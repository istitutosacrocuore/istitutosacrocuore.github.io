//  Copyright © 2016-2019 Apple Inc. All rights reserved.

//#-localizable-zone(PuzzleWorld01)
// Shared Code
// Code written in this file is available on all pages in this Playground Book.
//#-end-localizable-zone

public let world = GridWorld(columns: 10, rows: 10)
