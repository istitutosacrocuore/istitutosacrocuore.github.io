/*:
 **Presentazione:**
 
 - **Data:** 22 febbraio 2015
 - **Luogo:** indefinito tra le montagne del Cile
 
 La spedizione di 4 esploratori si era ormai protratta per ben oltre 14 giorni di viaggio.
 Ormai stanchi e pronti a mollare, si imbattono nei resti di un tempio e iniziano ad indagare ...

 **Precondizione:** analizzare ed eseguire il codice
 
 **Obiettivo:** completare la missione, ripristinando i portali per salire in cima alla torre e raccogliere tutte le gemme (*tesoro del tempio*)

 * Callout(Autore):
 **Gianluca De Fenza**
 */
//#-hidden-code
import Foundation

public func assessmentPoint() -> AssessmentResults {
    return .pass(message: nil)
}


public func playgroundPrologue() {
    Display.coordinateMarkers = true
    
    world.isCharacterPickerEnabled = false
    world.successCriteria = .custom(.ignoreGoals, { return false })
    registerAssessment(world, assessment: assessmentPoint)
    
    //// ----
    // Any items added or removed after this call will be animated.
    finalizeWorldBuilding(for: world)
    //// ----
}

// MARK: Epilogue

public func playgroundEpilogue() {
    sendCommands(for: world)
}

playgroundPrologue()
typealias Character = Actor
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color, array)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, hide, assessmentPoint(), playgroundPrologue(), playgroundEpilogue())
//#-code-completion(identifier, show, isOnOpenSwitch, if, func, for, while, moveForward(), turnLeft(), turnRight(), collectGem(), toggleSwitch(), isBlocked, north, south, east, west, Water, Expert, Character, (, ), (), turnLockUp(), turnLockDown(), isOnClosedSwitch, var, let, ., =, <, >, ==, !=, +=, +, -, isBlocked, move(distance:), Character, Expert, (, ), (), Portal, color:, (color:), Block, Gem, Stair, Switch, Platform, (onLevel:controlledBy:), onLevel:controlledBy:, PlatformLock, jump(), true, false, turnLock(up:numberOfTimes:), world, place(_:facing:at:), place(_:between:and:), removeBlock(atColumn:row:), isBlockedLeft, &&, ||, !, isBlockedRight, Coordinate, column:row:), (column:row:), column:row:, place(_:at:), remove(at:), insert(_:at:), removeItems(at:), append(_:), count, column(_:), row(_:), removeFirst(), removeLast(), randomInt(from:to:), removeAll(), allPossibleCoordinates, danceLikeNoOneIsWatching(), turnUp(), breakItDown(), grumbleGrumble(), argh(), coordinates(inRows:), coordinates(inColumns:intersectingRows:), name:, (name:), byte, blu, hopper, randomBool(), height(at:), movePlatforms(up:numberOfTimes:), height(at:), coordinates(inColumns:), existingGems(at:), existingSwitches(at:), existingCharacters(at:), existingExperts(at:), existingBlocks(at:), existingWater(at:), placeBlocks(at:), placeWater(at:), placeGems(at:), CharacterName, numberOfBlocks(at:), column, row)
// Inizializzazione dell'array "allCoordinates" con tutte le coordinate presenti nel mondo del livello
let allCoordinates = world.allPossibleCoordinates

// Inizializzazione degli array di coordinate
var island : [Coordinate] = []
var sea : [Coordinate] = []

// Costruzione del fiume
var columns = world.coordinates(inColumns: [5,6])
var rows = world.coordinates(inRows: [5,6])

for allCoordinates in rows {
    world.removeBlock(at: allCoordinates)
    world.placeWater(at: [allCoordinates])
}

for allCoordinates in columns {
    world.removeBlock(at: allCoordinates)
    world.placeWater(at: [allCoordinates])
}

// Costruzione del tempio
for coordinate in allCoordinates {
    if coordinate.column > 2 && coordinate.column < 9 && coordinate.row > 2 && coordinate.row < 9{
        island.append(coordinate)
    } else {
        sea.append(coordinate)
    }
}

for allCoordinates in island {
    world.place(Block(), at: allCoordinates)
}

for coordinate in allCoordinates{
    if coordinate.column > 3 && coordinate.column < 8 && coordinate.row > 3 && coordinate.row < 8{
        island.append(coordinate)
    }
}

for coordinate in island{
    world.place(Block(), at: coordinate)
}

for coordinate in allCoordinates{
    if coordinate.column > 4 && coordinate.column < 7 && coordinate.row > 4 && coordinate.row < 7{
        island.append(coordinate)
    }
}

for coordinate in island{
    world.place(Block(), at: coordinate)
}

// Selezione delle coordinate per le torri
var tower = [
    Coordinate(column: 11, row: 11), Coordinate(column: 11, row: 10), Coordinate(column: 10, row: 11), Coordinate(column: 10, row: 10), Coordinate(column: 1, row: 11), Coordinate(column: 1, row: 10), Coordinate(column: 0, row: 11), Coordinate(column: 0, row: 10), Coordinate(column: 0, row: 1), Coordinate(column: 0, row: 0), Coordinate(column: 1, row: 1), Coordinate(column: 1, row: 0), Coordinate(column: 11, row: 0), Coordinate(column: 11, row: 1), Coordinate(column: 10, row: 0), Coordinate(column: 10, row: 1)]

// Costruzione delle torri
for coordinate in tower {
    for i in 1 ... 10 {
        world.place(Block(), at: Coordinate(column: coordinate.column, row: coordinate.row
        ))
    }
}

// Selezione delle coordinate per il posizionamento delle gemme
var gem = [Coordinate(column: 3, row: 3), Coordinate(column: 8, row: 8), Coordinate(column: 3, row: 8), Coordinate(column: 10, row: 11), Coordinate(column: 11, row: 0), Coordinate(column: 0, row: 10), Coordinate(column: 0, row: 1)]

for coordinate in gem{
    world.placeGems(at: [coordinate])
}

// Posizionamento delle scale
world.place(Stair(), atColumn: 3, row: 6)
world.place(Stair(), facing: north, atColumn: 6, row: 7)
world.place(Stair(), facing: west, atColumn: 9, row: 11)
world.place(Stair(), facing: east, atColumn: 5, row: 8)
world.place(Stair(), facing: south, atColumn: 7, row: 2)
world.place(Stair(), facing: west, atColumn: 6, row: 3)
world.place(Stair(), facing: north, atColumn: 8, row: 5)
world.place(Stair(), facing: north, atColumn: 9, row: 7)

// Posizionamento dei muretti di pietra
world.place(Wall(), facing: north, atColumn: 2, row: 7)
world.place(Wall(), facing: north, atColumn: 1, row: 7)
world.place(Wall(), facing: south, atColumn: 0, row: 4)
world.place(Wall(), facing: west, atColumn: 4, row: 1)
world.place(Wall(), facing: south, atColumn: 7, row: 1)
world.place(Wall(), facing: north, atColumn: 9, row: 4)
world.place(Wall(), facing: east, atColumn: 11, row: 4)
world.place(Wall(), facing: east, atColumn: 7, row: 10)
world.place(Wall(), facing: east, atColumn: 4, row: 11)
world.place(Wall(), facing: east, atColumn: 7, row: 9)

// Inizializzazione dei personaggi
let xander = Character(name: .byte)
let billie = Character(name: .hopper)
let aaron = Character(name: .blu)
let ella = Expert()

// Posizionamento dei personaggi
world.place(xander, facing: south, atColumn: 9, row: 3)
world.place(billie, facing: east, atColumn: 8, row: 2)
world.place(aaron, facing: north, atColumn: 8, row: 7)
world.place(ella, facing: south, atColumn: 3, row: 6)

// Definizione delle azioni svolte dai personaggi
xander.danceLikeNoOneIsWatching()
billie.breakItDown()
aaron.grumbleGrumble()
ella.collectGem()

//#-editable-code Tap to enter code
// Inizializzazione e posizionamento dei portali
let portale1 = Portal(color: #colorLiteral(red: 0.9098039269447327, green: 0.47843137383461, blue: 0.6431372761726379, alpha: 1.0))
let portale2 = Portal(color: #colorLiteral(red: 0.9764705896377563, green: 0.8509804010391235, blue: 0.5490196347236633, alpha: 1.0))
let portale3 = Portal(color: #colorLiteral(red: 0.7215686440467834, green: 0.886274516582489, blue: 0.5921568870544434, alpha: 1.0))
let portale4 = Portal(color: #colorLiteral(red: 0.8078431487083435, green: 0.027450980618596077, blue: 0.3333333432674408, alpha: 1.0))
let portale5 = Portal(color: #colorLiteral(red: 0.239215686917305, green: 0.6745098233222961, blue: 0.9686274528503418, alpha: 1.0))
let portale6 = Portal(color: #colorLiteral(red: 0.5568627715110779, green: 0.3529411852359772, blue: 0.9686274528503418, alpha: 1.0))

world.place(portale1, atColumn: 3, row: 5 )
world.place(portale2, atColumn: 9, row: 2)
world.place(portale3, atColumn: 5, row: 7)
world.place(portale4, atColumn: 4, row: 11)
world.place(portale5, atColumn: 11, row: 11)
world.place(portale6, atColumn: 4, row: 3)

// Disattivazione di alcuni portali
portale2.isActive = false
portale3.isActive = false

world.place(Portal(color: #colorLiteral(red: 0.9098039269447327, green: 0.47843137383461, blue: 0.6431372761726379, alpha: 1.0)), atStartColumn:1, startRow:0, atEndColumn:1, endRow:0)

//#-end-editable-code

//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code

