/*:
 **Presentazione:** livello diviso in quattro sezioni:
 - un terreno basato sul livello *"Terre casuali"* di *"Impara a Programmare 2"*, punto di partenza per `Byte`
 - una montagna che `Byte` dovrà scalare per raccogliere la gemma
 - una torre la cui scala di accesso è interrotta: grazie ad `Expert` e alle sue abiltà bisognerà ristabilire il collegamento
 - un labirinto, punto di partenza per `Expert`
 
 **Precondizione:** analizzare ed eseguire il codice
 
 **Obiettivo:** raccogliere tutte le gemme e accendere tutti gli interruttori
 
 * Callout(Autore):
 **Paolo Mangiapia**
 */
//#-hidden-code
import Foundation

public func assessmentPoint() -> AssessmentResults {
    return .pass(message: nil)
}


public func playgroundPrologue() {
    Display.coordinateMarkers = true
    
    world.isCharacterPickerEnabled = false
    world.successCriteria = .custom(.ignoreGoals, { return false })
    registerAssessment(world, assessment: assessmentPoint)
    
    //// ----
    // Any items added or removed after this call will be animated.
    finalizeWorldBuilding(for: world)
    //// ----
}

// MARK: Epilogue

public func playgroundEpilogue() {
    sendCommands(for: world)
}

playgroundPrologue()
typealias Character = Actor
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color, array)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, hide, assessmentPoint(), playgroundPrologue(), playgroundEpilogue())
//#-code-completion(identifier, show, isOnOpenSwitch, if, func, for, while, moveForward(), turnLeft(), turnRight(), collectGem(), toggleSwitch(), isBlocked, north, south, east, west, Water, Expert, Character, (, ), (), turnLockUp(), turnLockDown(), isOnClosedSwitch, var, let, ., =, <, >, ==, !=, +=, +, -, isBlocked, move(distance:), Character, Expert, (, ), (), Portal, color:, (color:), Block, Gem, Stair, Switch, Platform, (onLevel:controlledBy:), onLevel:controlledBy:, PlatformLock, jump(), true, false, turnLock(up:numberOfTimes:), world, place(_:facing:at:), place(_:between:and:), removeBlock(atColumn:row:), isBlockedLeft, &&, ||, !, isBlockedRight, Coordinate, column:row:), (column:row:), column:row:, place(_:at:), remove(at:), insert(_:at:), removeItems(at:), append(_:), count, column(_:), row(_:), removeFirst(), removeLast(), randomInt(from:to:), removeAll(), allPossibleCoordinates, danceLikeNoOneIsWatching(), turnUp(), breakItDown(), grumbleGrumble(), argh(), coordinates(inRows:), coordinates(inColumns:intersectingRows:), name:, (name:), byte, blu, hopper, randomBool(), height(at:), movePlatforms(up:numberOfTimes:), height(at:), coordinates(inColumns:), existingGems(at:), existingSwitches(at:), existingCharacters(at:), existingExperts(at:), existingBlocks(at:), existingWater(at:), placeBlocks(at:), placeWater(at:), placeGems(at:), CharacterName, numberOfBlocks(at:), column, row)
// Inizializzazione dell'array "allCoordinates" con tutte le coordinate presenti nel mondo del livello
let allCoordinates = world.allPossibleCoordinates

// Inizializzazione di personaggi, portali e piattaforme
let platformlockRed = PlatformLock(color: #colorLiteral(red: 0.7450980544090271, green: 0.1568627506494522, blue: 0.07450980693101883, alpha: 1.0))
let expert = Expert()
let byte = Character(name: .byte)
let orangeportal = Portal(color: #colorLiteral(red: 0.9372549057006836, green: 0.3490196168422699, blue: 0.1921568661928177, alpha: 1.0))
let redportal = Portal(color: #colorLiteral(red: 0.7450980544090271, green: 0.1568627506494522, blue: 0.07450980693101883, alpha: 1.0))
let blackportal = Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0))

// Selezione delle coordinate per la creazione della fascia d'acqua orizzontale
let coordinate1 = world.coordinates(inColumns: [0,1,2,3,4,5,6,7,8,9,10,11], intersectingRows: [4,5,6,7])

for coordinate in coordinate1{
    world.removeBlock(at:coordinate)
    world.placeWater(at: [coordinate])
}

// Selezione delle coordinate necessarie per la costruzione dei vari elementi
let coordinate2 = world.coordinates(inColumns: [8,9,10,11], intersectingRows: [0])
let coordinate3 = world.coordinates(inColumns: [9,10,11], intersectingRows: [1])
let coordinate4 = world.coordinates(inColumns: [10,11], intersectingRows: [2])
let coordinate5 = world.coordinates(inColumns: [4,5,6,7], intersectingRows: [0,1,2,3,4,5,6,7,8,9,10,11])
let coordinate6 = world.coordinates(inColumns: [8,9,10,11], intersectingRows: [8,9,10,11])
let coordinate7 = world.coordinates(inColumns: [0,1,2], intersectingRows: [0,1,2])
let coordinate8 = world.coordinates(inColumns: [0,1,2,3], intersectingRows: [11,10,9,8])
let coordinate9 = world.coordinates(inColumns: [5,6], intersectingRows: [0,1,2,3,4,5,6,7,8,9,10,11])
let coordinate10 = world.coordinates(inColumns: [0,1,2,3,4,5,6,7,8,9,10,11],intersectingRows: [5,6])

var heights: [Int] = [1,2,3,4]
var heights2: [Int] = [1,2,3]
var heights3: [Int] = []

// Creazione "terra casuale" (con un panorama unico ogni volta che il codice viene eseguito)
var index = 0
for i in 1 ... 9 {
    let localnumber = randomInt(from: 1, to: 4)
    heights3.append(localnumber)
}

var index2 : Int = 0
for coordinate in coordinate6 {
    let height = coordinate.column + coordinate.row
    if index2 == heights3.count {
        index2 = 0
        
    }
    var currentHeight3 = heights3[index2]
    for i in 1 ... currentHeight3 {
        world.placeBlocks(at: [coordinate])
    }
    index2 += 1
}

world.place(Switch(), at: Coordinate(column: 11, row: 11))

// Creazione della montagna
for coordinate in coordinate2 {
    if index == heights.count {
        index = 0
    }
    for i in 1...heights[index] {
        
        world.place(Block(), at: coordinate)
    }
    index += 1
    if index == heights.count {
        index = 0
    }
    
}

for coordinate in coordinate3 {
    if index == heights.count {
        index = 0
    }
    for i in 1...heights[index] {
        
        world.place(Block(), at: coordinate)
    }
    
    index += 1
    if index == heights.count {
        index = 0
    }
    
}

for coordinate in coordinate4 {
    if index == heights2.count {
        index = 0
    }
    for i in 1...heights2[index] {
        
        world.place(Block(), at: coordinate)
    }
    index += 1
    if index == heights2.count {
        index = 0
    }
}

world.placeBlocks(at: [Coordinate(column: 11, row: 3)])

// Creazione della fascia d'acqua trasversale
for coordinate in coordinate5{
    world.removeBlock(at: coordinate)
    world.placeWater(at: [coordinate])
}
world.placeGems(at: [Coordinate(column: 11, row: 0)])

// Creazione della torre
for coordinate in coordinate7 {
    
    for i in 1 ... 9 {
        world.placeBlocks(at: [coordinate])
    }
}

// Creazione della scalinata
world.placeBlocks(at: [Coordinate(column: 0, row: 3)])
for i in 1 ... 2 {
    world.placeBlocks(at: [Coordinate(column: 1, row: 3)])
}

for i in 1 ... 3 {
    world.placeBlocks(at: [Coordinate(column: 2, row: 3)])
}

for i in 1 ... 4 {
    world.placeBlocks(at: [Coordinate(column: 3, row: 3)])
}

for i in 1 ... 5 {
    world.placeBlocks(at: [Coordinate(column: 3, row: 2)])
}

for i in 1 ... 6 {
    world.placeBlocks(at: [Coordinate(column: 3, row: 1)])
}

world.removeBlock(atColumn: 2, row: 0)
world.placeGems(at: [Coordinate(column: 0, row: 2)])

// Creazione del labirinto
for coordinate in coordinate8 {
    for i in 1 ... 2 {
        world.placeBlocks(at: [coordinate])
    }
    world.place(Wall(), at: Coordinate(column: 0, row: 10))
    world.place(Wall(), at: Coordinate(column: 1, row: 10))
    world.place(Wall(), at: Coordinate(column: 2, row: 10))
    world.place(Wall(),facing: east, at: Coordinate(column: 3, row: 10))
    world.place(Wall(), at: Coordinate(column: 2, row: 9))
    world.place(Wall(), at: Coordinate(column: 1, row: 9))
    world.place(Wall(), at: Coordinate(column: 0, row: 9))
    world.place(Wall(), at: Coordinate(column: 1, row: 8))
    world.place(Wall(), at: Coordinate(column: 2, row: 8))
    world.place(Wall(), at: Coordinate(column: 3, row: 8))
}

// Finalizzazione del mondo
world.place(orangeportal, atStartColumn: 3, startRow: 8, atEndColumn: 0, endRow: 3)

for i in 1 ... 5 {
    world.place(Block(), at: Coordinate(column: 4, row: 3))
}

orangeportal.isActive = true
world.place(blackportal, atStartColumn: 11, startRow: 10 , atEndColumn: 8, endRow: 3)
blackportal.isActive = true
world.place(expert,facing: east, at: Coordinate(column: 0, row: 11))
world.place(byte, at: Coordinate(column: 8, row: 8))
world.place(platformlockRed,facing: west, at: Coordinate(column: 4, row: 3))
world.place(Platform(onLevel: 2, controlledBy: platformlockRed), at: Coordinate(column: 3, row: 0))

// Posizionamento della piattaforma galleggiante
for coordinate in coordinate9 {
    world.place(Block(), at: coordinate)
}

for coordinate in coordinate10{
    world.place(Block(), at: coordinate)
}

//#-editable-code Tocca per inserire il codice

//#-end-editable-code
//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code


