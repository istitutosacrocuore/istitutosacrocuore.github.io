/*:
 **Precondizione:** analizzare ed eseguire il codice
 
 **Sfida:**  completare il livello, raccogliendo tutte le gemme (9) e accendendo tutti gli interruttori (4)
 
 * Callout(Autore):
 **Paolo Scocca**
 */
//#-hidden-code

//#-end-hidden-code
/*:
 * Callout(💡 Suggerimenti):
    1. L'utente dovrà anche gestire tre personaggi: Expert, Blu e Hopper, che dovranno aiutarsi a vicenda per superare il livello.
    2. Expert dovrà attraversare i due labirinti, attraversando uno dei due portali.
    3. Una volta superata la sezione, Expert potrà abbassare le piattaforme collegate al lock dello stesso colore.
    4. Così facendo, abbasserà la piattaforma per aiutare Blu o Hopper e allo stesso tempo gli permetterà di tornare all'inizio usando un portale.
 */
//#-hidden-code
import Foundation

public func assessmentPoint() -> AssessmentResults {
    return .pass(message: nil)
}


public func playgroundPrologue() {
    Display.coordinateMarkers = true
    
    world.isCharacterPickerEnabled = false
    world.successCriteria = .custom(.ignoreGoals, { return false })
    registerAssessment(world, assessment: assessmentPoint)
    
    //// ----
    // Any items added or removed after this call will be animated.
    finalizeWorldBuilding(for: world)
    //// ----
}

// MARK: Epilogue

public func playgroundEpilogue() {
    sendCommands(for: world)
}

playgroundPrologue()
typealias Character = Actor
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color, array)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, hide, assessmentPoint(), playgroundPrologue(), playgroundEpilogue())
//#-code-completion(identifier, show, isOnOpenSwitch, if, func, for, while, moveForward(), turnLeft(), turnRight(), collectGem(), toggleSwitch(), isBlocked, north, south, east, west, Water, Expert, Character, (, ), (), turnLockUp(), turnLockDown(), isOnClosedSwitch, var, let, ., =, <, >, ==, !=, +=, +, -, isBlocked, move(distance:), Character, Expert, (, ), (), Portal, color:, (color:), Block, Gem, Stair, Switch, Platform, (onLevel:controlledBy:), onLevel:controlledBy:, PlatformLock, jump(), true, false, turnLock(up:numberOfTimes:), world, place(_:facing:at:), place(_:between:and:), removeBlock(atColumn:row:), isBlockedLeft, &&, ||, !, isBlockedRight, Coordinate, column:row:), (column:row:), column:row:, place(_:at:), remove(at:), insert(_:at:), removeItems(at:), append(_:), count, column(_:), row(_:), removeFirst(), removeLast(), randomInt(from:to:), removeAll(), allPossibleCoordinates, danceLikeNoOneIsWatching(), turnUp(), breakItDown(), grumbleGrumble(), argh(), coordinates(inRows:), coordinates(inColumns:intersectingRows:), name:, (name:), byte, blu, hopper, randomBool(), height(at:), movePlatforms(up:numberOfTimes:), height(at:), coordinates(inColumns:), existingGems(at:), existingSwitches(at:), existingCharacters(at:), existingExperts(at:), existingBlocks(at:), existingWater(at:), placeBlocks(at:), placeWater(at:), placeGems(at:), CharacterName, numberOfBlocks(at:), column, row)
// Dichiarazione di variabili e costanti
let platformLockYellow = PlatformLock(color: #colorLiteral(red: 0.9529411792755127, green: 0.686274528503418, blue: 0.13333334028720856, alpha: 1.0))
let platformLockRed = PlatformLock(color: #colorLiteral(red: 0.9254902005195618, green: 0.23529411852359772, blue: 0.10196078568696976, alpha: 1.0))
let allCoordinates = world.allPossibleCoordinates
var index : Int = 0
var heights : [Int] = []
let mountain1 = world.coordinates(inColumns: [4], intersectingRows: [0,1,2,3,4])
let mountain2 = world.coordinates(inColumns: [0,1,2,3], intersectingRows: [4])
let mountain3 = world.coordinates(inColumns: [7], intersectingRows: [7,8,9,10,11])
let mountain4 = world.coordinates(inColumns: [7,8,9,10,11], intersectingRows: [6])
var sea : [Coordinate] = []

//Creazione del mondo
for coordinate in allCoordinates {
    if coordinate.column >= 7 && coordinate.row <= 4 {
        sea.append(coordinate)
    }
}
for allCoordinates in sea  {
    world.removeBlock(at: allCoordinates)
    world.placeWater(at: [allCoordinates])
}

//Inizializzazione del fiume
world.placeBlocks(at: [Coordinate(column: 7, row: 2)])
world.placeBlocks(at: [Coordinate(column: 9, row: 3)])
world.placeBlocks(at: [Coordinate(column: 10, row: 4)])
world.placeBlocks(at: [Coordinate(column: 9, row: 4)])
world.placeBlocks(at: [Coordinate(column: 8, row: 4)])
world.removeBlock(atColumn: 6, row: 0)
world.placeWater(at: [Coordinate(column: 6, row: 0)])
world.removeBlock(atColumn: 6, row: 4)
world.placeWater(at: [Coordinate(column: 6, row: 4)])
world.removeBlock(atColumn: 6, row: 5)
world.placeWater(at: [Coordinate(column: 6, row: 5)])
world.removeBlock(atColumn: 5, row: 5)
world.placeWater(at: [Coordinate(column: 5, row: 5)])
world.removeBlock(atColumn: 5, row: 6)
world.placeWater(at: [Coordinate(column: 5, row: 6)])
world.removeBlock(atColumn: 4, row: 6)
world.placeWater(at: [Coordinate(column: 4, row: 6)])
world.removeBlock(atColumn: 4, row: 7)
world.placeWater(at: [Coordinate(column: 4, row: 7)])
world.removeBlock(atColumn: 3, row: 7)
world.placeWater(at: [Coordinate(column: 3, row: 7)])
world.removeBlock(atColumn: 3, row: 8)
world.placeWater(at: [Coordinate(column: 3, row: 8)])
world.removeBlock(atColumn: 2, row: 8)
world.placeWater(at: [Coordinate(column: 2, row: 8)])
world.removeBlock(atColumn: 2, row: 9)
world.placeWater(at: [Coordinate(column: 2, row: 9)])
world.removeBlock(atColumn: 1, row: 9)
world.placeWater(at: [Coordinate(column: 1, row: 9)])
world.removeBlock(atColumn: 1, row: 10)
world.placeWater(at: [Coordinate(column: 1, row: 10)])

//Inizzializzazione del labirinto
world.place(Platform(onLevel: 1, controlledBy: PlatformLock(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0))), at: Coordinate(column: 0, row: 11))
world.place(Wall(), facing: north, at: Coordinate(column: 5, row: 0))
world.place(Wall(), facing: west, at: Coordinate(column: 5, row: 0))
world.place(Wall(), facing: north, at: Coordinate(column: 6, row: 1))
world.place(Wall(), facing: west, at: Coordinate(column: 6, row: 1))
world.place(Wall(), facing: north, at: Coordinate(column: 7, row: 2))
world.place(Wall(), facing: west, at: Coordinate(column: 7, row: 2))
world.place(Wall(), facing: south, at: Coordinate(column: 7, row: 2))
world.place(Wall(), facing: west, at: Coordinate(column: 6, row: 3))
world.place(Wall(), facing: south, at: Coordinate(column: 6, row: 3))
world.place(Wall(), facing: west, at: Coordinate(column: 5, row: 4))
world.place(Wall(), facing: south, at: Coordinate(column: 5, row: 4))
world.place(Wall(), facing: north, at: Coordinate(column: 7, row: 5))
world.place(Wall(), facing: east, at: Coordinate(column: 7, row: 5))
world.place(Wall(), facing: east, at: Coordinate(column: 8, row: 4))
world.place(Wall(), facing: north, at: Coordinate(column: 8, row: 4))
world.place(Wall(), facing: east, at: Coordinate(column: 9, row: 3))
world.place(Wall(), facing: north, at: Coordinate(column: 9, row: 3))
world.place(Wall(), facing: west, at: Coordinate(column: 9, row: 3))
world.place(Wall(), facing: north, at: Coordinate(column: 10, row: 4))
world.place(Wall(), facing: west, at: Coordinate(column: 10, row: 4))
world.place(Wall(), facing: north, at: Coordinate(column: 11, row: 5))
world.place(Wall(), facing: west, at: Coordinate(column: 11, row: 5))

for i in 1 ... 20 {
    let localNumber = randomInt(from: 4, to: 5)
    heights.append(localNumber)
}

for coordinate in mountain1 {
    if index == heights.count {
        index = 0
    }
    var currentHeight = heights[index]
    if currentHeight == 0 {
    } else {
        for i in 1 ... currentHeight {
            world.place(Block(), at: coordinate)
        }
    }
    index += 1
}
for coordinate in mountain2 {
    if index == heights.count {
        index = 0
    }
    var currentHeight = heights[index]
    if currentHeight == 0 {
    } else {
        for i in 1 ... currentHeight {
            world.place(Block(), at: coordinate)
        }
    }
    index += 1
}
for coordinate in mountain3 {
    if index == heights.count {
        index = 0
    }
    var currentHeight = heights[index]
    if currentHeight == 0 {
    } else {
        for i in 1 ... currentHeight {
            world.place(Block(), at: coordinate)
        }
    }
    index += 1
}
for coordinate in mountain4 {
    if index == heights.count {
        index = 0
    }
    var currentHeight = heights[index]
    if currentHeight == 0 {
    } else {
        for i in 1 ... currentHeight {
            world.place(Block(), at: coordinate)
        }
    }
    index += 1
}
world.place(Wall(), facing: west, at: Coordinate(column: 0, row: 7))
world.place(Wall(), facing: west, at: Coordinate(column: 0, row: 6))
world.place(Wall(), facing: north, at: Coordinate(column: 0, row: 6))
world.place(Wall(), facing: south, at: Coordinate(column: 1, row: 6))
world.place(Wall(), facing: west, at: Coordinate(column: 1, row: 6))
world.place(Wall(), facing: north, at: Coordinate(column: 2, row: 6))
world.place(Wall(), facing: west, at: Coordinate(column: 5, row: 11))
world.place(Wall(), facing: west, at: Coordinate(column: 4, row: 11))
world.place(Wall(), facing: north, at: Coordinate(column: 4, row: 11))
world.place(Wall(), facing: south, at: Coordinate(column: 3, row: 10))
world.place(Wall(), facing: west, at: Coordinate(column: 3, row: 10))
world.place(Wall(), facing: north, at: Coordinate(column: 4, row: 10))
world.place(Wall(), facing: south, at: Coordinate(column: 5, row: 8))
world.place(Wall(), facing: north, at: Coordinate(column: 5, row: 8))
world.place(Wall(), facing: north, at: Coordinate(column: 5, row: 9))
world.place(Wall(), facing: west, at: Coordinate(column: 5, row: 9))
world.place(Wall(), facing: south, at: Coordinate(column: 6, row: 9))
world.removeBlock(atColumn: 0, row: 1)
world.place(Water(), at: Coordinate(column: 0, row: 1))
world.removeBlock(atColumn: 1, row: 1)
world.place(Water(), at: Coordinate(column: 1, row: 1))
world.removeBlock(atColumn: 2, row: 1)
world.place(Water(), at: Coordinate(column: 2, row: 1))
world.removeBlock(atColumn: 3, row: 1)
world.place(Water(), at: Coordinate(column: 3, row: 1))
world.removeBlock(atColumn: 8, row: 9)
world.place(Water(), at: Coordinate(column: 8, row: 9))
world.removeBlock(atColumn: 9, row: 9)
world.place(Water(), at: Coordinate(column: 9, row: 9))
world.removeBlock(atColumn: 10, row: 9)
world.place(Water(), at: Coordinate(column: 10, row: 9))
world.removeBlock(atColumn: 11, row: 9)
world.place(Water(), at: Coordinate(column: 11, row: 9))
world.place(Portal(color: #colorLiteral(red: 0.21960784494876862, green: 0.007843137718737125, blue: 0.8549019694328308, alpha: 1.0)), between: Coordinate(column: 4, row: 5), and: Coordinate(column: 5, row: 4))
world.place(Portal(color: #colorLiteral(red: 0.34117648005485535, green: 0.6235294342041016, blue: 0.16862745583057404, alpha: 1.0)), between: Coordinate(column: 6, row: 6), and: Coordinate(column: 7, row: 5))
world.place(Platform(onLevel: 4, controlledBy: platformLockRed), at: Coordinate(column: 2, row: 9))
world.place(Platform(onLevel: 4, controlledBy: platformLockRed), at: Coordinate(column: 0, row: 1))
world.place(Platform(onLevel: 4, controlledBy: platformLockYellow), at: Coordinate(column: 1, row: 9))
world.place(Platform(onLevel: 4, controlledBy: platformLockYellow), at: Coordinate(column: 8, row: 9))
world.place(Portal(color: #colorLiteral(red: 0.9529411792755127, green: 0.686274528503418, blue: 0.13333334028720856, alpha: 1.0)), between: Coordinate(column: 11, row: 5), and: Coordinate(column: 1, row: 9))
world.place(Portal(color: #colorLiteral(red: 0.9254902005195618, green: 0.23529411852359772, blue: 0.10196078568696976, alpha: 1.0)), between: Coordinate(column: 5, row: 0), and: Coordinate(column: 2, row: 9))
world.place(Gem(), at: Coordinate(column: 0, row: 6))
world.place(Gem(), at: Coordinate(column: 1, row: 6))
world.place(Gem(), at: Coordinate(column: 7, row: 2))
world.place(Gem(), at: Coordinate(column: 4, row: 11))
world.place(Gem(), at: Coordinate(column: 6, row: 11))
world.place(Gem(), at: Coordinate(column: 4, row: 10))
world.place(Gem(), at: Coordinate(column: 5, row: 7))
world.place(Gem(), at: Coordinate(column: 6, row: 9))
world.place(Gem(), at: Coordinate(column: 9, row: 3))
world.place(Switch(), at: Coordinate(column: 8, row: 7))
world.place(Switch(), at: Coordinate(column: 0, row: 0))
world.place(Stair(), facing: west, at: Coordinate(column: 9, row: 7))
world.place(Block(), at: Coordinate(column: 10, row: 7))
world.place(Stair(), facing: west, at: Coordinate(column: 10, row: 7))
for i in 1 ... 2 {
    world.place(Block(), at: Coordinate(column: 11, row: 7))
}
world.place(Switch(), at: Coordinate(column: 11, row: 7))
world.place(Stair(), facing: west, at: Coordinate(column: 1, row: 0))
world.place(Block(), at: Coordinate(column: 2, row: 0))
world.place(Stair(), facing: west, at: Coordinate(column: 2, row: 0))
for i in 1 ... 2 {
    world.place(Block(), at: Coordinate(column: 3, row: 0))
}
world.place(Switch(), at: Coordinate(column: 3, row: 0))
world.place(platformLockRed, facing: west, at: Coordinate(column: 10, row: 4))
world.place(platformLockYellow, facing: north, at: Coordinate(column: 6, row: 1))

// Dichiarazione e inizializzazione dei personaggi
let expert = Expert()
let blu = Character(name: .blu)
let hopper = Character(name: .hopper)
world.place(expert, facing: south, at: Coordinate(column: 0, row: 11))
world.place(blu, facing: south, at: Coordinate(column: 0, row: 2))
world.place(hopper, facing: south, at: Coordinate(column: 8, row: 10))

expert.danceLikeNoOneIsWatching()
blu.danceLikeNoOneIsWatching()
hopper.danceLikeNoOneIsWatching()

//#-editable-code Tap to enter code


//#-end-editable-code


//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code

