/*:
 **Presentazione:** da un'idea originale, una scacchiera ♟ "rivisitata" sfruttando la capacità dei portali di poter teletrasportare i personaggi.
 
 Buona fortuna!🤞🏻🤔
 
 **Precondizione:** analizzare ed eseguire il codice
 
 **Obiettivo:** come in una partita a scacchi, individuare le mosse giuste per aiutare `Blu` e `Hopper` a raccogliere tutte le gemme e ad attivare tutti gli interruttori
 
 * Callout(Autore):
 **Andrea Celano**
 */
//#-hidden-code

//#-end-hidden-code
/*:
 
- Note:
Solo uno tra tutti i portali presenti può teletrasportare i personaggi sulle piattaforme dove sono collocate le gemme e gli interruttori

 * Callout(💡 Suggerimenti):
    1. Alcuni portali portano indietro, mentre altri possono dare una GROSSA MANO.
    2. Se proprio non riesci ad individuare il portale corretto ✖️😞, prova a controllare nelle prime file o quelli agli angoli🤫😉
 */
//#-hidden-code
import Foundation

public func assessmentPoint() -> AssessmentResults {
    return .pass(message: nil)
}


public func playgroundPrologue() {
    Display.coordinateMarkers = true
    
    world.isCharacterPickerEnabled = false
    world.successCriteria = .custom(.ignoreGoals, { return false })
    registerAssessment(world, assessment: assessmentPoint)
    
    //// ----
    // Any items added or removed after this call will be animated.
    finalizeWorldBuilding(for: world)
    //// ----
}

// MARK: Epilogue

public func playgroundEpilogue() {
    sendCommands(for: world)
}

playgroundPrologue()
typealias Character = Actor
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color, array)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, hide, assessmentPoint(), playgroundPrologue(), playgroundEpilogue())
//#-code-completion(identifier, show, isOnOpenSwitch, if, func, for, while, moveForward(), turnLeft(), turnRight(), collectGem(), toggleSwitch(), isBlocked, north, south, east, west, Water, Expert, Character, (, ), (), turnLockUp(), turnLockDown(), isOnClosedSwitch, var, let, ., =, <, >, ==, !=, +=, +, -, isBlocked, move(distance:), Character, Expert, (, ), (), Portal, color:, (color:), Block, Gem, Stair, Switch, Platform, (onLevel:controlledBy:), onLevel:controlledBy:, PlatformLock, jump(), true, false, turnLock(up:numberOfTimes:), world, place(_:facing:at:), place(_:between:and:), removeBlock(atColumn:row:), isBlockedLeft, &&, ||, !, isBlockedRight, Coordinate, column:row:), (column:row:), column:row:, place(_:at:), remove(at:), insert(_:at:), removeItems(at:), append(_:), count, column(_:), row(_:), removeFirst(), removeLast(), randomInt(from:to:), removeAll(), allPossibleCoordinates, danceLikeNoOneIsWatching(), turnUp(), breakItDown(), grumbleGrumble(), argh(), coordinates(inRows:), coordinates(inColumns:intersectingRows:), name:, (name:), byte, blu, hopper, randomBool(), height(at:), movePlatforms(up:numberOfTimes:), height(at:), coordinates(inColumns:), existingGems(at:), existingSwitches(at:), existingCharacters(at:), existingExperts(at:), existingBlocks(at:), existingWater(at:), placeBlocks(at:), placeWater(at:), placeGems(at:), CharacterName, numberOfBlocks(at:), column, row)

let blu = Character(name: .blu)
let hopper = Character(name: .hopper)
var column6 = world.coordinates(inColumns : [6])
var discardedCoordinates: [Coordinate] = []

// Costruzione della scacchiera
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 8, startRow: 1, atEndColumn: 7, endRow: 10)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 3, startRow: 6, atEndColumn: 4, endRow: 1)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 5, startRow: 5, atEndColumn: 0, endRow: 10)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 7, startRow: 9, atEndColumn: 11, endRow: 5)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 2,startRow: 7, atEndColumn: 1,endRow: 11)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 8,startRow: 10, atEndColumn: 1,endRow: 11)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 7,startRow: 6, atEndColumn: 11,endRow: 11)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 9,startRow: 10, atEndColumn: 11,endRow: 10)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 8,startRow: 9, atEndColumn: 9,endRow: 10)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 8,startRow: 8, atEndColumn: 10,endRow: 10)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 7,startRow: 7, atEndColumn: 9,endRow: 9)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 11,startRow: 10, atEndColumn: 7,endRow: 8)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 10,startRow: 9, atEndColumn: 9,endRow: 8)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 7,startRow: 6, atEndColumn: 8,endRow: 7)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 11,startRow: 9, atEndColumn: 5,endRow: 5)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 9,startRow: 7, atEndColumn: 10,endRow: 8)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 7,startRow: 5, atEndColumn: 8,endRow: 6)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 11,startRow: 8, atEndColumn: 10,endRow: 7)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 8,startRow: 5, atEndColumn: 9,endRow: 6)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 10,startRow: 5, atEndColumn: 11,endRow: 6)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 10,startRow: 6, atEndColumn: 11,endRow: 7)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 11,startRow: 6, atEndColumn: 7,endRow: 4)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 9,startRow: 4, atEndColumn: 10,endRow: 5)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 11,startRow: 2, atEndColumn: 11,endRow: 4)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 11,startRow: 3, atEndColumn: 11,endRow: 1)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 9,startRow: 1, atEndColumn: 10,endRow: 2)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 10,startRow: 1, atEndColumn: 8,endRow: 3)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 9,startRow: 2, atEndColumn: 10,endRow: 3)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 10,startRow: 4, atEndColumn: 11,endRow: 5)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 8,startRow: 2, atEndColumn: 9,endRow: 3)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 4,startRow: 4, atEndColumn: 5,endRow: 5)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 7,startRow: 2, atEndColumn: 11,endRow: 6)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 4,startRow: 4, atEndColumn: 5,endRow: 5)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 3,startRow: 2, atEndColumn: 4,endRow: 1 )
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 4, startRow: 1, atEndColumn: 1, endRow: 2)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 2, startRow: 1, atEndColumn: 3, endRow: 2)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 5, startRow: 11, atEndColumn: 6, endRow: 0)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 3, startRow: 2, atEndColumn: 5, endRow: 4 )
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 3,startRow: 4, atEndColumn: 3,endRow: 8)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 1, startRow: 1, atEndColumn: 1, endRow: 7)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 5, startRow: 1, atEndColumn: 2, endRow: 4)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 7, startRow: 3, atEndColumn: 9, endRow: 5)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 5,startRow: 6, atEndColumn: 3,endRow: 2)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 4,startRow: 3, atEndColumn: 5,endRow: 4)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 3,startRow: 1, atEndColumn: 4,endRow: 2)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 5,startRow: 3, atEndColumn: 0,endRow: 2)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 3,startRow: 3, atEndColumn: 2,endRow: 2)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 1,startRow: 1, atEndColumn: 1,endRow: 3)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 2,startRow: 3, atEndColumn: 0,endRow: 3)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 1,startRow: 4, atEndColumn: 2,endRow: 5)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 3,startRow: 6, atEndColumn: 4,endRow: 7)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 5,startRow: 2, atEndColumn: 5,endRow: 8)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 3,startRow: 5, atEndColumn: 4,endRow: 6)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 5,startRow: 7, atEndColumn: 0,endRow: 4)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 1,startRow: 5, atEndColumn: 2,endRow: 6)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 3,startRow: 7, atEndColumn: 4,endRow: 8)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 5,startRow: 9, atEndColumn: 0,endRow: 6)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 4,startRow: 5, atEndColumn: 0,endRow: 5)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 1,startRow: 6, atEndColumn: 2,endRow: 7)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 4,startRow: 9, atEndColumn: 5,endRow: 10)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 0,startRow: 7, atEndColumn: 1,endRow: 8)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 3,startRow: 10, atEndColumn: 1,endRow: 10)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 0,startRow: 9, atEndColumn: 0,endRow: 11)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 2,startRow: 8, atEndColumn: 3,endRow: 9)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 4,startRow: 10, atEndColumn: 0,endRow: 8)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 1,startRow: 9, atEndColumn: 2,endRow: 10)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 0,startRow: 10, atEndColumn: 1,endRow: 1)
world.place(Portal(color: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), atStartColumn: 7,startRow: 11, atEndColumn: 6,endRow: 11)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 2,startRow: 9, atEndColumn: 7,endRow: 1)
world.place(Portal(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)), atStartColumn: 0,startRow: 1, atEndColumn: 8,endRow: 4)

for i in 1 ... 3 {
    world.place(Block(), atColumn: 6, row: 0)
    world.place(Block(), atColumn: 6, row: 7)
    world.place(Block(), atColumn: 6, row: 11 )
    world.place(Block(), atColumn: 6, row: 10)
    world.place(Block(), atColumn: 6, row: 9)
    world.place(Block(), atColumn: 6, row: 8)
    world.place(Block(), atColumn: 6, row: 6)
    world.place(Block(), atColumn: 6, row: 5)
    world.place(Block(), atColumn: 6, row: 4)
    world.place(Block(), atColumn: 6, row: 3)
    world.place(Block(), atColumn: 6, row: 1)
    world.place(Block(), atColumn: 6, row: 0)
}

for i in 1 ... 2 {
    world.place(Block(), atColumn: 5, row: 11)
    world.place(Block(), atColumn: 7, row: 11)
    world.place(Block(), atColumn: 6, row: 1)
    world.place(Block(), atColumn: 4, row: 11)
    world.place(Block(), atColumn: 8, row: 11)
    world.place(Block(), atColumn: 6, row: 2)
    world.place(Block(), atColumn: 6, row: 2)
    world.removeBlock(atColumn: 6, row: 8)
    world.removeBlock(atColumn: 6, row: 10)
    world.place(Block(), atColumn: 6, row: 10)
    world.place(Block(), atColumn: 6, row: 5)
    world.place(Block(), atColumn: 6, row: 3)
    world.place(Block(), atColumn: 6, row: 8)
}

world.place(Block(), atColumn: 6, row: 9)
world.removeBlock(atColumn: 6, row: 9)
world.place(Block(), atColumn: 3, row: 11)
world.place(Block(), atColumn: 2, row: 11)
world.place(Block(), atColumn: 3, row: 11)
world.place(Block(), atColumn: 9, row: 11)
world.place(Block(), atColumn: 10, row: 11)
world.removeBlock(atColumn: 6, row: 5)
world.place(Block(), atColumn: 6, row: 4)
world.place(Block(), atColumn: 6, row: 2)
world.place(Block(), atColumn: 1, row: 11)
world.place(Block(), atColumn: 6, row: 0)
world.place(Block(), atColumn: 11, row: 11)
world.place(Block(), atColumn: 9, row: 11)
world.place(Stair(), facing: east, atColumn: 10, row: 11)
world.place(Gem(), atColumn: 4, row: 11)
world.place(Stair(), facing: west, atColumn: 2, row: 11)
world.place(Switch(), atColumn: 9, row: 11)
world.removeBlock(atColumn: 6, row: 9)
world.place(Switch(), atColumn: 3, row: 11)
world.removeBlock(atColumn: 6, row: 8)
world.place(Block(), atColumn: 6, row: 2)
world.place(Gem(), atColumn: 8, row: 11)
world.place(Block(), atColumn: 6, row: 1)

for i in 1...10 {
    for coordinate in column6 {
        world.place(Block(), at: coordinate)
    }
    discardedCoordinates.append(column6.remove(at: 0))
}

world.place(Stair(), facing: south, atColumn: 6, row: 6)
world.place(Stair(), facing: south, atColumn: 6, row: 4)
world.place(Stair(), facing: south, atColumn: 6, row: 1)
world.place(Stair(), facing: south, atColumn: 6, row: 8)
world.place(Stair(), facing: south, atColumn: 6, row: 9)

world.place(Switch(), atColumn: 6, row: 10)
world.place(Switch(), atColumn: 6, row: 7)
world.place(Switch(), atColumn: 6, row: 5)
world.place(Switch(), atColumn: 6, row: 3)

world.place(Wall(), facing: south, atColumn: 8, row: 11)
world.place(Wall(), facing: south, atColumn: 9, row: 11)
world.place(Wall(), facing: south, atColumn: 8, row: 11)
world.place(Wall(), facing: north, atColumn: 9, row: 11)
world.place(Wall(), facing: north, atColumn: 8, row: 11)
world.place(Wall(), facing: south, atColumn: 7, row: 11)
world.place(Wall(), facing: south, atColumn: 10, row: 11)
world.place(Wall(), facing: north, atColumn: 10, row: 11)
world.place(Wall(), facing: south, atColumn: 2, row: 11)
world.place(Wall(), facing: south, atColumn: 3, row: 11)
world.place(Wall(), facing: south, atColumn: 4, row: 11)
world.place(Wall(), facing: south, atColumn: 5, row: 11)
world.place(Wall(), facing: south, atColumn: 2, row: 11)
world.place(Wall(), facing: south, atColumn: 3, row: 11)
world.place(Wall(), facing: south, atColumn: 4, row: 11)
world.place(Wall(), facing: south, atColumn: 5, row: 11)
world.place(Wall(), facing: south, atColumn: 2, row: 11)
world.place(Wall(), facing: south, atColumn: 3, row: 11)
world.place(Wall(), facing: south, atColumn: 4, row: 11)
world.place(Wall(), facing: south, atColumn: 2, row: 11)
world.place(Wall(), facing: south, atColumn: 3, row: 11)
world.place(Wall(), facing: south, atColumn: 4, row: 11)
world.place(Wall(), facing: south, atColumn: 5, row: 11)
world.place(Wall(), facing: north, atColumn: 4, row: 11)
world.place(Wall(), facing: north, atColumn: 3, row: 11)
world.place(Wall(), facing: north, atColumn: 2, row: 11)
world.place(Wall(), facing: south, atColumn: 1, row: 11)
world.place(Wall(), facing: south, atColumn: 11, row: 11)

world.place(Gem(), atColumn: 6, row: 1)
world.place(hopper, atColumn: 9, row: 0)
world.place(blu, atColumn: 2, row: 0)

blu.turnLeft()
blu.turnLeft()
blu.turnRight()
hopper.turnLeft()
hopper.turnLeft()
hopper.breakItDown()
hopper.turnUp()
blu.danceLikeNoOneIsWatching()
blu.argh()
blu.turnLeft()
// Oh blu, non disperarti! Magari un giorno ballerai meglio di hopper 😅🤫🤣

//#-editable-code Tap to enter code


//#-end-editable-code


//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code

