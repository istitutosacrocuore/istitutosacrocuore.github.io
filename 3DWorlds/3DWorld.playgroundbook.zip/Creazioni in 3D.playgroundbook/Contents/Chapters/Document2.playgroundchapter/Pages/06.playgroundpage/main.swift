/*:
 **Precondizione:** analizzare ed eseguire il codice
 
 **Obiettivo:** raccogliere tutte le gemme 
 * Callout(Autore):
 **Francesca Cappuccio**
 */
//#-hidden-code

//#-end-hidden-code
/*:
 - Note:
 Quando viene raccolta una gemma il giardino si arricchisce di nuovi elementi
 
 * Experiment: **Azioni ammesse**\
 Per aiutare hopper a completare l'opera prova ad utilizzare soltanto il metodo seguente:
 \
 `hopperMove(distance: Int, turning: Int)`
 */
//#-hidden-code
import Foundation

public func assessmentPoint() -> AssessmentResults {
    return .pass(message: nil)
}


public func playgroundPrologue() {
    Display.coordinateMarkers = true
    
    world.isCharacterPickerEnabled = false
    world.successCriteria = .custom(.ignoreGoals, { return false })
    registerAssessment(world, assessment: assessmentPoint)
    
    //// ----
    // Any items added or removed after this call will be animated.
    finalizeWorldBuilding(for: world)
    //// ----
}

// MARK: Epilogue

public func playgroundEpilogue() {
    sendCommands(for: world)
}

playgroundPrologue()
typealias Character = Actor
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color, array)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, hide, assessmentPoint(), playgroundPrologue(), playgroundEpilogue())
//#-code-completion(identifier, show, isOnOpenSwitch, if, func, for, while, moveForward(), turnLeft(), turnRight(), collectGem(), toggleSwitch(), isBlocked, north, south, east, west, Water, Expert, Character, (, ), (), turnLockUp(), turnLockDown(), isOnClosedSwitch, var, let, ., =, <, >, ==, !=, +=, +, -, isBlocked, move(distance:), Character, Expert, (, ), (), Portal, color:, (color:), Block, Gem, Stair, Switch, Platform, (onLevel:controlledBy:), onLevel:controlledBy:, PlatformLock, jump(), true, false, turnLock(up:numberOfTimes:), world, place(_:facing:at:), place(_:between:and:), removeBlock(atColumn:row:), isBlockedLeft, &&, ||, !, isBlockedRight, Coordinate, column:row:), (column:row:), column:row:, place(_:at:), remove(at:), insert(_:at:), removeItems(at:), append(_:), count, column(_:), row(_:), removeFirst(), removeLast(), randomInt(from:to:), removeAll(), allPossibleCoordinates, danceLikeNoOneIsWatching(), turnUp(), breakItDown(), grumbleGrumble(), argh(), coordinates(inRows:), coordinates(inColumns:intersectingRows:), name:, (name:), byte, blu, hopper, randomBool(), height(at:), movePlatforms(up:numberOfTimes:), height(at:), coordinates(inColumns:), existingGems(at:), existingSwitches(at:), existingCharacters(at:), existingExperts(at:), existingBlocks(at:), existingWater(at:), placeBlocks(at:), placeWater(at:), placeGems(at:), CharacterName, numberOfBlocks(at:), column, row)
let character = Character(name: .hopper)
var number = 4
// Analizza la funzione seguente
func move(distance: Int, turning: Int) {
    if distance != 0{
        for i in 1...distance{
            if character.isBlocked {
                character.jump()
            }else{
                character.moveForward()}
            if character.isOnGem {
                character.collectGem()
                world.placeBlocks(at: world.coordinates(inColumns: [number], intersectingRows: [5,6]))
                number += 1
                if number == 8 {
                    world.placeGems(at:
                        world.coordinates(inColumns: [5,6], intersectingRows: [6,5]))
                }
            }
            if character.isOnClosedSwitch {
                character.toggleSwitch()
                world.removeItems(at: world.coordinates(inColumns: [9], intersectingRows: [4,6]))
            }
        }
    }
    if turning != 0 {
        for i in 1...turning {
            character.turnLeft()
        }
    }
}

// Costruzione delle mura perimetrali esterne
for coordinates in world.coordinates(inRows: [0,11]) {
    world.place(Block(), at: coordinates)
}

for coordinates in world.coordinates(inColumns: [0, 11]) {
    world.place(Block(), at: coordinates)
}

// Costruzione del laghetto
for coordinates in world.coordinates(inColumns: [4,5,6,7], intersectingRows: [4,5,6,7]) {
    world.removeBlock(at: coordinates)
    world.place(Water(), at: coordinates)
}

// Costruzione delle mura perimetrali in pietra interne
for coordinates in world.coordinates(inColumns: [9,8,7,6,5,4,3,2], intersectingRows: [2]){
    world.place(Wall(), facing: north, at: coordinates)
}

for coordinates in world.coordinates(inColumns: [9], intersectingRows: [2,3,4,5,6,7,8,9]) {
    world.place(Wall(), facing: west, at: coordinates)
}

for coordinates in world.coordinates(inColumns: [9,8,7,6,5,4,3,2], intersectingRows: [9]) {
    world.place(Wall(), facing: south, at: coordinates)
}

for coordinates in world.coordinates(inColumns: [2], intersectingRows: [2,3,4,5,6,7,8,9]) {
    world.place(Wall(), facing: east, at: coordinates)
}

// Costruzione delle torri
for coordinates in world.coordinates(inColumns: [0,11], intersectingRows: [11,0]) {
    for i in 1...7 {
        world.place(Block(), at: coordinates)
    }
}

var coords1: [Coordinate] = []
var coords2: [Coordinate] = []
var coords3: [Coordinate] = []
var coords4: [Coordinate] = []

// Posizionamento dei personaggi sceilti in maniera casuale in cima alle torri
let RNG = randomInt(from: 0, to: 3)

if RNG == 0 {
    coords1 = world.coordinates(inColumns: [0], intersectingRows: [0])
    coords2 = world.coordinates(inColumns: [11], intersectingRows: [0])
    coords3 = world.coordinates(inColumns: [11], intersectingRows: [11])
    coords4 = world.coordinates(inColumns: [0], intersectingRows: [11])
}
if RNG == 1 {
    coords1 = world.coordinates(inColumns: [11], intersectingRows: [0])
    coords2 = world.coordinates(inColumns: [11], intersectingRows: [11])
    coords3 = world.coordinates(inColumns: [0], intersectingRows: [11])
    coords4 = world.coordinates(inColumns: [0], intersectingRows: [0])
}
if RNG == 3 {
    coords1 = world.coordinates(inColumns: [11], intersectingRows: [11])
    coords2 = world.coordinates(inColumns: [0], intersectingRows: [11])
    coords3 = world.coordinates(inColumns: [0], intersectingRows: [0])
    coords4 = world.coordinates(inColumns: [11], intersectingRows: [0])
}
if RNG == 2 {
    coords1 = world.coordinates(inColumns: [0], intersectingRows: [11])
    coords2 = world.coordinates(inColumns: [0], intersectingRows: [0])
    coords3 = world.coordinates(inColumns: [11], intersectingRows: [0])
    coords4 = world.coordinates(inColumns: [11], intersectingRows: [11])
}

for coordinates in coords1 {
    world.place(Expert(), at: coordinates)
}

for coordinates in coords2 {
    world.place(Character(name: .hopper), at: coordinates)
}

for coordinates in coords3 {
    world.place(Character(name: .blu), at: coordinates)
}

for coordinates in coords4 {
    world.place(Character(name: .byte), at: coordinates)
}

world.place(character, at: Coordinate(column: 3, row: 8))
world.place(Switch(), at: Coordinate(column: 9, row: 5))

for coordinates in world.coordinates(inColumns: [0,11], intersectingRows: [1,10]) {
    world.placeGems(at: [coordinates])
}

character.turnLeft()
move(distance: 6, turning: 3)
move(distance: 4, turning: 1)
move(distance: 2, turning: 3)
move(distance: 3, turning: 2)
move(distance: 9, turning: 1)
move(distance: 11, turning: 1)
move(distance: 9, turning: 1)
//#-editable-code Tap to enter code
move(distance: 10, turning: 1)
move(distance: 3, turning: 1)
move(distance: 2, turning: 3)
move(distance: 1, turning: 1)
move(distance: 4, turning: 3)
move(distance: 1, turning: 3)
move(distance: 2, turning: 0)
//#-end-editable-code
//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code

