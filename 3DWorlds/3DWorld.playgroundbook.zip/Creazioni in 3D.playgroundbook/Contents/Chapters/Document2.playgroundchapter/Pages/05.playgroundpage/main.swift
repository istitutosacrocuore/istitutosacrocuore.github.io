/*:
 **Presentazione:** un livello in cui i personaggi accettano di compiere una missione, ovvero raccogliere le gemme in cima alle torri.\
 Quando tutto sembrava oramai compiuto, i protagonisti si riuniscono per festeggiare ... ma avviene qualcosa di inaspettato: `Blu` inciampa rovinosamente causando la rimozione di tutti i blocchi, dei personaggi e dell'acqua.
 
 Toccherà proprio a `Blu` riportare l'equilibrio nel mondo!
 * Callout(Autore):
 **Domi Dean**
 */
//#-hidden-code
import Foundation

public func assessmentPoint() -> AssessmentResults {
    return .pass(message: nil)
}


public func playgroundPrologue() {
    Display.coordinateMarkers = true
    
    world.isCharacterPickerEnabled = false
    world.successCriteria = .custom(.ignoreGoals, { return false })
    registerAssessment(world, assessment: assessmentPoint)
    
    //// ----
    // Any items added or removed after this call will be animated.
    finalizeWorldBuilding(for: world)
    //// ----
}

// MARK: Epilogue

public func playgroundEpilogue() {
    sendCommands(for: world)
}

playgroundPrologue()
typealias Character = Actor
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color, array)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, hide, assessmentPoint(), playgroundPrologue(), playgroundEpilogue())
//#-code-completion(identifier, show, isOnOpenSwitch, if, func, for, while, moveForward(), turnLeft(), turnRight(), collectGem(), toggleSwitch(), isBlocked, north, south, east, west, Water, Expert, Character, (, ), (), turnLockUp(), turnLockDown(), isOnClosedSwitch, var, let, ., =, <, >, ==, !=, +=, +, -, isBlocked, move(distance:), Character, Expert, (, ), (), Portal, color:, (color:), Block, Gem, Stair, Switch, Platform, (onLevel:controlledBy:), onLevel:controlledBy:, PlatformLock, jump(), true, false, turnLock(up:numberOfTimes:), world, place(_:facing:at:), place(_:between:and:), removeBlock(atColumn:row:), isBlockedLeft, &&, ||, !, isBlockedRight, Coordinate, column:row:), (column:row:), column:row:, place(_:at:), remove(at:), insert(_:at:), removeItems(at:), append(_:), count, column(_:), row(_:), removeFirst(), removeLast(), randomInt(from:to:), removeAll(), allPossibleCoordinates, danceLikeNoOneIsWatching(), turnUp(), breakItDown(), grumbleGrumble(), argh(), coordinates(inRows:), coordinates(inColumns:intersectingRows:), name:, (name:), byte, blu, hopper, randomBool(), height(at:), movePlatforms(up:numberOfTimes:), height(at:), coordinates(inColumns:), existingGems(at:), existingSwitches(at:), existingCharacters(at:), existingExperts(at:), existingBlocks(at:), existingWater(at:), placeBlocks(at:), placeWater(at:), placeGems(at:), CharacterName, numberOfBlocks(at:), column, row)
// Costruzione piattaforme di terra esterne all'area iniziale (griglia 12*12)
for colonne in 0 ... 4 {
    for righe in -5 ... -2 {
        world.place(Block(), at:
            Coordinate(column: colonne, row: righe))
    }
}
for colonne in 8 ... 11 {
    for righe in 13 ... 15 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
}
// Spazio delle variabili, costanti e funzioni
let allCoordinates = world.allPossibleCoordinates
let expert1 = Expert()
let expert2 = Expert()
let blu = Character(name: .blu)
let hopper = Character(name: .hopper)
let byte = Character(name: .byte)

func move1(distance: Int) {
    for i in 1 ... distance {
        blu.jump()
    }
}

func move2(distance: Int) {
    for i in 1 ... distance {
        hopper.jump()
    }
}

func move3(distance: Int) {
    for i in 1 ... distance {
        byte.jump()
    }
}

var columns = world.coordinates(inColumns: [4,5,6,7])
var rows = world.coordinates(inRows: [4,5,6,7])

for allCoordinates in rows {
    world.removeBlock(at: allCoordinates)
    world.placeWater(at: [allCoordinates])
}
for allCoordinates in columns {
    world.removeBlock(at: allCoordinates)
    world.placeWater(at: [allCoordinates])
}
// Costruzione delle torri con array e cicli for

for coordinate in world.coordinates(inColumns: [11,10,9], intersectingRows: [11,10,9]) {
    for i in 1...6 {
        world.place(Block(), at: coordinate)
    }
}

for coordinate in world.coordinates(inColumns: [11, 10, 9], intersectingRows: [2, 1, 0]) {
    for i in 1...6 {
        world.place(Block(), at: coordinate)
    }
}

for coordinate in world.coordinates(inColumns: [0, 1, 2], intersectingRows: [0, 1, 2]) {
    for i in 1...6 {
        world.place(Block(), at: coordinate)
        
    }
}

for coordinate in world.coordinates(inColumns: [0, 1, 2], intersectingRows: [9, 10, 11]) {
    for i in 1...6 {
        world.place(Block(), at: coordinate)
    }
}

world.place(Block(), at: Coordinate(column: 8, row: 10))

for i in 1 ... 2 {
    world.place(Block(), at: Coordinate(column: 8, row: 9))
}

for i in 1 ... 3 {
    world.place(Block(), at: Coordinate(column: 8, row: 8))
}

for i in 1 ... 4 {
    world.place(Block(), at: Coordinate(column: 9, row: 8))
}

for i in 1 ... 5 {
    world.place(Block(), at: Coordinate(column: 10, row: 8))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: 11, row: 8))
}

for i in 1 ... 2 {
    world.place(Block(), at: Coordinate(column: 3, row: 2))
}

for i in 1 ... 3 {
    world.place(Block(), at: Coordinate(column: 3, row: 3))
}

for i in 1 ... 4 {
    world.place(Block(), at: Coordinate(column: 2, row: 3))
}

for i in 1 ... 5 {
    world.place(Block(), at: Coordinate(column: 1, row: 3))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: 0, row: 3))
}

world.place(Block(), at: Coordinate(column: 3, row: 10))

for i in 1 ... 2 {
    world.place(Block(), at: Coordinate(column: 3, row: 9))
}

for i in 1 ... 3 {
    world.place(Block(), at: Coordinate(column: 3, row: 8))
}

for i in 1 ... 4 {
    world.place(Block(), at: Coordinate(column: 2, row: 8))
}

for i in 1 ... 5 {
    world.place(Block(), at: Coordinate(column: 1, row: 8))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: 0, row: 8))
}

world.place(Block(), at: Coordinate(column: 8, row: 1))

for i in 1 ... 2 {
    world.place(Block(), at: Coordinate(column: 8, row: 2))
}

for i in 1 ... 3 {
    world.place(Block(), at: Coordinate(column: 8, row: 3))
}

for i in 1 ... 4 {
    world.place(Block(), at: Coordinate(column: 9, row: 3))
}

for i in 1 ... 5 {
    world.place(Block(), at: Coordinate(column: 10, row: 3))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: 11, row: 3))
}

world.place(Block(), at: Coordinate(column: 11, row: 2))

for i in 1 ... 2 {
    world.place(Block(), at: Coordinate(column: 11, row: 1))
}

for i in 1 ... 3 {
    world.place(Block(), at: Coordinate(column: 11, row: 0))
}

for i in 1 ... 4 {
    world.place(Block(), at: Coordinate(column: 10, row: 0))
}

for i in 1 ... 5 {
    world.place(Block(), at: Coordinate(column: 9, row: 0))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: 9, row: 1))
}

for i in 1 ... 7 {
    world.place(Block(), at: Coordinate(column: 9, row: 2))
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: 10, row: 2))
}

for i in 1 ... 9 {
    world.place(Block(), at: Coordinate(column: 10, row: 1))
}

world.place(Block(), at: Coordinate(column: 0, row: 9))

for i in 1 ... 2 {
    world.place(Block(), at: Coordinate(column: 0, row: 10))
}

for i in 1 ... 3 {
    world.place(Block(), at: Coordinate(column: 0, row: 11))
}

for i in 1 ... 4 {
    world.place(Block(), at: Coordinate(column: 1, row: 11))
}

for i in 1 ... 5 {
    world.place(Block(), at: Coordinate(column: 2, row: 11))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: 2, row: 10))
}

for i in 1 ... 7 {
    world.place(Block(), at: Coordinate(column: 2, row: 9))
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: 1, row: 9))
}

for i in 1 ... 9 {
    world.place(Block(), at: Coordinate(column: 1, row: 10))
}

world.place(Block(), at: Coordinate(column: 11, row: 9))

for i in 1 ... 2 {
    world.place(Block(), at: Coordinate(column: 11, row: 10))
}

for i in 1 ... 3 {
    world.place(Block(), at: Coordinate(column: 11, row: 11))
}

for i in 1 ... 4 {
    world.place(Block(), at: Coordinate(column: 10, row: 11))
}

for i in 1 ... 5 {
    world.place(Block(), at: Coordinate(column: 9, row: 11))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: 9, row: 10))
}

for i in 1 ... 7 {
    world.place(Block(), at: Coordinate(column: 9, row: 9))
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: 10, row: 9))
}

for i in 1 ... 9 {
    world.place(Block(), at: Coordinate(column: 10, row: 10))
}

world.place(Block(), at: Coordinate(column: 0, row: 2))

for i in 1 ... 2 {
    world.place(Block(), at: Coordinate(column: 0, row: 1))
}

for i in 1 ... 3 {
    world.place(Block(), at: Coordinate(column: 0, row: 0))
}

for i in 1 ... 4 {
    world.place(Block(), at: Coordinate(column: 1, row: 0))
}

for i in 1 ... 5 {
    world.place(Block(), at: Coordinate(column: 2, row: 0))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: 2, row: 1))
}

for i in 1 ... 7 {
    world.place(Block(), at: Coordinate(column: 2, row: 2))
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: 1, row: 2))
}

for i in 1 ... 9 {
    world.place(Block(), at: Coordinate(column: 1, row: 1))
}

// Posizionamento delle genme in cima alle torri
world.placeGems(at: [Coordinate(column: 1, row: 1)])
world.placeGems(at: [Coordinate(column: 10, row: 1)])
world.placeGems(at: [Coordinate(column: 10, row: 10)])
world.placeGems(at: [Coordinate(column: 1, row: 10)])

// Posizionamento  dei personaggi
world.place(expert1, facing: north, at: Coordinate(column: 3, row: 0))
world.place(byte, facing: north, at: Coordinate(column: 8, row: 0))
world.place(blu, facing: south, at: Coordinate(column: 3, row: 11))
world.place(hopper, facing: south, at: Coordinate(column: 8, row: 11))

/* Svolgimento della missione: i personaggi arriverrano in cima alle torri per raccoglie le gemme, con Expert che si serverà di un suo clone per raggiungere l'obiettivo
 */

for i in 1 ... 3 {
    move1(distance: 3)
    blu.turnRight()
}

for i in 1 ... 2 {
    move1(distance: 2)
    blu.turnRight()
}

blu.jump()
blu.turnRight()
blu.jump()
blu.collectGem()
blu.danceLikeNoOneIsWatching()

for i in 1 ... 3 {
    move2(distance: 3)
    hopper.turnLeft()
}

for i in 1 ... 2 {
    move2(distance: 2)
    hopper.turnLeft()
}

hopper.jump()
hopper.turnLeft()
hopper.jump()
hopper.collectGem()
hopper.danceLikeNoOneIsWatching()

for i in 1 ... 3 {
    move3(distance: 3)
    byte.turnRight()
}

for i in 1 ... 2 {
    move3(distance: 2)
    byte.turnRight()
}

byte.jump()
byte.turnRight()
byte.jump()
byte.collectGem()
byte.danceLikeNoOneIsWatching()
expert1.grumbleGrumble()

let platformlockblack = PlatformLock(color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0))
world.place(platformlockblack, facing: south, at: Coordinate(column: 3, row: 1))
world.place(Platform(onLevel: 2, controlledBy: platformlockblack), at: Coordinate(column: 4, row: 1))
world.place(expert2, facing: west, at: Coordinate(column: 4, row: 1))

for i in 1 ... 15 {
    expert1.turnLockUp()
}
expert1.argh()

for i in 1 ... 15 {
    world.place(Block(), at: Coordinate(column: 3, row: 1))
}
expert1.argh()

for i in 1 ... 3 {
    world.place(Block(), at: Coordinate(column: 2, row: 1))
}

world.removeItems(at: Coordinate(column: 3, row: 1))
world.removeItems(at: Coordinate(column: 3, row: 0))

for i in 1 ... 3 {
    expert2.moveForward()
}

expert2.collectGem()
expert2.danceLikeNoOneIsWatching()

// Al completamento del livello, i quattro personaggi si riuniscono danzando
world.place(Platform(), at: Coordinate(column: 4, row: 4))
world.place(Platform(), at: Coordinate(column: 7, row: 4))
world.place(Platform(), at: Coordinate(column: 7, row: 7))
world.place(Platform(), at: Coordinate(column: 4, row: 7))
world.place(hopper, facing: south, at: Coordinate(column: 7, row: 7))
world.place(blu, facing: south, at: Coordinate(column: 4, row: 7))
world.place(expert2, facing: north, at: Coordinate(column: 4, row: 4))
world.place(byte, facing: north, at: Coordinate(column: 7, row: 4))
hopper.danceLikeNoOneIsWatching()
expert2.danceLikeNoOneIsWatching()
byte.danceLikeNoOneIsWatching()

// Blu inciampa rovinosamente causando la rimozione di tutti i blocchi, dei personaggi e dell'acqua
blu.argh()
for i in 1 ... 17 {
    for coordinate in allCoordinates {
        world.removeBlock(at: coordinate)
    }
}

for i in 1 ... 2 {
    for coordinate in allCoordinates {
        world.removeItems(at: coordinate)
    }
}

// Selezione delle coordinate per la generazione di un nuovo panorama
for coordinate in allCoordinates {
    world.place(Block(), at: coordinate)
}

var heights: [Int] = [3,8,2,1,7,5,4,6,10,9]

var index = 0
for coordinate in allCoordinates {
    if index == heights.count {
        index = 0
    }
    for i in 0...heights[index] {
        world.place(Block(), at: coordinate)
    }
    index += 1
}

// Finamelmente Blu ha riportato l'equilibrio nel mondo!

//#-editable-code Tap to enter code


//#-end-editable-code

//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code


