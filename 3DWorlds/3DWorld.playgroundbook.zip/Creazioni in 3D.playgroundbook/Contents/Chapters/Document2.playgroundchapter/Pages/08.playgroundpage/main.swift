/*:
 **Precondizione:** analizzare ed eseguire il codice
 
 **Obiettivo:** collezionare tutte le gemme e creare una coreografia di danza!

* Callout(Autore):
**Luisa Genovese**
 */
//#-hidden-code

//#-end-hidden-code
/*:
 * Callout(💡 Suggerimenti):
 Oltre a creare un array per inserire nuovi elementi, puoi crearlo anche a partire dagli elementi già esistenti nel mondo di un livello.\
  `let characters = world.existingCharacters(at: allCoordinates)`\
 Con l'array di personaggi di cui sopra, puoi effettuare un'iterazione su ogni personaggio, dandogli comandi come ad esempio `jump()` (salta) o persino chiedendogli di farti vedere come balla!
 */
//#-hidden-code

//#-end-hidden-code
/*:
 * callout(Esibisciti!): Prova a richiamare questi metodi per ogni personaggio presente nel tuo array di personaggi:\
 `danceLikeNoOneIsWatching()`\
 `turnUp()`\
 `breakItDown()`\
 `grumbleGrumble()`\
 `argh()`
 */
//#-hidden-code
import Foundation

public func assessmentPoint() -> AssessmentResults {
    return .pass(message: nil)
}


public func playgroundPrologue() {
    Display.coordinateMarkers = true
    
    world.isCharacterPickerEnabled = false
    world.successCriteria = .custom(.ignoreGoals, { return false })
    registerAssessment(world, assessment: assessmentPoint)
    
    //// ----
    // Any items added or removed after this call will be animated.
    finalizeWorldBuilding(for: world)
    //// ----
}

// MARK: Epilogue

public func playgroundEpilogue() {
    sendCommands(for: world)
}

playgroundPrologue()
typealias Character = Actor
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color, array)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, hide, assessmentPoint(), playgroundPrologue(), playgroundEpilogue())
//#-code-completion(identifier, show, isOnOpenSwitch, if, func, for, while, moveForward(), turnLeft(), turnRight(), collectGem(), toggleSwitch(), isBlocked, north, south, east, west, Water, Expert, Character, (, ), (), turnLockUp(), turnLockDown(), isOnClosedSwitch, var, let, ., =, <, >, ==, !=, +=, +, -, isBlocked, move(distance:), Character, Expert, (, ), (), Portal, color:, (color:), Block, Gem, Stair, Switch, Platform, (onLevel:controlledBy:), onLevel:controlledBy:, PlatformLock, jump(), true, false, turnLock(up:numberOfTimes:), world, place(_:facing:at:), place(_:between:and:), removeBlock(atColumn:row:), isBlockedLeft, &&, ||, !, isBlockedRight, Coordinate, column:row:), (column:row:), column:row:, place(_:at:), remove(at:), insert(_:at:), removeItems(at:), append(_:), count, column(_:), row(_:), removeFirst(), removeLast(), randomInt(from:to:), removeAll(), allPossibleCoordinates, danceLikeNoOneIsWatching(), turnUp(), breakItDown(), grumbleGrumble(), argh(), coordinates(inRows:), coordinates(inColumns:intersectingRows:), name:, (name:), byte, blu, hopper, randomBool(), height(at:), movePlatforms(up:numberOfTimes:), height(at:), coordinates(inColumns:), existingGems(at:), existingSwitches(at:), existingCharacters(at:), existingExperts(at:), existingBlocks(at:), existingWater(at:), placeBlocks(at:), placeWater(at:), placeGems(at:), CharacterName, numberOfBlocks(at:), column, row)
// Inizializzazione dell'array "allCoordinates" con tutte le coordinate presenti nel mondo del livello
let allCoordinates = world.allPossibleCoordinates
// Inizializzazione degli array di coordinate
var island : [Coordinate] = []
var sea : [Coordinate] = []


// Creazione dell'isola e del mare
for coordinate in allCoordinates {
    if coordinate.row > 0 && coordinate.column < 11 &&
    coordinate.column < 9 && coordinate.row > 0 && coordinate.row < 7 {
        island.append(coordinate)
    }
    else {
        sea.append(coordinate)
    }
}

for allCoordinates in island {
    world.place(Block(), at: allCoordinates)
}


for allCoordinates in sea  {
    world.removeAllBlocks(at: allCoordinates)
    world.place(Water(), at: allCoordinates)
}
// Inizializzazione di portali e personaggi
let portale = Portal(color: #colorLiteral(red: 0.8078431487083435, green: 0.027450980618596077, blue: 0.3333333432674408, alpha: 1.0))
let portale2 = Portal(color: #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1))
let character = Character()
let hopper = Character(name: .hopper)
let hopper1 = Character(name: .hopper)
let hopper2 = Character(name: .hopper)
let expert = Expert()
let expert1 = Expert()
let expert2 = Expert()
let expert3 = Expert()
let expert4 = Expert()
let expert5 = Expert()
let expert6 = Expert()

// Posizionamento dei blocchi per la costruzione dei cubi (I fila)
world.place(Block(), atColumn: 2, row: 2)
world.place(Block(), atColumn: 2, row: 2)
world.place(character, atColumn: 7, row: 1)
world.place(Block(), atColumn: 6, row: 2)
world.place(Block(), atColumn: 6, row: 2)
world.place(Block(), atColumn: 4, row: 2)

world.place(Block(), atColumn: 4, row: 2)
world.place(Block(), atColumn: 2, row: 2)
world.place(Block(), atColumn: 4, row: 2)
world.place(Block(), atColumn: 6, row: 2)
world.place(Block(), atColumn: 2, row: 2)
world.place(Block(), atColumn: 4, row: 2)
world.place(Block(), atColumn: 6, row: 2)

// Posizionamento di gemme, portali, piattaforme e personaggi
world.place(Gem(), atColumn: 5, row: 2)
world.place(Gem(), atColumn: 5, row: 3)
world.place(Gem(), atColumn: 5, row: 4)
world.place(Gem(), atColumn: 5, row: 5)
world.place(Gem(), atColumn: 3, row: 2)
world.place(Gem(), atColumn: 3, row: 3)
world.place(Gem(), atColumn: 3, row: 4)
world.place(Gem(), atColumn: 3, row: 5)

world.place(portale, between: Coordinate(column: 4, row: 10), and: Coordinate(column: 8, row: 6))
world.place(portale2, between: Coordinate(column: 0, row: 6), and: Coordinate(column: 5, row: 10))

world.place(Platform(), at: Coordinate(column: 0, row: 4))
world.place(Platform(), at: Coordinate(column: 8, row: 4))
world.place(hopper, atColumn: 0, row: 4)
world.place(hopper1, atColumn: 8, row: 4)
world.place(Platform(), at: Coordinate(column: 4, row: 2))
world.place(hopper2, atColumn: 4, row: 2)

// Costruzione dell'isoletta laterale
for i in 1...3 {
    for colonne in 8 ... 11 {
        for righe in 13 ... 15 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}
    
world.place(Block(), atColumn: 9, row: 13)
world.place(Block(), atColumn: 10, row: 13)
world.place(Block(), atColumn: 11, row: 13)
world.place(Block(), atColumn: 11, row: 14)
world.place(Block(), atColumn: 9, row: 14)
world.place(Block(), atColumn: 8, row: 14)
world.place(Block(), atColumn: 11, row: 15)
world.place(Block(), atColumn: 10, row: 15)
world.place(Block(), atColumn: 8, row: 15)
world.place(Block(), atColumn: 11, row: 13)
world.place(Block(), atColumn: 10, row: 13)
world.place(Block(), atColumn: 11, row: 13)
world.place(Block(), atColumn: 9, row: 13)
world.place(Block(), atColumn: 10, row: 13)
world.place(Block(), atColumn: 11, row: 13)

// Posizionamento delle piattaforme
world.place(Platform(), at: Coordinate(column: 6, row: 2))
world.place(Platform(), at: Coordinate(column: 2, row: 2))
world.place(Platform(), at: Coordinate(column: 11, row: 13))
world.place(Platform(), at: Coordinate(column: 10, row: 15))
world.place(Platform(), at: Coordinate(column: 8, row: 14))

// Posizionamento degli Expert sulle piattaforme
world.place(expert, at: Coordinate(column: 2, row: 2))
world.place(expert1, at: Coordinate(column: 6, row: 2))
world.place(expert2, at: Coordinate(column: 11, row: 13))
world.place(expert3, at: Coordinate(column: 10, row: 15))
world.place(expert4, at: Coordinate(column: 8, row: 14))

// Costruzione del muro
world.place(Wall(), facing: west, atColumn: 6, row: 1)
world.place(Wall(), facing: east, atColumn: 8, row: 1)

// Posizionamento dei blocchi per la costruzione dei cubi (II fila)
world.place(Block(), atColumn: 6, row: 6)
world.place(Block(), atColumn: 6, row: 6)
world.place(Block(), atColumn: 6, row: 6)
world.place(Block(), atColumn: 4, row: 6)
world.place(Block(), atColumn: 4, row: 6)
world.place(Block(), atColumn: 4, row: 6)

// Posizionamento delle piattaforme e di expert su di esse
world.place(Platform(), at: Coordinate(column: 6, row: 6))
world.place(expert5, at: Coordinate(column: 6, row: 6))
world.place(Platform(), at: Coordinate(column: 4, row: 6))
world.place(expert6, at: Coordinate(column: 4, row: 6))
var colonne = world.coordinates(inColumns: [0, 11])
var righe = world.coordinates(inRows: [11, 10])

for allCoordinates in righe{world.place(Block(), at: allCoordinates)}

// Posizionamento delle piattaforme
world.place(Platform(), at: Coordinate(column: 0, row: 10))
world.place(Platform(), at: Coordinate(column: 11, row: 10))

//#-editable-code Tocca per inserire il codice

//#-end-editable-code
//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code
