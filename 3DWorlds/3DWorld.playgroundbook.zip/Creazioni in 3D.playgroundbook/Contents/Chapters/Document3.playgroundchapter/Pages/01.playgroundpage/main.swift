/*:
 **Sfida:** ricostruire il mondo di seguito proposto e completare il livello.
 
Ciascun personaggio dovrà attraversare il portale del suo stesso colore per salire in cima alla torre e raccogliere le gemme
 */
//#-hidden-code

//#-end-hidden-code
/*:
 
 * Callout(Vista dall'alto N.1):
 **Torri** - Altezza: 10 - Base: 4X4
 */
//#-hidden-code

//#-end-hidden-code
/*:
 ![screenshot N.1?](template1.jpg)
 */
//#-hidden-code

//#-end-hidden-code
/*:
 * Callout(Vista dall'alto N.2):
 **Passarelle** - Lunghezza: 5 - Larghezza: 2 - Distanza dalle torri: 2
 */
//#-hidden-code

//#-end-hidden-code
/*:
 ![screenshot N.2?](template2.jpg)
 */
//#-hidden-code

//#-end-hidden-code
/*:
 * Callout(Autore):
 **Marco Jin**
 */
//#-hidden-code

//#-end-hidden-code
/*:
 * Experiment: **Download**\
 Puoi anche scaricare le viste\
 Vista N.1 [fai un tap qui](https://istitutosacrocuore.github.io/3DWorlds/template1.jpg)\
 Vista N.2 [fai un tap qui](https://istitutosacrocuore.github.io/3DWorlds/template2.jpg)
*/
//#-hidden-code
import Foundation

public func assessmentPoint() -> AssessmentResults {
    return .pass(message: nil)
}


public func playgroundPrologue() {
    Display.coordinateMarkers = true
    
    world.isCharacterPickerEnabled = false
    world.successCriteria = .custom(.ignoreGoals, { return false })
    registerAssessment(world, assessment: assessmentPoint)
    
    //// ----
    // Any items added or removed after this call will be animated.
    finalizeWorldBuilding(for: world)
    //// ----
}

// MARK: Epilogue

public func playgroundEpilogue() {
    sendCommands(for: world)
}

playgroundPrologue()
typealias Character = Actor
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color, array)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, hide, assessmentPoint(), playgroundPrologue(), playgroundEpilogue())
//#-code-completion(identifier, show, isOnOpenSwitch, if, func, for, while, moveForward(), turnLeft(), turnRight(), collectGem(), toggleSwitch(), isBlocked, north, south, east, west, Water, Expert, Character, (, ), (), turnLockUp(), turnLockDown(), isOnClosedSwitch, var, let, ., =, <, >, ==, !=, +=, +, -, isBlocked, move(distance:), Character, Expert, (, ), (), Portal, color:, (color:), Block, Gem, Stair, Switch, Platform, (onLevel:controlledBy:), onLevel:controlledBy:, PlatformLock, jump(), true, false, turnLock(up:numberOfTimes:), world, place(_:facing:at:), place(_:between:and:), removeBlock(atColumn:row:), isBlockedLeft, &&, ||, !, isBlockedRight, Coordinate, column:row:), (column:row:), column:row:, place(_:at:), remove(at:), insert(_:at:), removeItems(at:), append(_:), count, column(_:), row(_:), removeFirst(), removeLast(), randomInt(from:to:), removeAll(), allPossibleCoordinates, danceLikeNoOneIsWatching(), turnUp(), breakItDown(), grumbleGrumble(), argh(), coordinates(inRows:), coordinates(inColumns:intersectingRows:), name:, (name:), byte, blu, hopper, randomBool(), height(at:), movePlatforms(up:numberOfTimes:), height(at:), coordinates(inColumns:), existingGems(at:), existingSwitches(at:), existingCharacters(at:), existingExperts(at:), existingBlocks(at:), existingWater(at:), placeBlocks(at:), placeWater(at:), placeGems(at:), CharacterName, numberOfBlocks(at:), column, row)
//#-editable-code Tocca per inserire il codice



//#-end-editable-code


//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code

