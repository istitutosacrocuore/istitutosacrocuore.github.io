/*:
 **Precondizione:** analizzare ed eseguire il codice
 
 **Obiettivo:** raccogliere la gemma e attivare tutti gli interruttori spenti in cima alle torri, utlizzando `Expert` per il sollevamento delle piattaforme
 
* Callout(Autore):
**Luca Petroccione**
 */
//#-hidden-code

//#-end-hidden-code
/*:
* Experiment: **Oggetti nascosti nel codice**\
Questo esempio mostra come posizionare un muro di pietra scegliendo l'orientamento:
 \
 `world.place(Wall(), facing: Direction?, at: Coordinate)`\
Valori ammessi per il parametro `facing`: `west`, `east`, `north`, `south`
 - Note:
 L'oggetto `Wall()` non compare tra i suggerimenti nella *barra delle abbreviazioni* che suggerisce i comandi in modo intelligente
 */
//#-hidden-code
import Foundation

public func assessmentPoint() -> AssessmentResults {
    return .pass(message: nil)
}


public func playgroundPrologue() {
    Display.coordinateMarkers = true
    
    world.isCharacterPickerEnabled = false
    world.successCriteria = .custom(.ignoreGoals, { return false })
    registerAssessment(world, assessment: assessmentPoint)
    
    //// ----
    // Any items added or removed after this call will be animated.
    finalizeWorldBuilding(for: world)
    //// ----
}

// MARK: Epilogue

public func playgroundEpilogue() {
    sendCommands(for: world)
}

playgroundPrologue()
typealias Character = Actor
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color, array)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, hide, assessmentPoint(), playgroundPrologue(), playgroundEpilogue())
//#-code-completion(identifier, show, isOnOpenSwitch, if, func, for, while, moveForward(), turnLeft(), turnRight(), collectGem(), toggleSwitch(), isBlocked, north, south, east, west, Water, Expert, Character, (, ), (), turnLockUp(), turnLockDown(), isOnClosedSwitch, var, let, ., =, <, >, ==, !=, +=, +, -, isBlocked, move(distance:), Character, Expert, (, ), (), Portal, color:, (color:), Block, Gem, Stair, Switch, Platform, (onLevel:controlledBy:), onLevel:controlledBy:, PlatformLock, jump(), true, false, turnLock(up:numberOfTimes:), world, place(_:facing:at:), place(_:between:and:), removeBlock(atColumn:row:), isBlockedLeft, &&, ||, !, isBlockedRight, Coordinate, column:row:), (column:row:), column:row:, place(_:at:), remove(at:), insert(_:at:), removeItems(at:), append(_:), count, column(_:), row(_:), removeFirst(), removeLast(), randomInt(from:to:), removeAll(), allPossibleCoordinates, danceLikeNoOneIsWatching(), turnUp(), breakItDown(), grumbleGrumble(), argh(), coordinates(inRows:), coordinates(inColumns:intersectingRows:), name:, (name:), byte, blu, hopper, randomBool(), height(at:), movePlatforms(up:numberOfTimes:), height(at:), coordinates(inColumns:), existingGems(at:), existingSwitches(at:), existingCharacters(at:), existingExperts(at:), existingBlocks(at:), existingWater(at:), placeBlocks(at:), placeWater(at:), placeGems(at:), CharacterName, numberOfBlocks(at:), column, row)
// Rimozione dei blocchi e posizionamento dell'acqua intorno alla Torre N.1
for coordinate in world.coordinates(inColumns: [3], intersectingRows: [0,1,2,3]){
    world.removeBlock(atColumn: coordinate.column, row: coordinate.row)
    world.placeWater(at: [Coordinate(column:coordinate.column, row: coordinate.row)])
}

for coordinate in world.coordinates(inColumns: [0,1,2], intersectingRows: [3]){
    world.removeBlock(atColumn: coordinate.column, row: coordinate.row)
    world.placeWater(at: [Coordinate(column:coordinate.column, row: coordinate.row)])
}

// Costruzione della Torre N.1 (monca)
for coordinate in world.coordinates(inColumns: [0, 1, 2], intersectingRows: [0, 1, 2]) {
    for i in 1...2 {
        world.place(Block(), at: coordinate)
    }
}

for coordinate in world.coordinates(inColumns: [0, 1], intersectingRows: [0, 1]) {
    for i in 1...2 {
        world.place(Block(), at: coordinate)
    }
}

// Selezione delle coordinate per il posizionamento dei muri di pietra
for coordinate in world.coordinates(inColumns: [0,1], intersectingRows: [1,0]) {
    for i in 1...2 {
        world.place(Wall(), facing: west, at: coordinate)
    }
}

// Posizionamento della gemma in cima alla Torre N.1
world.place(Gem(), at: Coordinate(column: 0, row: 0))

// Rimozione dei blocchi e posizionamento dell'acqua intorno alla Torre N.2
for coordinate in world.coordinates(inColumns: [8,9,10,11], intersectingRows: [3]){
    world.removeBlock(atColumn: coordinate.column, row: coordinate.row)
    world.placeWater(at: [Coordinate(column:coordinate.column, row: coordinate.row)])
}

for coordinate in world.coordinates(inColumns: [8], intersectingRows: [0,1,2]){
    world.removeBlock(atColumn: coordinate.column, row: coordinate.row)
    world.placeWater(at: [Coordinate(column:coordinate.column, row: coordinate.row)])
}

// Costruzione della Torre N.2
for coordinate in world.coordinates(inColumns: [11,10,9], intersectingRows: [0, 1, 2]) {
    for i in 1...2 {
        world.place(Block(), at: coordinate)
    }
}

for coordinate in world.coordinates(inColumns: [10,11], intersectingRows: [0, 1]) {
    for i in 1...8 {
        world.place(Block(), at: coordinate)
    }
}

// Posizionamento dello switch in cima alla Torre N.2
world.place(Switch(), at: Coordinate(column: 11, row: 0))

// Rimozione dei blocchi e posizionamento dell'acqua intorno alla Torre N.3
for coordinate in world.coordinates(inColumns: [8], intersectingRows: [8,9,10,11]){
    world.removeBlock(atColumn: coordinate.column, row: coordinate.row)
    world.placeWater(at: [Coordinate(column:coordinate.column, row: coordinate.row)])
}

for coordinate in world.coordinates(inColumns: [9,10,11], intersectingRows: [8]){
    world.removeBlock(atColumn: coordinate.column, row: coordinate.row)
    world.placeWater(at: [Coordinate(column:coordinate.column, row: coordinate.row)])
}

// Costruzione della Torre N.3
for coordinate in world.coordinates(inColumns: [9,10,11], intersectingRows: [9,10,11]) {
    for i in 1...2 {
        world.place(Block(), at: coordinate)
    }
}

for coordinate in world.coordinates(inColumns: [10,11], intersectingRows: [10, 11]) {
    for i in 1...8 {
        world.place(Block(), at: coordinate)
    }
}

// Posizionamento dello switch in cima alla Torre N.3
world.place(Switch(), at: Coordinate(column: 11, row: 11))

// Rimozione dei blocchi e posizionamento dell'acqua intorno alla Torre N.4
for coordinate in world.coordinates(inColumns: [0,1,2,3], intersectingRows: [8]){
    world.removeBlock(atColumn: coordinate.column, row: coordinate.row)
    world.placeWater(at: [Coordinate(column:coordinate.column, row: coordinate.row)])
}

for coordinate in world.coordinates(inColumns: [3], intersectingRows: [9,10,11]){
    world.removeBlock(atColumn: coordinate.column, row: coordinate.row)
    world.placeWater(at: [Coordinate(column:coordinate.column, row: coordinate.row)])
}

// Costruzione della Torre N.4
for coordinate in world.coordinates(inColumns: [0,1,2], intersectingRows: [11,10,9]) {
    for i in 1...2 {
        world.place(Block(), at: coordinate)
    }
}

for coordinate in world.coordinates(inColumns: [0,1], intersectingRows: [10, 11]) {
    for i in 1...8 {
        world.place(Block(), at: coordinate)
    }
}

// Posizionamento dello switch in cima alla Torre N.4
world.place(Switch(), at: Coordinate(column: 0, row: 11))

for coordinates in world.coordinates(inRows: [4,5,6,7]){
    world.removeBlock(at: coordinates)
    world.placeWater(at: [coordinates])
}

for coordinates in world.coordinates(inColumns: [3,8]){
    world.removeBlock(at: coordinates)
    world.placeWater(at: [coordinates])
}

// Inizializzazione e posizionamento delle piattaforme
let squareLock = PlatformLock(color: #colorLiteral(red: 0.46666666865348816, green: 0.7647058963775635, blue: 0.2666666805744171, alpha: 1.0))
world.place(squareLock, facing: east, at: Coordinate(column: 4, row: 9))
let cornerLock = PlatformLock(color: .red)
world.place(cornerLock, facing: west, at: Coordinate(column: 7 , row: 10))
let backLock = PlatformLock(color: .blue)
world.place(backLock, at: Coordinate(column: 5, row: 3))
let upLock = PlatformLock(color:.pink )
world.place(upLock, facing: north,at: Coordinate(column: 6, row: 0))
world.place(Platform(onLevel: 2, controlledBy: cornerLock), at: Coordinate(column: 11, row: 9))
world.place(Platform(onLevel: 2, controlledBy: squareLock), at: Coordinate(column: 9, row: 0))
world.place(Platform(onLevel: 2, controlledBy: backLock), at: Coordinate(column: 0, row: 2))

// Inizializzazione e posizionamento dei portali
let portal = Portal(color: #colorLiteral(red: 0.9254902005195618, green: 0.23529411852359772, blue: 0.10196078568696976, alpha: 1.0))
world.place(portal, atStartColumn: 1, startRow: 1, atEndColumn: 9, endRow: 11)
let portal2 = Portal(color: #colorLiteral(red: 0.4028071761, green: 0.7315050364, blue: 0.2071235478, alpha: 1))
world.place(portal2, atStartColumn: 10, startRow: 11, atEndColumn: 11, endRow: 2)
let portal3 = Portal(color: #colorLiteral(red: 0.8549019694328308, green: 0.250980406999588, blue: 0.47843137383461, alpha: 1.0))
world.place(portal3, atStartColumn: 11, startRow: 1, atEndColumn: 0, endRow: 9)
let portal4 = Portal(color: #colorLiteral(red: 0.239215686917305, green: 0.6745098233222961, blue: 0.9686274528503418, alpha: 1.0))
world.place(portal4, atStartColumn: 0, startRow: 10, atEndColumn: 2, endRow: 2)
let portal5 = Portal(color: #colorLiteral(red: 0.9607843160629272, green: 0.7058823704719543, blue: 0.20000000298023224, alpha: 1.0))
world.place(portal5, atStartColumn: 6, startRow: 11, atEndColumn: 7, endRow: 1)
let squarLock = world.place(Platform(onLevel: 2, controlledBy: upLock), at:Coordinate(column: 2, row: 11))

// Posizionamento delle scale
world.place(Stair(), facing: north,at: Coordinate(column: 9, row: 1))
world.place(Stair(), facing: south,at: Coordinate(column: 2, row: 10))
world.place(Stair(), facing: west,at: Coordinate(column: 10, row: 9))
world.place(Stair(), facing: east,at: Coordinate(column: 1, row: 2))

// Inizializzazione e posizionamento dei personaggi
let hopper = Character(name: .hopper)
world.place(hopper, facing: north,at: Coordinate(column: 1, row: 0))
let expert = Expert()
world.place(expert, facing: south, at: Coordinate(column: 5, row: 11))

//#-editable-code Tap to enter code

//#-end-editable-code


//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code
