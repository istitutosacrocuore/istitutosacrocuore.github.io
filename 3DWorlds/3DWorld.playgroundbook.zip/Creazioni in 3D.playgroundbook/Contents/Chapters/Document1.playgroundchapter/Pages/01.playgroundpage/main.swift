/*:
 **Precondizione:** analizzare ed eseguire il codice
 
 **Sfida:** prima di raccogliere le gemme, prova ad ottimizzare il codice e a correggere gli errori semantici
 
 * Callout(Autore):
 **Marco Li**
 */
//#-hidden-code

//#-end-hidden-code
/*:
 * Callout(💡 Suggerimenti):
    1. Nel ciclo `for` utilizzato per rimuovere i blocchi e posizionare l'acqua basta usare solo 2 istruzioni! Sapresti individuare quali?
    2. Si potrebbero gestire in maniera più efficiente i blocchi di codice per la selezione delle coordinate?
    3. C'è qualcosa che non va nel posizionamento dei portali (gestione dei punti di ingresso ed uscita). E' necessario correggere l'errore semantico per permettere ad `Hopper` di potere attraversare il labirinto
*/
//#-hidden-code
import Foundation

public func assessmentPoint() -> AssessmentResults {
    return .pass(message: nil)
}


public func playgroundPrologue() {
    Display.coordinateMarkers = true
    
    world.isCharacterPickerEnabled = false
    world.successCriteria = .custom(.ignoreGoals, { return false })
    registerAssessment(world, assessment: assessmentPoint)
    
    //// ----
    // Any items added or removed after this call will be animated.
    finalizeWorldBuilding(for: world)
    //// ----
}

// MARK: Epilogue

public func playgroundEpilogue() {
    sendCommands(for: world)
}

playgroundPrologue()
typealias Character = Actor
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color, array)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, hide, assessmentPoint(), playgroundPrologue(), playgroundEpilogue())
//#-code-completion(identifier, show, isOnOpenSwitch, if, func, for, while, moveForward(), turnLeft(), turnRight(), collectGem(), toggleSwitch(), isBlocked, north, south, east, west, Water, Expert, Character, (, ), (), turnLockUp(), turnLockDown(), isOnClosedSwitch, var, let, ., =, <, >, ==, !=, +=, +, -, isBlocked, move(distance:), Character, Expert, (, ), (), Portal, color:, (color:), Block, Gem, Stair, Switch, Platform, (onLevel:controlledBy:), onLevel:controlledBy:, PlatformLock, jump(), true, false, turnLock(up:numberOfTimes:), world, place(_:facing:at:), place(_:between:and:), removeBlock(atColumn:row:), isBlockedLeft, &&, ||, !, isBlockedRight, Coordinate, column:row:), (column:row:), column:row:, place(_:at:), remove(at:), insert(_:at:), removeItems(at:), append(_:), count, column(_:), row(_:), removeFirst(), removeLast(), randomInt(from:to:), removeAll(), allPossibleCoordinates, danceLikeNoOneIsWatching(), turnUp(), breakItDown(), grumbleGrumble(), argh(), coordinates(inRows:), coordinates(inColumns:intersectingRows:), name:, (name:), byte, blu, hopper, randomBool(), height(at:), movePlatforms(up:numberOfTimes:), height(at:), coordinates(inColumns:), existingGems(at:), existingSwitches(at:), existingCharacters(at:), existingExperts(at:), existingBlocks(at:), existingWater(at:), placeBlocks(at:), placeWater(at:), placeGems(at:), CharacterName, numberOfBlocks(at:), column, row)
//#-editable-code
// Selezione delle coordinate nella griglia per l'acqua
var sea : [Coordinate] = []
sea.append(Coordinate(column: 6, row: 5))
sea.append(Coordinate(column: 5, row: 5))
sea.append(Coordinate(column: 6, row: 6))
sea.append(Coordinate(column: 5, row: 6))
sea.append(Coordinate(column: 6, row: 7))
sea.append(Coordinate(column: 5, row: 7))
sea.append(Coordinate(column: 4, row: 6))
sea.append(Coordinate(column: 4, row: 5))
sea.append(Coordinate(column: 5, row: 4))
sea.append(Coordinate(column: 6, row: 4))
sea.append(Coordinate(column: 7, row: 5))
sea.append(Coordinate(column: 7, row: 6))
sea.append(Coordinate(column: 6, row: 9))
sea.append(Coordinate(column: 5, row: 9))
sea.append(Coordinate(column: 2, row: 6))
sea.append(Coordinate(column: 2, row: 5))
sea.append(Coordinate(column: 5, row: 2))
sea.append(Coordinate(column: 6, row: 2))
sea.append(Coordinate(column: 9, row: 5))
sea.append(Coordinate(column: 9, row: 6))
 
// Rimozione dei blocchi per il posizionamento dell'acqua
for coordinate in sea{
    world.removeBlock(atColumn: 6, row: 5)
    world.place(Water(), at: coordinate)
    world.removeBlock(atColumn: 5, row:5 )
    world.place(Water(), at: coordinate)
    world.removeBlock(atColumn: 6, row: 6)
    world.place(Water(), at:coordinate)
    world.removeBlock(atColumn: 5, row: 6)
    world.place(Water(), at:coordinate)
    world.removeBlock(atColumn: 6, row: 7)
    world.place(Water(), at:coordinate)
    world.removeBlock(atColumn: 5, row: 7)
    world.place(Water(), at:coordinate)
    world.removeBlock(atColumn: 4, row: 6)
    world.place(Water(), at:coordinate)
    world.removeBlock(atColumn: 4, row: 5)
    world.place(Water(), at:coordinate)
    world.removeBlock(atColumn: 5, row: 4)
    world.place(Water(), at:coordinate)
    world.removeBlock(atColumn: 6, row: 4)
    world.place(Water(), at:coordinate)
    world.removeBlock(atColumn: 7, row: 5)
    world.place(Water(), at:coordinate)
    world.removeBlock(atColumn: 7, row: 6)
    world.place(Water(), at:coordinate)
    world.removeBlock(atColumn: 6, row: 9)
    world.place(Water(), at:coordinate)
    world.removeBlock(atColumn: 5, row: 9)
    world.place(Water(), at:coordinate)
    world.removeBlock(atColumn: 2, row: 6)
    world.place(Water(), at:coordinate)
    world.removeBlock(atColumn: 2, row: 5)
    world.place(Water(), at:coordinate)
    world.removeBlock(atColumn: 5, row: 2)
    world.place(Water(), at:coordinate)
    world.removeBlock(atColumn: 6, row: 2)
    world.place(Water(), at:coordinate)
    world.removeBlock(atColumn: 9, row: 5)
    world.place(Water(), at:coordinate)
    world.removeBlock(atColumn: 9, row: 6)
}

// Selezione delle coordinate nella griglia per il posizionamento dei blocchi verticali
let corners = [
    Coordinate(column: 7, row: 4),
    Coordinate(column: 8, row: 3),
    Coordinate(column: 9, row: 2),
    Coordinate(column: 10, row: 1),
    Coordinate(column: 11, row: 0),
    Coordinate(column: 7, row: 7),
    Coordinate(column: 8, row: 8),
    Coordinate(column: 9, row: 9),
    Coordinate(column: 10, row: 10),
    Coordinate(column: 11, row: 11),
    Coordinate(column: 4, row: 7),
    Coordinate(column: 3, row: 8),
    Coordinate(column: 2, row: 9),
    Coordinate(column: 1, row: 10),
    Coordinate(column: 0, row: 11),
    Coordinate(column: 4, row: 4),
    Coordinate(column: 3, row: 3),
    Coordinate(column: 2, row: 2),
    Coordinate(column: 1, row: 1),
    Coordinate(column: 0, row: 0),
]

for coordinate in corners {
    for i in 1 ... 4 {
        world.place(Block(), at: coordinate)
    }
}

// Selezione delle coordinate per la realizzazione delle griglie laterali
for colonne in 7 ... 11 {
    for righe in -5 ... -2 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
}

for colonne in 1 ... 4 {
    for righe in 13 ... 15 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
}

// Posizionamento personaggi, portali, gemme e muri
let hopper = Character(name: .hopper)
world.place(hopper, at: Coordinate(column: 4, row: 15))

world.place(Portal(color: #colorLiteral(red: 0.9372549057006836, green: 0.3490196168422699, blue: 0.1921568661928177, alpha: 1.0)), atStartColumn: 1, startRow:13, atEndColumn: 1, endRow: 13)
world.place(Portal(color: #colorLiteral(red: 0.9372549057006836, green: 0.3490196168422699, blue: 0.1921568661928177, alpha: 1.0)), atStartColumn: 0, startRow:1, atEndColumn: 0, endRow: 1)

world.place(Portal(color: #colorLiteral(red: 0.4745098054409027, green: 0.8392156958580017, blue: 0.9764705896377563, alpha: 1.0)), atStartColumn:0, startRow:10, atEndColumn:0, endRow:10)
world.place(Portal(color: #colorLiteral(red: 0.4745098054409027, green: 0.8392156958580017, blue: 0.9764705896377563, alpha: 1.0)),atStartColumn:1, startRow:11, atEndColumn:1, endRow:11)

world.place(Portal(color: #colorLiteral(red: 0.7215686440467834, green: 0.886274516582489, blue: 0.5921568870544434, alpha: 1.0)), atStartColumn:10, startRow:11, atEndColumn:10, endRow:11)
world.place(Portal(color: #colorLiteral(red: 0.7215686440467834, green: 0.886274516582489, blue: 0.5921568870544434, alpha: 1.0)),atStartColumn:11, startRow:10, atEndColumn:11, endRow:10)

world.place(Portal(color: #colorLiteral(red: 0.5568627715110779, green: 0.3529411852359772, blue: 0.9686274528503418, alpha: 1.0)), atStartColumn:11, startRow:1, atEndColumn:11, endRow:1)
world.place(Portal(color: #colorLiteral(red: 0.5568627715110779, green: 0.3529411852359772, blue: 0.9686274528503418, alpha: 1.0)), atStartColumn:10, startRow:0, atEndColumn:10, endRow:0)

world.place(Portal(color: #colorLiteral(red: 0.9098039269447327, green: 0.47843137383461, blue: 0.6431372761726379, alpha: 1.0)), atStartColumn:1, startRow:0, atEndColumn:1, endRow:0)
world.place(Portal(color: #colorLiteral(red: 0.9098039269447327, green: 0.47843137383461, blue: 0.6431372761726379, alpha: 1.0)), atStartColumn:11, startRow:-5, atEndColumn:11, endRow:-5)

world.place(Gem(), at: Coordinate(column: 3, row: 7))
world.place(Gem(), at: Coordinate(column: 7, row: 8))
world.place(Gem(), at: Coordinate(column: 8, row: 4))
world.place(Gem(), at: Coordinate(column: 4, row: 3))
world.place(Gem(), at: Coordinate(column: 7, row: -2))

//#-end-editable-code
//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code
