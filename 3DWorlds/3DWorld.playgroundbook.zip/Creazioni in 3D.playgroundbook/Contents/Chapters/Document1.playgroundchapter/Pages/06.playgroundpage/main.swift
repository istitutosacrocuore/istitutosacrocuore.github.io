/*:
 **Precondizione:** analizzare ed eseguire il codice
 
 **Obiettivo:** individuare la posizione iniziale di `Hopper`, aiutandolo a percorrere la grande muraglia per raccogliere tutte le gemme posizionate lungo il suo perimetro.
 
 Al termine della missione, teletrasportare `Hopper` sull'isola.

* Callout(Autore):
**Sandro Chen Jie**
*/
//#-hidden-code
import Foundation

public func assessmentPoint() -> AssessmentResults {
    return .pass(message: nil)
}


public func playgroundPrologue() {
    Display.coordinateMarkers = true
    
    world.isCharacterPickerEnabled = false
    world.successCriteria = .custom(.ignoreGoals, { return false })
    registerAssessment(world, assessment: assessmentPoint)
    
    //// ----
    // Any items added or removed after this call will be animated.
    finalizeWorldBuilding(for: world)
    //// ----
}

// MARK: Epilogue

public func playgroundEpilogue() {
    sendCommands(for: world)
}

playgroundPrologue()
typealias Character = Actor
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color, array)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, hide, assessmentPoint(), playgroundPrologue(), playgroundEpilogue())
//#-code-completion(identifier, show, isOnOpenSwitch, if, func, for, while, moveForward(), turnLeft(), turnRight(), collectGem(), toggleSwitch(), isBlocked, north, south, east, west, Water, Expert, Character, (, ), (), turnLockUp(), turnLockDown(), isOnClosedSwitch, var, let, ., =, <, >, ==, !=, +=, +, -, isBlocked, move(distance:), Character, Expert, (, ), (), Portal, color:, (color:), Block, Gem, Stair, Switch, Platform, (onLevel:controlledBy:), onLevel:controlledBy:, PlatformLock, jump(), true, false, turnLock(up:numberOfTimes:), world, place(_:facing:at:), place(_:between:and:), removeBlock(atColumn:row:), isBlockedLeft, &&, ||, !, isBlockedRight, Coordinate, column:row:), (column:row:), column:row:, place(_:at:), remove(at:), insert(_:at:), removeItems(at:), append(_:), count, column(_:), row(_:), removeFirst(), removeLast(), randomInt(from:to:), removeAll(), allPossibleCoordinates, danceLikeNoOneIsWatching(), turnUp(), breakItDown(), grumbleGrumble(), argh(), coordinates(inRows:), coordinates(inColumns:intersectingRows:), name:, (name:), byte, blu, hopper, randomBool(), height(at:), movePlatforms(up:numberOfTimes:), height(at:), coordinates(inColumns:), existingGems(at:), existingSwitches(at:), existingCharacters(at:), existingExperts(at:), existingBlocks(at:), existingWater(at:), placeBlocks(at:), placeWater(at:), placeGems(at:), CharacterName, numberOfBlocks(at:), column, row)
// Selezione delle coordinate esterne alla griglia per la costruzione delle torri
for colonne in 0 ... 3 {
    for righe in -5 ... -2 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
}

for colonne in 8 ... 11 {
    for righe in 13 ... 16 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
}

world.place(Block(), at: Coordinate(column: 12, row: 0))
world.place( Block(), at: Coordinate(column: 13, row: 0))
world.place( Block(), at: Coordinate(column: 14, row: 0))
world.place( Block(), at: Coordinate(column: 12, row: 11))
world.place( Block(), at: Coordinate(column: 13, row: 11))
world.place( Block(), at: Coordinate(column: 14, row: 11))
world.place(Block(), at: Coordinate(column: -1, row: 11))
world.place(Block(), at: Coordinate(column: -2, row: 11))
world.place(Block(), at: Coordinate(column: -3, row: 11))
world.place(Block(), at: Coordinate(column: -1, row: 0))
world.place(Block(), at: Coordinate(column: -2, row: 0))
world.place(Block(), at: Coordinate(column: -3, row: 0))

// Selezione delle coordinate nella griglia per l'isola
for colonne in 2 ... 9  {
    for righe in 2 ... 9 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
}

for coordinate in world.coordinates(inColumns: [0,1,2,9,10,11], intersectingRows: [0,1,2,3,4,5,6,7,8,9,10,11]){
    world.removeBlock(atColumn: coordinate.column, row: coordinate.row)
}

for coordinate in world.coordinates(inColumns: [3,4,5,6,7,8], intersectingRows: [0,1,2,9,10,11]){
    world.removeBlock(atColumn: coordinate.column, row: coordinate.row)
}

// Selezione delle coordinate nella griglia per il posizionamento dell'acqua
let sea = world.coordinates(inColumns: [2,3,4,5,6,7,8,9], intersectingRows: [0,1,10,11]) + world.coordinates(inColumns: [0,1,10,11], intersectingRows: [0,1,2,3,4,5,6,7,8,9,10,11])

for seaCoordinate in sea {
     world.place(Water(), at: seaCoordinate)
}


for colonne in 4 ... 7  {
    for righe in 4 ... 7 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
}

for colonne in 5 ... 6  {
    for righe in 5 ... 6 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
}

for colonne in 1 ... 2  {
    for righe in -4 ... -3 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
}

for colonne in 9 ... 10  {
    for righe in 14 ... 15 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
}

// Posizionamento dei portali sull'isola
world.place(Portal(color: #colorLiteral(red: 0.25882354378700256, green: 0.7568627595901489, blue: 0.9686274528503418, alpha: 1.0)), between: Coordinate(column: 2, row: 9), and: Coordinate(column: 9, row: 2))
world.place(Portal(color: #colorLiteral(red: 0.5843137502670288, green: 0.8235294222831726, blue: 0.41960784792900085, alpha: 1.0)), between: Coordinate(column: 9, row: 9), and: Coordinate(column: 2, row: 2))
world.place(Portal(color: #colorLiteral(red: 0.364705890417099, green: 0.06666667014360428, blue: 0.9686274528503418, alpha: 1.0)), between: Coordinate(column: 8, row: 8), and: Coordinate(column: 3, row: 3))
world.place(Portal(color: #colorLiteral(red: 0.8549019694328308, green: 0.250980406999588, blue: 0.47843137383461, alpha: 1.0)), between: Coordinate(column: 3, row: 8), and: Coordinate(column: 8, row: 3))
world.place(Portal(color: #colorLiteral(red: 0.9411764740943909, green: 0.49803921580314636, blue: 0.3529411852359772, alpha: 1.0)), between: Coordinate(column: 7, row: 7), and: Coordinate(column: 4, row: 4))
world.place(Portal(color: #colorLiteral(red: 0.9686274528503418, green: 0.7803921699523926, blue: 0.3450980484485626, alpha: 1.0)), between: Coordinate(column: 7, row: 4), and: Coordinate(column: 4, row: 7))
world.place(Portal(color: #colorLiteral(red: 0.9254902005195618, green: 0.23529411852359772, blue: 0.10196078568696976, alpha: 1.0)), between: Coordinate(column: 6, row: 5), and: Coordinate(column: 5, row: 6))
world.place(Portal(color: #colorLiteral(red: 0.1764705926179886, green: 0.49803921580314636, blue: 0.7568627595901489, alpha: 1.0)), between: Coordinate(column: 5, row: 5), and: Coordinate(column: 6, row: 6))

// Selezione delle coordinate necessarie per la costruzione delle torri e della muraglia
for colonne in 8 ... 11 {
    for righe in 13 ... 13 {
        for i in 1 ... 5 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in 11 ... 11 {
    for righe in 14 ... 16 {
        for i in 1 ... 5 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in 8 ... 8 {
    for righe in 14 ... 16 {
        for i in 1 ... 5 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in 9 ... 10 {
    for righe in 16 ... 16 {
        for i in 1 ... 5 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in 0 ... 3 {
    for righe in -2 ... -2 {
        for i in 1 ... 5 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in 0 ... 0 {
    for righe in -5 ... -3 {
        for i in 1 ... 5 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in 1 ... 2 {
    for righe in -5 ... -5 {
        for i in 1 ... 5 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in 3 ... 3 {
    for righe in -5 ... -3 {
        for i in 1 ... 5 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

// Posizionamento della gemma e del portale sulla torre ovest
world.place(Gem(), at: Coordinate(column: 10, row: 15))
world.place(Portal(color: #colorLiteral(red: 0.09019608050584793, green: 0.13333334028720856, blue: 0.03921568766236305, alpha: 1.0)), between: Coordinate(column: 2, row: -3), and: Coordinate(column: 9, row: 14))


for colonne in 12 ... 14 {
    for righe in 11 ... 11 {
        for i in 1 ... 10 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in 12 ... 14 {
    for righe in 0 ... 0 {
        for i in 1 ... 10 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
        
    }
}

for colonne in -3 ... -1 {
    for righe in 11 ... 11 {
        for i in 1 ... 10 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in -3 ... -1 {
    for righe in 0 ... 0 {
        for i in 1 ... 10 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in 14 ... 14 {
    for righe in 1 ... 10 {
        for i in 1 ... 11 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in -3 ... -3 {
    for righe in 1 ... 10 {
        for i in 1 ... 11 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in 12 ... 12 {
    for righe in 12 ... 17 {
        for i in 1 ... 11 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in 7 ... 11 {
    for righe in 17 ... 17 {
        for i in 1 ... 11 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in 7 ... 7 {
    for righe in 12 ... 16 {
        for i in 1 ... 11 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in -1 ... 6 {
    for righe in 12 ... 12 {
        for i in 1 ... 11 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in -1 ... -1 {
    for righe in -6 ... -1 {
        for i in 1 ... 11 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in 0 ... 4 {
    for righe in -6 ... -6 {
        for i in 1 ... 11 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in 4 ... 4 {
    for righe in -5 ... -1 {
        for i in 1 ... 11 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for colonne in 5 ... 12 {
    for righe in -1 ... -1 {
        for i in 1 ... 11 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

// Selezione delle coordinate per il riempimento con acqua
for colonne in 0 ... 3 {
    for righe in -1 ... -1 {
        world.place(Water(), at: Coordinate(column: colonne, row: righe))
    }
}

for colonne in 8 ... 11 {
    for righe in 12 ... 12 {
        world.place(Water(), at: Coordinate(column: colonne, row: righe))
    }
}

for colonne in 12 ... 13 {
    for righe in 1 ... 10 {
        world.place(Water(), at: Coordinate(column: colonne, row: righe))
    }
}

for colonne in -2 ... -1 {
    for righe in 1 ... 10 {
        world.place(Water(), at: Coordinate(column: colonne, row: righe))
    }
}

// Posizionamento di gemme e portali lungo la muraglia
world.place(Portal(color: #colorLiteral(red: 0.9098039269447327, green: 0.47843137383461, blue: 0.6431372761726379, alpha: 1.0)), between: Coordinate(column: 10, row: 14),and:Coordinate(column: 12, row: 11))
world.place(Gem(), at: Coordinate(column: 14, row: 11))
world.place(Gem(), at: Coordinate(column: 14, row: 0))
world.place(Gem(), at: Coordinate(column: 12, row: 0))
world.place(Gem(), at: Coordinate(column: 12, row: -1))
world.place(Gem(), at: Coordinate(column: 4, row: -1))
world.place(Gem(), at: Coordinate(column: 4, row: -6))
world.place(Gem(), at: Coordinate(column: -1, row: -6))
world.place(Gem(), at: Coordinate(column: -1, row: 0))
world.place(Gem(), at: Coordinate(column: -3, row: 0))
world.place(Gem(), at: Coordinate(column: -3, row: 11))
world.place(Gem(), at: Coordinate(column: -1, row: 11))
world.place(Gem(), at: Coordinate(column: -1, row: 12))
world.place(Gem(), at: Coordinate(column: 7, row: 12))
world.place(Gem(), at: Coordinate(column: 7, row: 17))
world.place(Gem(), at: Coordinate(column: 12, row: 17))
world.place(Portal(color: #colorLiteral(red: 0.5215686559677124, green: 0.10980392247438431, blue: 0.05098039284348488, alpha: 1.0)), between: Coordinate(column: 12, row: 12), and: Coordinate(column: 6, row: 5))
let hopper = Character(name: .octet)
world.place(hopper, facing: east, at: Coordinate(column: 1, row: -3))

//#-editable-code Tocca per inserire il codice

//#-end-editable-code
//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code
