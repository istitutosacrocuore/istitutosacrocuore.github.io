/*:
 **Presentazione:**  L'obiettivo è raccogliere la gemma e attivare tutti gli interruttori spenti.

 Questo mondo è un fantasico livello da completare. Puoi utilizzare tutto ciò che hai imparato nelle attività passate.


\
 
* Callout(Autore):
**Luca Petroccione**
*/
//#-hidden-code
import Foundation

public func assessmentPoint() -> AssessmentResults {
    return .pass(message: nil)
}


public func playgroundPrologue() {
    Display.coordinateMarkers = true
    
    world.isCharacterPickerEnabled = false
    world.successCriteria = .custom(.ignoreGoals, { return false })
    registerAssessment(world, assessment: assessmentPoint)
    
    //// ----
    // Any items added or removed after this call will be animated.
    finalizeWorldBuilding(for: world)
    //// ----
}

// MARK: Epilogue

public func playgroundEpilogue() {
    sendCommands(for: world)
}

playgroundPrologue()
typealias Character = Actor
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color, array)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, hide, assessmentPoint(), playgroundPrologue(), playgroundEpilogue())
//#-code-completion(identifier, show, isOnOpenSwitch, if, func, for, while, moveForward(), turnLeft(), turnRight(), collectGem(), toggleSwitch(), isBlocked, north, south, east, west, Water, Expert, Character, (, ), (), turnLockUp(), turnLockDown(), isOnClosedSwitch, var, let, ., =, <, >, ==, !=, +=, +, -, isBlocked, move(distance:), Character, Expert, (, ), (), Portal, color:, (color:), Block, Gem, Stair, Switch, Platform, (onLevel:controlledBy:), onLevel:controlledBy:, PlatformLock, jump(), true, false, turnLock(up:numberOfTimes:), world, place(_:facing:at:), place(_:between:and:), removeBlock(atColumn:row:), isBlockedLeft, &&, ||, !, isBlockedRight, Coordinate, column:row:), (column:row:), column:row:, place(_:at:), remove(at:), insert(_:at:), removeItems(at:), append(_:), count, column(_:), row(_:), removeFirst(), removeLast(), randomInt(from:to:), removeAll(), allPossibleCoordinates, danceLikeNoOneIsWatching(), turnUp(), breakItDown(), grumbleGrumble(), argh(), coordinates(inRows:), coordinates(inColumns:intersectingRows:), name:, (name:), byte, blu, hopper, randomBool(), height(at:), movePlatforms(up:numberOfTimes:), height(at:), coordinates(inColumns:), existingGems(at:), existingSwitches(at:), existingCharacters(at:), existingExperts(at:), existingBlocks(at:), existingWater(at:), placeBlocks(at:), placeWater(at:), placeGems(at:), CharacterName, numberOfBlocks(at:), column, row)

// rimozzione dei blocchi  e piazzamento dell'acqua
var column = world.coordinates(inColumns: [3,2,1,0])
var row = world.coordinates(inRows: [0,1,2,3])
world.removeAllBlocks(at: Coordinate(column: 3, row: 0))
world.placeWater(at: [Coordinate(column:3, row: 0)])
world.removeAllBlocks(at: Coordinate(column: 3, row: 1))
world.placeWater(at: [Coordinate(column:3, row: 1)])
world.removeAllBlocks(at: Coordinate(column: 3, row: 2))
world.placeWater(at: [Coordinate(column:3, row: 2)])
world.removeAllBlocks(at: Coordinate(column: 3, row: 3))
world.placeWater(at: [Coordinate(column:3, row: 3)])
world.removeAllBlocks(at: Coordinate(column: 0, row: 3))
world.placeWater(at: [Coordinate(column:0, row:3 )])
world.removeAllBlocks(at: Coordinate(column: 1, row: 3))
world.placeWater(at: [Coordinate(column:1, row: 3)])
world.removeAllBlocks(at: Coordinate(column: 2, row: 3))
world.placeWater(at: [Coordinate(column:2, row: 3)])
let corgi = world.coordinates(inColumns: [0, 1, 2], intersectingRows: [0, 1, 2])
for corgi in corgi {
    for i in 1...2 {
        world.place(Block(), at: corgi)
    }
}
let corki = world.coordinates(inColumns: [0, 1], intersectingRows: [0, 1])
for corki in corki {
    for i in 1...2 {
        world.place(Block(), at: corki)
    }
}
//aggiunta dei muri
let coods = world.coordinates(inColumns: [0,1], intersectingRows: [1,0])
for coods in coods {
    for i in 1...2 {
        world.place(Wall(), facing: west, at: coods)
    }
}
//aggiunta la gemma
world.place(Gem(), at: Coordinate(column: 0, row: 0))

world.removeAllBlocks(at: Coordinate(column: 11, row: 3))
world.placeWater(at: [Coordinate(column:11, row: 3)])
world.removeAllBlocks(at: Coordinate(column: 10, row: 3))
world.placeWater(at: [Coordinate(column:10, row: 3)])
world.removeAllBlocks(at: Coordinate(column: 9, row: 3))
world.placeWater(at: [Coordinate(column:9, row: 3)])
world.removeAllBlocks(at: Coordinate(column: 8, row: 3))
world.placeWater(at: [Coordinate(column:8, row: 3)])
world.removeAllBlocks(at: Coordinate(column: 8, row: 2))
world.placeWater(at: [Coordinate(column:8, row:2 )])
world.removeAllBlocks(at: Coordinate(column: 8, row: 1))
world.placeWater(at: [Coordinate(column:8, row: 1)])
world.removeAllBlocks(at: Coordinate(column: 8, row: 0))
world.placeWater(at: [Coordinate(column:8, row: 0)])
let info = world.coordinates(inColumns: [11,10,9], intersectingRows: [0, 1, 2])
for info in info {
    for i in 1...2 {
        world.place(Block(), at: info)
    }
}
let inform = world.coordinates(inColumns: [10,11], intersectingRows: [0, 1])
for inform in inform {
    for i in 1...8 {
        world.place(Block(), at: inform)
    }
}
world.place(Switch(), at: Coordinate(column: 11, row: 0))

world.removeAllBlocks(at: Coordinate(column: 8, row: 11))
world.placeWater(at: [Coordinate(column:8, row: 11)])
world.removeAllBlocks(at: Coordinate(column: 8, row: 10))
world.placeWater(at: [Coordinate(column:8, row: 10)])
world.removeAllBlocks(at: Coordinate(column: 8, row: 9))
world.placeWater(at: [Coordinate(column:8, row: 9)])
world.removeAllBlocks(at: Coordinate(column: 8, row: 8))
world.placeWater(at: [Coordinate(column:8, row: 8)])
world.removeAllBlocks(at: Coordinate(column: 9, row: 8))
world.placeWater(at: [Coordinate(column:9, row:8 )])
world.removeAllBlocks(at: Coordinate(column: 10, row: 8))
world.placeWater(at: [Coordinate(column:10, row: 8)])
world.removeAllBlocks(at: Coordinate(column: 11, row: 8))
world.placeWater(at: [Coordinate(column:11, row: 8)])
let steam = world.coordinates(inColumns: [9,10,11], intersectingRows: [9,10,11])
for steam in steam {
    for i in 1...2 {
        world.place(Block(), at: steam)
    }
}
let dream = world.coordinates(inColumns: [10,11], intersectingRows: [10, 11])
for dream in dream {
    for i in 1...8 {
        world.place(Block(), at: dream)
    }
}
world.place(Switch(), at: Coordinate(column: 11, row: 11))

world.removeAllBlocks(at: Coordinate(column: 0, row: 8))
world.placeWater(at: [Coordinate(column:0, row: 8)])
world.removeAllBlocks(at: Coordinate(column: 1, row: 8))
world.placeWater(at: [Coordinate(column:1, row: 8)])
world.removeAllBlocks(at: Coordinate(column: 2, row: 8))
world.placeWater(at: [Coordinate(column:2, row: 8)])
world.removeAllBlocks(at: Coordinate(column: 3, row: 8))
world.placeWater(at: [Coordinate(column:3, row: 8)])
world.removeAllBlocks(at: Coordinate(column: 3, row: 9))
world.placeWater(at: [Coordinate(column:3, row:9 )])
world.removeAllBlocks(at: Coordinate(column: 3, row: 10))
world.placeWater(at: [Coordinate(column:3, row: 10)])
world.removeAllBlocks(at: Coordinate(column: 3, row: 11))
world.placeWater(at: [Coordinate(column:3, row: 11)])
let placement = world.coordinates(inColumns: [0,1,2], intersectingRows: [11,10,9])
for placement in placement {
    for i in 1...2 {
        world.place(Block(), at: placement)
    }
}
let block1 = world.coordinates(inColumns: [0,1], intersectingRows: [10, 11])
for block1 in block1 {
    for i in 1...8 {
        world.place(Block(), at: block1)
    }
}
world.place(Switch(), at: Coordinate(column: 0, row: 11))

let DUMMY = world.row(4)
for Coordinates in DUMMY{
    world.removeBlock(at: Coordinates)
    world.placeWater(at: [Coordinates])
}
let strike = world.row(5)
for Coordinates in strike{
    world.removeBlock(at: Coordinates)
    world.placeWater(at: [Coordinates])
}
let dummy = world.row(6)
for Coordinates in dummy{
    world.removeBlock(at: Coordinates)
    world.placeWater(at: [Coordinates])
}
let hippo = world.row(7)
for Coordinates in hippo{
    world.removeBlock(at: Coordinates)
    world.placeWater(at: [Coordinates])
}
let stik = world.column(8)
for Coordinates in stik{
    world.removeBlock(at: Coordinates)
    world.placeWater(at: [Coordinates])
}

let sky = world.column(3)
for Coordinates in sky{
    world.removeBlock(at: Coordinates)
    world.placeWater(at: [Coordinates])
}
//aggiunta delle piattaforme
let squareLock = PlatformLock(color: #colorLiteral(red: 0.46666666865348816, green: 0.7647058963775635, blue: 0.2666666805744171, alpha: 1.0))
world.place(squareLock, facing: east, at: Coordinate(column: 4, row: 9))
let cornerLock = PlatformLock(color: .red)
world.place(cornerLock, facing: west, at: Coordinate(column: 7 , row: 10))
let backLock = PlatformLock(color: .blue)
world.place(backLock, at: Coordinate(column: 5, row: 3))
let upLock = PlatformLock(color:.pink )
world.place(upLock, facing: north,at: Coordinate(column: 6, row: 0))

// aggiunta dei portali
let portal = Portal(color: #colorLiteral(red: 0.9254902005195618, green: 0.23529411852359772, blue: 0.10196078568696976, alpha: 1.0))
world.place(portal, atStartColumn: 1, startRow: 1, atEndColumn: 9, endRow: 11)
let portal2 = Portal(color: #colorLiteral(red: 0.4028071761, green: 0.7315050364, blue: 0.2071235478, alpha: 1))
world.place(portal2, atStartColumn: 10, startRow: 11, atEndColumn: 11, endRow: 2)
let portal3 = Portal(color: #colorLiteral(red: 0.8549019694328308, green: 0.250980406999588, blue: 0.47843137383461, alpha: 1.0))
world.place(portal3, atStartColumn: 11, startRow: 1, atEndColumn: 0, endRow: 9)
let portal4 = Portal(color: #colorLiteral(red: 0.239215686917305, green: 0.6745098233222961, blue: 0.9686274528503418, alpha: 1.0))
world.place(portal4, atStartColumn: 0, startRow: 10, atEndColumn: 2, endRow: 2)
let portal5 = Portal(color: #colorLiteral(red: 0.9607843160629272, green: 0.7058823704719543, blue: 0.20000000298023224, alpha: 1.0))
world.place(portal5, atStartColumn: 6, startRow: 11, atEndColumn: 7, endRow: 1)
let squarLock = world.place(Platform(onLevel: 2, controlledBy: upLock), at:Coordinate(column: 2, row: 11))
world.place(Platform(onLevel: 2, controlledBy: cornerLock), at: Coordinate(column: 11, row: 9))
world.place(Platform(onLevel: 2, controlledBy: squareLock), at: Coordinate(column: 9, row: 0))
world.place(Platform(onLevel: 2, controlledBy: backLock), at: Coordinate(column: 0, row: 2))

// posizionamento delle scale
world.place(Stair(), facing: north,at: Coordinate(column: 9, row: 1))
world.place(Stair(), facing: south,at: Coordinate(column: 2, row: 10))
world.place(Stair(), facing: west,at: Coordinate(column: 10, row: 9))
world.place(Stair(), facing: east,at: Coordinate(column: 1, row: 2))

// inizializzazione e collocamento dei pesonaggi
let hopper = Character(name: .hopper)
world.place(hopper, facing: north,at: Coordinate(column: 1, row: 0))
let expert = Expert()
world.place(expert, facing: south, at: Coordinate(column: 5, row: 11))


//#-editable-code Tap to enter code

//#-end-editable-code


//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code
