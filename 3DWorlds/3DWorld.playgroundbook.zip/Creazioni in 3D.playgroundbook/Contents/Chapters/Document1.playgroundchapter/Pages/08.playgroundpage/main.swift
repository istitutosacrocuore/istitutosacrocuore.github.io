/*:
 **Precondizione:** analizzare ed eseguire il codice
 
 **Obiettivo:** raccogliere le quattro gemme alle estremità del mondo e azionare gli interruttori (qualora fossero spenti) ripartendo i compiti in maniera bilanciata tra i quattro concorrenti in gara. Utilizzare gli Expert per azionare le piattaforme di collegamento.
 * Callout(Autore):
 **Anna Avolio**
 */
//#-hidden-code

//#-end-hidden-code
/*:
 
  - Note:
    L'accesione o spegnimento iniziale degli interruttori è gestito in maniera casuale.
 
* Experiment: **Inizializzare un interruttore**\
Questo esempio mostra come impostare lo stato di un interruttore:
\
 `let switch = Switch(open: true)` -> interruttore accesso\
 `let switch = Switch(open: false)` -> interruttore spento\
 Parametro `open`: se omesso -> interruttore spento
 */
//#-hidden-code
import Foundation

public func assessmentPoint() -> AssessmentResults {
    return .pass(message: nil)
}


public func playgroundPrologue() {
    Display.coordinateMarkers = true
    
    world.isCharacterPickerEnabled = false
    world.successCriteria = .custom(.ignoreGoals, { return false })
    registerAssessment(world, assessment: assessmentPoint)
    
    //// ----
    // Any items added or removed after this call will be animated.
    finalizeWorldBuilding(for: world)
    //// ----
}

// MARK: Epilogue

public func playgroundEpilogue() {
    sendCommands(for: world)
}

playgroundPrologue()
typealias Character = Actor
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color, array)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, hide, assessmentPoint(), playgroundPrologue(), playgroundEpilogue())
//#-code-completion(identifier, show, isOnOpenSwitch, if, func, for, while, moveForward(), turnLeft(), turnRight(), collectGem(), toggleSwitch(), isBlocked, north, south, east, west, Water, Expert, Character, (, ), (), turnLockUp(), turnLockDown(), isOnClosedSwitch, var, let, ., =, <, >, ==, !=, +=, +, -, isBlocked, move(distance:), Character, Expert, (, ), (), Portal, color:, (color:), Block, Gem, Stair, Switch, Platform, (onLevel:controlledBy:), onLevel:controlledBy:, PlatformLock, jump(), true, false, turnLock(up:numberOfTimes:), world, place(_:facing:at:), place(_:between:and:), removeBlock(atColumn:row:), isBlockedLeft, &&, ||, !, isBlockedRight, Coordinate, column:row:), (column:row:), column:row:, place(_:at:), remove(at:), insert(_:at:), removeItems(at:), append(_:), count, column(_:), row(_:), removeFirst(), removeLast(), randomInt(from:to:), removeAll(), allPossibleCoordinates, danceLikeNoOneIsWatching(), turnUp(), breakItDown(), grumbleGrumble(), argh(), coordinates(inRows:), coordinates(inColumns:intersectingRows:), name:, (name:), byte, blu, hopper, randomBool(), height(at:), movePlatforms(up:numberOfTimes:), height(at:), coordinates(inColumns:), existingGems(at:), existingSwitches(at:), existingCharacters(at:), existingExperts(at:), existingBlocks(at:), existingWater(at:), placeBlocks(at:), placeWater(at:), placeGems(at:), CharacterName, numberOfBlocks(at:), column, row)
// Inizializzazione dell'array "allCoordinates" con tutte le coordinate presenti nel mondo del livello
let allCoordinates = world.allPossibleCoordinates

// Inizializzazione delle variabili booleane con il metodo randomBool() che genera un valore booleano (true/false) casuale
let random1 = randomBool()
let random2 = randomBool()
let random3 = randomBool()
let random4 = randomBool()

// Inizializzazione degli array vuoti di tipo coordinate
var mountain : [Coordinate] = []
var sea : [Coordinate] = []
var sea2 : [Coordinate] = []
var sea3 : [Coordinate] = world.column(3)
var sea4 : [Coordinate] = world.column(8)
var island : [Coordinate] = []
var walls1 : [Coordinate] = []
var walls2 : [Coordinate] = []

// Selezione delle cordinate nella griglia per la costruzione del paesaggio
for coordinate in allCoordinates {
    if coordinate.column >= 0 && coordinate.column <= 11 && coordinate.row > 1 && coordinate.row < 4
    {
        sea.append(coordinate)
    }
    else {
        mountain.append(coordinate)
    }
}

for AllCoordinates in mountain {
    world.place( Block(), at : AllCoordinates)
}

for AllCoordinates in sea {
    world.removeAllBlocks(at: AllCoordinates)
    world.place(Water(), at: AllCoordinates)
}

for coordinate in allCoordinates {
    if coordinate.column >= 0 && coordinate.column <= 11 && coordinate.row > 7 && coordinate.row < 10
    {
        sea2.append(coordinate)
    }
}

for allCoordinates in sea2  {
    world.removeAllBlocks(at: allCoordinates)
    world.place(Water(), at: allCoordinates)
}

for AllCoordinates in sea3 {
    world.removeAllBlocks (at : AllCoordinates)
    world.place (Water(), at : AllCoordinates)
}

for AllCoordinates in sea4 {
    world.removeAllBlocks ( at : AllCoordinates)
    world.place (Water(), at : AllCoordinates)
}

for coordinate in allCoordinates {
    if coordinate.column >= 10 && coordinate.column <= 10 && coordinate.row > 3 && coordinate.row < 8
    {
        walls1.append(coordinate)
    }
}

for coordinate in allCoordinates {
    if coordinate.column >= 1 && coordinate.column <= 1 && coordinate.row > 3 && coordinate.row < 8
    {
        walls2.append(coordinate)
    }
}

for allCoordinates in walls1 {
    world.place(Wall(), facing: west, at: allCoordinates)
}

for allCoordinates in walls2 {
    world.place(Wall(), facing: east, at: allCoordinates)
}

// Posizionamento dei blocchi di diverse altezze e delle scale
world.place(Block(), atColumn: 6, row: 6)
world.place(Block(), atColumn: 5, row: 5)
world.place(Block(), atColumn: 5, row: 6)
world.place(Block(), atColumn: 6, row: 5)
world.place(Stair(), facing: north , atColumn: 2, row:  1)
world.place(Stair(), facing: west, atColumn: 9, row:  1)
world.place(Stair(), facing: south, atColumn: 9, row:  10)
world.place(Stair(), facing: east, atColumn: 2, row:  10)

for i in 1 ... 2 {
    world.place (Block(), atColumn: 4, row :5 )
    world.place (Block(), atColumn: 6, row :4 )
    world.place (Block(), atColumn: 7, row :6 )
    world.place (Block(), atColumn: 5, row :7 )
    world.place (Block (), atColumn: 2, row: 0)
    world.place (Block (), atColumn: 10, row: 1)
    world.place (Block (), atColumn: 9, row: 11)
    world.place (Block (), atColumn: 1, row: 10)
}

for i in 1 ... 3 {
    world.place (Block(), atColumn: 4, row :4 )
    world.place (Block(), atColumn: 7, row :4 )
    world.place (Block(), atColumn: 7, row :7 )
    world.place (Block(), atColumn: 4, row :7 )
    world.place (Block (), atColumn: 1, row: 0)
    world.place (Block (), atColumn: 11, row: 1)
    world.place (Block (), atColumn: 10, row: 11)
    world.place (Block (), atColumn: 0, row: 10)
}

for i in 1 ... 4 {
    world.place (Block (), atColumn: 0, row: 0)
    world.place (Block (), atColumn: 11, row: 0)
    world.place (Block (), atColumn: 11, row: 11)
    world.place (Block (), atColumn: 0, row: 11)
}

// Inizializzazione e posizionamento dei portali di diverso colore
let redPortal = Portal (color: #colorLiteral(red: 0.7450980544090271, green: 0.1568627506494522, blue: 0.07450980693101883, alpha: 1.0))
world.place(redPortal, atStartColumn: 4, startRow: 4, atEndColumn: 2, endRow: 6)
let orangePortal = Portal (color: #colorLiteral(red: 0.9411764740943909, green: 0.49803921580314636, blue: 0.3529411852359772, alpha: 1.0))
world.place(orangePortal, atStartColumn: 7, startRow: 4, atEndColumn: 5, endRow: 1)
let yellowPortal = Portal (color: #colorLiteral(red: 0.9686274528503418, green: 0.7803921699523926, blue: 0.3450980484485626, alpha: 1.0) )
world.place(yellowPortal, atStartColumn: 7, startRow: 7, atEndColumn: 9, endRow: 5)
let blackPortal = Portal (color: #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0))
world.place(blackPortal, atStartColumn: 4, startRow: 7, atEndColumn: 6, endRow: 10)

// Posizionamento delle gemme
var gem = [Coordinate (column:0, row:0), Coordinate(column: 11, row: 0), Coordinate(column : 11, row: 11), Coordinate (column: 0, row: 11)]
for coordinate in gem {
    world.placeGems(at: [coordinate])
}

// Posizionamento degli interruttori, utlizzando le variabili random che ne determinano lo stato acesso (se vere) o spento (altrimenti)
if random1 == true {
    var swicthacceso = Switch(open:true)
    world.place(swicthacceso, atColumn: 5, row :4)
} else {
    world.place(Switch(), atColumn: 5, row: 4)
}

if random2 == true {
    var swicthacceso = Switch(open:true)
    world.place(swicthacceso, atColumn: 7 , row  :5)
} else {
    world.place(Switch(), atColumn: 7, row: 5)
}

if random3 == true {
    var swicthacceso = Switch(open:true)
    world.place(swicthacceso, atColumn: 6, row :7)
} else {
    world.place(Switch(), atColumn: 6, row: 7)
}

if random4 == true {
    var swicthacceso = Switch(open:true)
    world.place(swicthacceso, atColumn: 4, row :6)
} else {
    world.place(Switch(), atColumn: 4, row: 6)
}

// Inizializzazione e posizionamento delle piattaforme e delle serrature di controllo
let redLock = PlatformLock(color: #colorLiteral(red: 0.7450980544090271, green: 0.1568627506494522, blue: 0.07450980693101883, alpha: 1.0))
world.place(redLock, at: Coordinate(column: 0, row: 6))
world.place(Platform(onLevel: 2, controlledBy: redLock), at: Coordinate(column: 2, row: 2))
world.place(Platform(onLevel: 2, controlledBy: redLock), at: Coordinate(column: 2, row: 3))
world.place(Platform(onLevel: 2, controlledBy: redLock), at: Coordinate(column: 9, row: 8))
world.place(Platform(onLevel: 2, controlledBy: redLock),at : Coordinate(column: 9, row: 9))
let blackLock = PlatformLock (color: #colorLiteral(red: 0.11764705926179886, green: 0.0, blue: 0.06666667014360428, alpha: 1.0))
world.place(blackLock, facing: north, at: Coordinate(column: 11, row: 5 ))
world.place(Platform(onLevel: 5, controlledBy: blackLock), at: Coordinate(column: 8, row: 1))
world.place(Platform(onLevel: 5, controlledBy: blackLock), at: Coordinate(column: 3, row: 10))

// Inizializzazione e posizionamento degli Expert
let expert1 = Expert()
let expert2 = Expert()
world.place(expert1, facing: north, atColumn : 0, row: 5)
world.place(expert2, facing: south, atColumn: 11, row: 6)

// Inizializzazione e posizionamento dei personaggi
let character = Character()
let character1 = Character ()
let character2 = Character()
let character3 = Character()
world.place(character, facing: west, atColumn: 5, row : 5)
world.place(character1, facing: south, atColumn: 6, row : 5)
world.place(character2, facing: east, atColumn: 6, row : 6)
world.place(character3, facing: north, atColumn: 5, row : 6)

// Danza dei personaggi
character.breakItDown()
character1.breakItDown()
character2.breakItDown()
character3.breakItDown()

//#-editable-code Tap to enter code

//#-end-editable-code


//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code
