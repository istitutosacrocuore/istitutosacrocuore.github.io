/*:
 **Precondizione:** analizzare ed eseguire il codice
 
 **Obiettivo:** con l'aiuto di `Expert` guidare i personaggi all'interno del mondo per raccogliere tutte le gemme ed accendere tutti gli interruttori spenti utilizzando portali e piattaforme.
 
 Se necessario, è possibile anche modificare la struttura iniziale del mondo (rimuovere mura, aggiungere blocchi, ecc.)
 
* Callout(Autore):
**Cristina Su**
*/
//#-hidden-code
import Foundation

public func assessmentPoint() -> AssessmentResults {
    return .pass(message: nil)
}


public func playgroundPrologue() {
    Display.coordinateMarkers = true
    
    world.isCharacterPickerEnabled = false
    world.successCriteria = .custom(.ignoreGoals, { return false })
    registerAssessment(world, assessment: assessmentPoint)
    
    //// ----
    // Any items added or removed after this call will be animated.
    finalizeWorldBuilding(for: world)
    //// ----
}

// MARK: Epilogue

public func playgroundEpilogue() {
    sendCommands(for: world)
}

playgroundPrologue()
typealias Character = Actor
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color, array)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, hide, assessmentPoint(), playgroundPrologue(), playgroundEpilogue())
//#-code-completion(identifier, show, isOnOpenSwitch, if, func, for, while, moveForward(), turnLeft(), turnRight(), collectGem(), toggleSwitch(), isBlocked, north, south, east, west, Water, Expert, Character, (, ), (), turnLockUp(), turnLockDown(), isOnClosedSwitch, var, let, ., =, <, >, ==, !=, +=, +, -, isBlocked, move(distance:), Character, Expert, (, ), (), Portal, color:, (color:), Block, Gem, Stair, Switch, Platform, (onLevel:controlledBy:), onLevel:controlledBy:, PlatformLock, jump(), true, false, turnLock(up:numberOfTimes:), world, place(_:facing:at:), place(_:between:and:), removeBlock(atColumn:row:), isBlockedLeft, &&, ||, !, isBlockedRight, Coordinate, column:row:), (column:row:), column:row:, place(_:at:), remove(at:), insert(_:at:), removeItems(at:), append(_:), count, column(_:), row(_:), removeFirst(), removeLast(), randomInt(from:to:), removeAll(), allPossibleCoordinates, danceLikeNoOneIsWatching(), turnUp(), breakItDown(), grumbleGrumble(), argh(), coordinates(inRows:), coordinates(inColumns:intersectingRows:), name:, (name:), byte, blu, hopper, randomBool(), height(at:), movePlatforms(up:numberOfTimes:), height(at:), coordinates(inColumns:), existingGems(at:), existingSwitches(at:), existingCharacters(at:), existingExperts(at:), existingBlocks(at:), existingWater(at:), placeBlocks(at:), placeWater(at:), placeGems(at:), CharacterName, numberOfBlocks(at:), column, row)
// Inizializzazione degli array di coordinate necessari per la generazinoe di montagne, fiumi e del lago centrale
let coordinate1 = world.coordinates(inColumns: [0,2,3,4,7,8,9,11], intersectingRows: [3,4,5,6,7,8])

let coordinate2 = world.coordinates(inColumns: [6], intersectingRows: [4,6,8])

let coordinate3 = world.coordinates(inColumns: [5], intersectingRows: [3,5,7])

let coordinate4 = world.coordinates(inColumns: [3,4,5,6,7,8], intersectingRows: [0,2,9,11])

let coordinate5 = world.coordinates(inColumns: [9,10,11], intersectingRows: [9,10,11])

let coordinate6 = world.coordinates(inColumns: [0,1,2], intersectingRows: [11])

let coordinate7 = world.coordinates(inColumns: [0,1,2], intersectingRows: [0,1,2])

let coordinate8 = world.coordinates(inColumns: [11], intersectingRows: [0,1,2])

let coordinate9 = world.coordinates(inColumns: [10], intersectingRows: [0,1])

let columns3 = [4,5,6,7,8]

// Rimozione dei blocchi e creazione dei fiumi laterali e del lago centrale
for coordinate in coordinate1{
    world.removeBlock(at:coordinate)
    world.placeWater(at: [coordinate])
}

for coordinate in coordinate2 {
    world.removeBlock(at: coordinate)
    world.placeWater(at: [coordinate])
}

for coordinate in  coordinate3 {
    world.removeBlock(at: coordinate)
    world.placeWater(at: [coordinate])
}

for coordinate in coordinate4 {
    world.removeBlock(at: coordinate)
    world.placeWater(at: [coordinate])
}

// Generazione delle montagne
var heights: [Int] = [5,4,2,1]
var index = 0
for coordinate in coordinate5 {
    if index == heights.count {
        index = 0
    }
    for i in 0...heights[index] {
        world.place(Block(), at: coordinate)
    }
    index += 1
}

var heights1: [Int] = [3,3,5]
var index1 = 0
for coordinate in coordinate6 {
    if index1 == heights.count {
        index1 = 0
    }
    for i in 0...heights[index1] {
        world.place(Block(), at: coordinate)
    }
    index1 += 1
}

for coordinate in coordinate7 {
    let height = coordinate.row + coordinate.column
    
    for i in 0...height {
        world.place(Block(), at: coordinate)
    }
}

for i in 1 ... 2 {
    world.place(Block(), at: Coordinate(column: 2, row: 11))
}

for i in 1 ... 4 {
    world.place(Block(), at: Coordinate(column: 2, row: 10))
}

for i in 1 ... 3 {
    world.place(Block(), at: Coordinate(column: 1, row: 10))
}

for i in 1 ... 3 {
    world.place(Block(), at: Coordinate(column: 0, row: 10))
    world.place(Block(), at: Coordinate(column: 0, row: 9))
    
}

for i in 1 ... 2 {
    world.place(Block(), at: Coordinate(column: 1, row: 9))
    world.place(Block(), at: Coordinate(column: 2, row: 9))
}

for coordinate in coordinate8 {
    for i in 1 ... 4 {
        world.place(Block(), at: coordinate)
    }
}

for coordinate in coordinate9 {
    for i in 1 ... 3 {
        world.place(Block(), at: coordinate)
    }
}

world.place(Block(), at: Coordinate(column: 10 , row: 0))

// Posizionamento delle scale
let columns = [0,1]
for column in columns {
    world.place(Stair(), facing: .east, at: Coordinate(column: column, row: 11))
}

let columns1 = [1,2]
for column in columns1 {
    world.place(Stair(), facing: .west, at: Coordinate(column: column, row: 10))
}

world.place(Stair(), facing: .east, at: Coordinate(column: 1, row: 9))
world.place(Stair(), facing: .north, at: Coordinate(column: 10, row: 1))

// Posizionamento delle mura
for colonne in 3 ... 8 {
    world.place(Wall(), at: Coordinate(column: colonne, row: 1))
}

for colonne in 3 ... 8 {
    world.place(Wall(), facing: .north, at: Coordinate(column: colonne, row: 1))
}

for colonne in 3 ... 8 {
    world.place(Wall(), at: Coordinate(column: colonne, row: 10))
}

for colonne in 3 ... 8 {
    world.place(Wall(), facing: .north, at: Coordinate(column: colonne, row: 10))
}

for righe in 3...8 {
    world.place(Wall(), facing: .east, at: Coordinate(column: 1, row: righe))
}

for righe in 3...8 {
    world.place(Wall(), facing: .west, at: Coordinate(column: 1, row: righe))
}

for righe in 3...8 {
    world.place(Wall(), facing: .east, at: Coordinate(column: 10, row: righe))
}

for righe in 3...8 {
    world.place(Wall(), facing: .west, at: Coordinate(column: 10, row: righe))
}

world.place(Wall(), facing: .south, at: Coordinate(column: 4, row: 10))

// Inizializzazione e posizionamento dei lock
let redLock = PlatformLock(color: #colorLiteral(red: 0.5215686559677124, green: 0.10980392247438431, blue: 0.05098039284348488, alpha: 1.0))
world.place(redLock, facing: . east, at: Coordinate(column: 1, row: 9))
let pinkLock = PlatformLock(color: #colorLiteral(red: 0.8549019694328308, green: 0.250980406999588, blue: 0.47843137383461, alpha: 1.0))
world.place(pinkLock, facing: .south, at: Coordinate(column: 11, row: 2))

// Inizializzazione e posizionamento delle piattaforme
world.place(Platform(onLevel: 2, controlledBy: redLock), at:Coordinate(column:5, row: 9))
world.place(Platform(onLevel: 5, controlledBy: redLock), at:Coordinate(column:10, row: 2))
world.place(Platform(onLevel: 2, controlledBy: pinkLock), at:Coordinate(column: 6, row: 2))

// Inizializzazione e posizionamento deelle gemme
var gem = [Coordinate (column:2, row:2), Coordinate(column: 11, row: 0), Coordinate(column : 11, row: 11), Coordinate (column: 0, row: 11)]

for coordinate in gem {
    world.placeGems(at: [coordinate])
}

for column in columns3 {
    world.place(Gem(), atColumn: column, row: 10)
}

// Inizializzazione e posizionamento degli interrutori spenti o accessi in maniera casuale
let random1 = randomBool()
let random2 = randomBool()
let random3 = randomBool()
let random4 = randomBool()

if random1 == true {
    var swicthacceso = Switch(open:true)
    world.place(swicthacceso, atColumn: 5, row :4)
}
else {
    world.place(Switch(), atColumn: 5, row: 4)
}
if random2 == true {
    var swicthacceso = Switch(open:true)
    world.place(swicthacceso, atColumn: 9 , row  :2)
}
else {
    world.place(Switch(), atColumn: 10, row: 1)
}
if random3 == true {
    var swicthacceso = Switch(open:true)
    world.place(swicthacceso, atColumn: 6, row :7)
}
else {
    world.place(Switch(), atColumn: 6, row: 7)
}
if random4 == true {
    var swicthacceso = Switch(open:true)
    world.place(swicthacceso, atColumn: 9, row :9)
}
else {
    world.place(Switch(), atColumn: 0, row: 10)
}

for column in columns3 {
    world.place(Switch(), atColumn: column, row: 1)
}

// Inizializzazione e posizionamento dei portali
let redPortal = Portal(color: #colorLiteral(red: 0.572549045085907, green: 0.0, blue: 0.23137255012989044, alpha: 1.0))
world.place(redPortal, atStartColumn: 9, startRow: 1, atEndColumn: 3, endRow:10)
let pinkPortal = Portal(color: #colorLiteral(red: 0.8078431487083435, green: 0.027450980618596077, blue: 0.3333333432674408, alpha: 1.0))
world.place(pinkPortal, atStartColumn: 8, startRow: 10, atEndColumn: 11, endRow:11)
let yellowPortal = Portal(color: #colorLiteral(red: 0.9529411792755127, green: 0.686274528503418, blue: 0.13333334028720856, alpha: 1.0))
world.place(yellowPortal, atStartColumn: 3, startRow: 1, atEndColumn: 2, endRow:2)
let greenPortal = Portal(color: #colorLiteral(red: 0.27450981736183167, green: 0.48627451062202454, blue: 0.1411764770746231, alpha: 1.0))
world.place(greenPortal, atStartColumn: 1, startRow: 2, atEndColumn: 0, endRow:11)

// Inizializzazione e posizionamento dei personaggi
let blu = Character(name: .blu)
let blu2 = Character(name: .blu)
let expert = Expert()
let expert2 = Expert()
world.place(blu, facing: north, atColumn: 6, row: 2)
world.place(blu2, facing: .south, atColumn: 5, row: 9)
world.place(expert, facing: .west, atColumn: 2, row: 9)
world.place(expert2, facing: .north, atColumn: 11, row: 1)

//#-editable-code Tap to enter code

//#-end-editable-code


//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code
