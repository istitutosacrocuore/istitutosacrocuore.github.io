/*:
 **Precondizione:** analizzare ed eseguire il codice
 
 **Obiettivo:** raccogliere le gemme azionando gli interruttori. Utilizzare `Expert` per sollevare le piattaforma.

* Callout(Autore):
**Riccardo Cernia**
 
 - Note:
 E' possibile inserire blocchi anche all'esterno dell'area di riferimento iniziale delimitata dalla griglia di dimensione 12*12 (piano cartesiano)
````
 \\ Griglia 4*4 (in basso a dx)
 for colonne in 0 ... 4 {
    for righe in -5 ... -2 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
 }
 \\ Griglia 3*3 (in alto a sx)
 for colonne in 8 ... 11 {
    for righe in 13 ... 15 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
 }
 ````
 */
//#-hidden-code
import Foundation

public func assessmentPoint() -> AssessmentResults {
    return .pass(message: nil)
}


public func playgroundPrologue() {
    Display.coordinateMarkers = true
    
    world.isCharacterPickerEnabled = false
    world.successCriteria = .custom(.ignoreGoals, { return false })
    registerAssessment(world, assessment: assessmentPoint)
    
    //// ----
    // Any items added or removed after this call will be animated.
    finalizeWorldBuilding(for: world)
    //// ----
}

// MARK: Epilogue

public func playgroundEpilogue() {
    sendCommands(for: world)
}

playgroundPrologue()
typealias Character = Actor
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color, array)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, hide, assessmentPoint(), playgroundPrologue(), playgroundEpilogue())
//#-code-completion(identifier, show, isOnOpenSwitch, if, func, for, while, moveForward(), turnLeft(), turnRight(), collectGem(), toggleSwitch(), isBlocked, north, south, east, west, Water, Expert, Character, (, ), (), turnLockUp(), turnLockDown(), isOnClosedSwitch, var, let, ., =, <, >, ==, !=, +=, +, -, isBlocked, move(distance:), Character, Expert, (, ), (), Portal, color:, (color:), Block, Gem, Stair, Switch, Platform, (onLevel:controlledBy:), onLevel:controlledBy:, PlatformLock, jump(), true, false, turnLock(up:numberOfTimes:), world, place(_:facing:at:), place(_:between:and:), removeBlock(atColumn:row:), isBlockedLeft, &&, ||, !, isBlockedRight, Coordinate, column:row:), (column:row:), column:row:, place(_:at:), remove(at:), insert(_:at:), removeItems(at:), append(_:), count, column(_:), row(_:), removeFirst(), removeLast(), randomInt(from:to:), removeAll(), allPossibleCoordinates, danceLikeNoOneIsWatching(), turnUp(), breakItDown(), grumbleGrumble(), argh(), coordinates(inRows:), coordinates(inColumns:intersectingRows:), name:, (name:), byte, blu, hopper, randomBool(), height(at:), movePlatforms(up:numberOfTimes:), height(at:), coordinates(inColumns:), existingGems(at:), existingSwitches(at:), existingCharacters(at:), existingExperts(at:), existingBlocks(at:), existingWater(at:), placeBlocks(at:), placeWater(at:), placeGems(at:), CharacterName, numberOfBlocks(at:), column, row)
// Inizializzazione dell'array "allCoordinates" con tutte le coordinate presenti nel mondo del livello
let allCoordinate = world.allPossibleCoordinates

// Inizializzazione dei portali e dei personaggi
let expert = Expert()
let platformLockgreen = PlatformLock(color: #colorLiteral(red: 0.34117648005485535, green: 0.6235294342041016, blue: 0.16862745583057404, alpha: 1.0))
let byte = Character(name: .byte)
let portal = Portal(color: #colorLiteral(red: 0.9254902005195618, green: 0.23529411852359772, blue: 0.10196078568696976, alpha: 1.0))
let portal2 = Portal(color: #colorLiteral(red: 0.9607843160629272, green: 0.7058823704719543, blue: 0.20000000298023224, alpha: 1.0))

// Costruzione delle piattaforme di terra esterne all'area iniziale (piano 12*12)
for colonne in 0 ... 4 {
    for righe in -5 ... -2 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
}

for colonne in 8 ... 11 {
    for righe in 13 ... 15 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
}

// Rimozione dei blocchi e posizionamento dell'acqua per la creazione del mare
for coordinate in allCoordinate{
    world.removeBlock(at: coordinate)
    world.placeWater(at: [coordinate])
}

// Posizionamento dei blocchi per la creazione dell'isola centrale
let coordinate2 = world.coordinates(inColumns: [7,6,5,4], intersectingRows: [4,5,6,7])
for coordinate in coordinate2 {
    world.placeBlocks(at: [coordinate])
}

// Posizionamento portali, personaggi, gemme ed interruttori
world.place(byte, at: Coordinate(column: 11, row: 15))
world.place(expert, at: Coordinate(column: -1, row: -4))
world.place(portal, atStartColumn: 8, startRow: 13, atEndColumn: 7, endRow: 7)
world.place(portal2, atStartColumn: 4, startRow: 4, atEndColumn: 4, endRow: -2)
world.placeGems(at: [Coordinate(column: 8, row: 15)])
world.place(Switch(), at: Coordinate(column: 7, row: 4))
world.placeBlocks(at: [Coordinate(column: 5, row: 7)])
world.place(platformLockgreen,facing: west, at: Coordinate(column: 0, row: -4))
world.placeGems(at: [Coordinate(column: 1, row: -5)])
world.placeGems(at: [Coordinate(column: 0, row: -4)])
world.place(Switch(), at: Coordinate(column: 0, row: -5))
world.place(Platform(onLevel: 1, controlledBy: platformLockgreen), at: Coordinate(column: -1, row: -4))

// Posizionamento dei blocchi per la creazione delle montagne
for i in 1 ... 2{
    world.placeBlocks(at: [Coordinate(column: 4, row: 7)])
}

world.placeBlocks(at: [Coordinate(column: 4, row: 6)])
world.placeBlocks(at: [Coordinate(column: 11, row: 14)])

for i in 1 ... 2{
    world.placeBlocks(at: [Coordinate(column: 11, row: 13)])
}

world.placeBlocks(at: [Coordinate(column: 10, row: 13)])
world.place(Platform(onLevel: 2, controlledBy: platformLockgreen), at: Coordinate(column: 1, row: -5))

for i in 1 ... 4{
    world.placeBlocks(at: [Coordinate(column: 0, row: -5)])
}

world.placeBlocks(at: [Coordinate(column: 11, row: 3)])
world.placeBlocks(at: [Coordinate(column: 10, row: 2)])
world.placeBlocks(at: [Coordinate(column: 9, row: 1)])
world.placeBlocks(at: [Coordinate(column: 8, row: 0)])

for i in 1 ... 2 {
    world.placeBlocks(at: [Coordinate(column: 11, row: 2)])
    world.placeBlocks(at: [Coordinate(column: 10, row: 1)])
    world.placeBlocks(at: [Coordinate(column: 9, row: 0)])
}

for i in 1 ... 3 {
    world.placeBlocks(at: [Coordinate(column: 10, row: 0)])
    world.placeBlocks(at: [Coordinate(column: 11, row: 1)])
}

for i in 1 ... 4 {
    world.placeBlocks(at: [Coordinate(column: 11, row: 0)])
}

world.placeBlocks(at: [Coordinate(column: 3, row: 11)])
world.placeBlocks(at: [Coordinate(column: 2, row: 10)])
world.placeBlocks(at: [Coordinate(column: 1, row: 9)])
world.placeBlocks(at: [Coordinate(column: 0, row: 8)])

for i in 1 ... 2 {
    world.placeBlocks(at: [Coordinate(column: 2, row: 11)])
    world.placeBlocks(at: [Coordinate(column: 1, row: 10)])
    world.placeBlocks(at: [Coordinate(column: 0, row: 9)])
}

for i in 1 ... 3 {
    world.placeBlocks(at: [Coordinate(column: 0, row: 10)])
    world.placeBlocks(at: [Coordinate(column: 1, row: 11)])
}

for i in 1 ... 4 {
    world.placeBlocks(at: [Coordinate(column: 0, row: 11)])
}

//#-editable-code Tocca per inserire il codice

//#-end-editable-code
//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code
