/*:
 **Precondizione:** analizzare ed eseguire il codice
 
 **Obiettivo:** guidare i personaggi affinchè possano raccogliere la gemma posizionata prima di portale del loro stesso colore e salire sulla torre assegnata.

**Sfida aggiuntiva:** raccogliere le gemme sulle torri usando le piattaforme.
* Callout(Autore):
**Chen Xuanting**
*/
//#-hidden-code
import Foundation

public func assessmentPoint() -> AssessmentResults {
    return .pass(message: nil)
}


public func playgroundPrologue() {
    Display.coordinateMarkers = true
    
    world.isCharacterPickerEnabled = false
    world.successCriteria = .custom(.ignoreGoals, { return false })
    registerAssessment(world, assessment: assessmentPoint)
    
    //// ----
    // Any items added or removed after this call will be animated.
    finalizeWorldBuilding(for: world)
    //// ----
}

// MARK: Epilogue

public func playgroundEpilogue() {
    sendCommands(for: world)
}

playgroundPrologue()
typealias Character = Actor
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color, array)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, hide, assessmentPoint(), playgroundPrologue(), playgroundEpilogue())
//#-code-completion(identifier, show, isOnOpenSwitch, if, func, for, while, moveForward(), turnLeft(), turnRight(), collectGem(), toggleSwitch(), isBlocked, north, south, east, west, Water, Expert, Character, (, ), (), turnLockUp(), turnLockDown(), isOnClosedSwitch, var, let, ., =, <, >, ==, !=, +=, +, -, isBlocked, move(distance:), Character, Expert, (, ), (), Portal, color:, (color:), Block, Gem, Stair, Switch, Platform, (onLevel:controlledBy:), onLevel:controlledBy:, PlatformLock, jump(), true, false, turnLock(up:numberOfTimes:), world, place(_:facing:at:), place(_:between:and:), removeBlock(atColumn:row:), isBlockedLeft, &&, ||, !, isBlockedRight, Coordinate, column:row:), (column:row:), column:row:, place(_:at:), remove(at:), insert(_:at:), removeItems(at:), append(_:), count, column(_:), row(_:), removeFirst(), removeLast(), randomInt(from:to:), removeAll(), allPossibleCoordinates, danceLikeNoOneIsWatching(), turnUp(), breakItDown(), grumbleGrumble(), argh(), coordinates(inRows:), coordinates(inColumns:intersectingRows:), name:, (name:), byte, blu, hopper, randomBool(), height(at:), movePlatforms(up:numberOfTimes:), height(at:), coordinates(inColumns:), existingGems(at:), existingSwitches(at:), existingCharacters(at:), existingExperts(at:), existingBlocks(at:), existingWater(at:), placeBlocks(at:), placeWater(at:), placeGems(at:), CharacterName, numberOfBlocks(at:), column, row)
// Selezione delle coordiante per la costruzione dell'isolotto centrale, rimuovendo i blocchi in eccesso
let coordinate1 = world.coordinates(inColumns: [0], intersectingRows: [0,1,2,3,4,5,6,7,8,9,10,11])
for coordinare in coordinate1 {
    world.removeBlock(at:coordinare)
}

let coordinate2 = world.coordinates(inColumns: [1,2,3,4,5,6,7,8,9,10,11], intersectingRows: [11])
for coordinare in coordinate2 {
    world.removeBlock(at:coordinare)
}

let coordinate3 = world.coordinates(inColumns: [11], intersectingRows: [0,1,2,3,4,5,6,7,8,9,10,11])
for coordinare in coordinate3 {
    world.removeBlock(at:coordinare)
}

let coordinate4 = world.coordinates(inColumns: [1,2,3,4,5,6,7,8,9,10], intersectingRows: [0])
for coordinare in coordinate4 {
    world.removeBlock(at:coordinare)
}

let coordinate5 = world.coordinates(inColumns: [1], intersectingRows: [10,9,8,7,6,5,4,3,2,1])
for coordinate in coordinate5 {
    world.placeBlocks(at: [coordinate])
}

let coordinate6 = world.coordinates(inColumns: [2], intersectingRows: [2,3,4,5,6,7,8,9])
for coordinate in coordinate6 {
    for i in 1 ... 2 {
        world.placeBlocks(at: [coordinate])
    }
}

let coordinate7 = world.coordinates(inColumns: [3], intersectingRows: [8,7,6,5,4,3])
for coordinate in coordinate7 {
    for i in 1 ... 3 {
        world.placeBlocks(at: [coordinate])
    }
}

let coordinate8 = world.coordinates(inColumns: [4], intersectingRows: [7,6,5,4])
for coordinate in coordinate8 {
    for i in 1 ... 4 {
        world.placeBlocks(at: [coordinate])
    }
}

let coordinate9 = world.coordinates(inColumns: [6,5], intersectingRows: [5,6])
for coordinate in coordinate9 {
    for i in 1 ... 5 {
        world.placeBlocks(at: [coordinate])
    }
}

let coordinate10 = world.coordinates(inColumns: [2,3,4,5,6,7,8,9,10], intersectingRows: [1])
for coordinate in coordinate10 {
    world.placeBlocks(at: [coordinate])
}

let coordinate11 = world.coordinates(inColumns: [3,4,5,6,7,8,9], intersectingRows: [2])
for coordinate in coordinate11{
    for i in 1 ... 2 {
        world.placeBlocks(at: [coordinate])
    }
}

let coordinate12 = world.coordinates(inColumns: [4,5,6,7,8], intersectingRows: [3])
for coordinate in coordinate12 {
    for i in 1 ... 3 {
        world.placeBlocks(at: [coordinate])
    }
}

let coordinate13 = world.coordinates(inColumns: [5,6,7], intersectingRows: [4])
for coordinate in coordinate13 {
    for i in 1 ... 4 {
        world.placeBlocks(at: [coordinate])
    }
}

let coordinate14 = world.coordinates(inColumns: [10], intersectingRows: [2,3,4,5,6,7,8,9,10])
for coordinate in coordinate14 {
    world.placeBlocks(at: [coordinate])
}

let coordinate15 = world.coordinates(inColumns: [9], intersectingRows: [3,4,5,6,7,8,9])
for coordinate in coordinate15{
    for i in 1 ... 2 {
        world.placeBlocks(at: [coordinate])
    }
}

let coordinate16 = world.coordinates(inColumns: [8], intersectingRows: [4,5,6,7,8])
for coordinate in coordinate16 {
    for i in 1 ... 3 {
        world.placeBlocks(at: [coordinate])
    }
}

let coordinate17 = world.coordinates(inColumns: [7], intersectingRows: [5,6,7])
for coordinate in coordinate17 {
    for i in 1 ... 4 {
        world.placeBlocks(at: [coordinate] )
    }
}

let coordinate18 = world.coordinates(inColumns: [2,3,4,5,6,7,8,9], intersectingRows: [10])
for coordinate in coordinate18 {
    world.placeBlocks(at: [coordinate])
}

let coordinate19 = world.coordinates(inColumns: [3,4,5,6,7,8], intersectingRows: [9])
for coordinate in coordinate19{
    for i in 1 ... 2 {
        world.placeBlocks(at: [coordinate])
    }
}

let coordinate20 = world.coordinates(inColumns: [4,5,6,7], intersectingRows: [8])
for coordinate in coordinate20 {
    for i in 1 ... 3 {
        world.placeBlocks(at: [coordinate])
    }
}

let coordinate21 = world.coordinates(inColumns: [5,6], intersectingRows: [7])
for coordinate in coordinate21 {
    for i in 1 ... 4 {
        world.placeBlocks(at: [coordinate])
    }
}

// Costruzione della torre N.1
for colonne in 11 ... 15 {
    for righe in 11 ... 15 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: 11, row: 11))
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: 11, row: 15))
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: 15, row: 11))
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: 15, row: 15))
}

for i in 1 ... 6 {
    for colonne in 12 ... 14 {
        for righe in 12 ... 14 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: 12, row: 12))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: 14, row: 12))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: 14, row: 14))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: 12, row: 14))
}

for i in 1 ... 10 {
    world.place(Block(), at: Coordinate(column: 13, row: 13))
}

// Posizionamento delle gemme e del portale sulla piattaforma N.1
world.place(Gem(), at: Coordinate(column: 11, row: 11))
world.place(Gem(), at: Coordinate(column: 15, row: 11))
world.place(Gem(), at: Coordinate(column: 11, row: 15))
world.place(Gem(), at: Coordinate(column: 15, row: 15))
world.place(Gem(), at: Coordinate(column: 12, row: 14))
world.place(Gem(), at: Coordinate(column: 14, row: 12))
world.place(Gem(), at: Coordinate(column: 12, row: 12))
world.place(Gem(), at: Coordinate(column: 14, row: 14))
world.place(Portal(color: #colorLiteral(red: 0.9686274528503418, green: 0.7803921699523926, blue: 0.3450980484485626, alpha: 1.0)), at: Coordinate(column: 13, row: 13))

// Rimozione dei blocchi e posizionamento dell'acqua alla base della piattaforma N.1

for coordinate in world.coordinates(inColumns: [12,13,14], intersectingRows: [11,15]){
    world.removeBlock(atColumn: coordinate.column, row: coordinate.row)
    world.placeWater(at: [Coordinate(column:coordinate.column, row: coordinate.row)])
}

for coordinate in world.coordinates(inColumns: [11,15], intersectingRows: [12,13,14]){
    world.removeBlock(atColumn: coordinate.column, row: coordinate.row)
    world.placeWater(at: [Coordinate(column:coordinate.column, row: coordinate.row)])
}

// Costruzione della torre N.2
for colonne in -4 ... 0 {
    for righe in -4 ... 0 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: 0, row: 0))
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: -4, row: 0))
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: -4, row: -4))
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: 0, row: -4))
}


for i in 1 ... 6 {
    for colonne in -3 ... -1 {
        for righe in -3 ... -1 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: -1, row: -1))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: -1, row: -3))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: -3, row: -1))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: -3, row: -3))
}

for i in 1 ... 10 {
    world.place(Block(), at: Coordinate(column: -2, row: -2))
}

// Posizionamento delle gemme e del portale sulla piattaforma N.2

world.place(Gem(), at: Coordinate(column: 0, row: 0))
world.place(Gem(), at: Coordinate(column: -4, row: 0))
world.place(Gem(), at: Coordinate(column: 0, row: -4))
world.place(Gem(), at: Coordinate(column: -4, row: -4))
world.place(Gem(), at: Coordinate(column: -1, row: -1))
world.place(Gem(), at: Coordinate(column: -1, row: -3))
world.place(Gem(), at: Coordinate(column: -3, row: -1))
world.place(Gem(), at: Coordinate(column: -3, row: -3))
world.place(Portal(color: #colorLiteral(red: 0.9254902005195618, green: 0.23529411852359772, blue: 0.10196078568696976, alpha: 1.0)), at: Coordinate(column: -2, row: -2))

// Rimozione dei blocchi e posizionamento dell'acqua alla base della piattaforma N.2
world.removeBlock(atColumn: 0, row: -1)
world.placeWater(at: [Coordinate(column: 0, row: -1)])
world.removeBlock(atColumn: 0, row: -2)
world.placeWater(at: [Coordinate(column: 0, row: -2)])
world.removeBlock(atColumn: 0, row: -3)
world.placeWater(at: [Coordinate(column: 0, row: -3)])
world.removeBlock(atColumn: -1, row: 0)
world.placeWater(at: [Coordinate(column: -1, row: 0)])
world.removeBlock(atColumn: -2, row: 0)
world.placeWater(at: [Coordinate(column: -2, row: 0)])
world.removeBlock(atColumn: -3, row: 0)
world.placeWater(at: [Coordinate(column: -3, row: 0)])
world.removeBlock(atColumn: -1, row: -4)
world.placeWater(at: [Coordinate(column: -1, row: -4)])
world.removeBlock(atColumn: -2, row: -4)
world.placeWater(at: [Coordinate(column: -2, row: -4)])
world.removeBlock(atColumn: -3, row: -4)
world.placeWater(at: [Coordinate(column: -3, row: -4)])
world.removeBlock(atColumn: -4, row: -3)
world.placeWater(at: [Coordinate(column: -4, row: -3)])
world.removeBlock(atColumn: -4, row: -2)
world.placeWater(at: [Coordinate(column: -4, row: -2)])
world.removeBlock(atColumn: -4, row: -1)
world.placeWater(at: [Coordinate(column: -4, row: -1)])
world.place(Portal(color: #colorLiteral(red: 0.9686274528503418, green: 0.7803921699523926, blue: 0.3450980484485626, alpha: 1.0)), at: Coordinate(column: 1, row: 1))
world.place(Portal(color: #colorLiteral(red: 0.9254902005195618, green: 0.23529411852359772, blue: 0.10196078568696976, alpha: 1.0)), at: Coordinate(column: 1, row: 10))

// Costruzione della torre N.3
for colonne in 11 ... 15 {
    for righe in -4 ... 0 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: 11, row: 0))
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: 15, row: 0))
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: 11, row: -4))
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: 15, row: -4))
}

for i in 1 ... 6 {
    for colonne in 12 ... 14 {
        for righe in -3 ... -1 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: 12, row: -1))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: 14, row: -1))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: 12, row: -3))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: 14, row: -3))
}

for i in 1 ... 10 {
    world.place(Block(), at: Coordinate(column: 13, row: -2))
}

// Posizionamento delle gemme e del portale sulla piattaforma N.3
world.place(Gem(), at: Coordinate(column: 11, row: 0))
world.place(Gem(), at: Coordinate(column: 15, row: 0))
world.place(Gem(), at: Coordinate(column: 11, row: -4))
world.place(Gem(), at: Coordinate(column: 15, row: -4))
world.place(Gem(), at: Coordinate(column: 12, row: -1))
world.place(Gem(), at: Coordinate(column: 14, row: -1))
world.place(Gem(), at: Coordinate(column: 12, row: -3))
world.place(Gem(), at: Coordinate(column: 14, row: -3))
world.place(Portal(color: #colorLiteral(red: 0.34117648005485535, green: 0.6235294342041016, blue: 0.16862745583057404, alpha: 1.0)), at: Coordinate(column: 13, row: -2))

// Rimozione dei blocchi e posizionamento dell'acqua alla base della piattaforma N.3
world.removeBlock(atColumn: 11, row: -1)
world.removeBlock(atColumn: 11, row: -2)
world.removeBlock(atColumn: 11, row: -3)
world.removeBlock(atColumn: 12, row: 0)
world.removeBlock(atColumn: 13, row: 0)
world.removeBlock(atColumn: 14, row: 0)
world.removeBlock(atColumn: 15, row: -1)
world.removeBlock(atColumn: 15, row: -2)
world.removeBlock(atColumn: 15, row: -3)
world.removeBlock(atColumn: 14, row: -4)
world.removeBlock(atColumn: 13, row: -4)
world.removeBlock(atColumn: 12, row: -4)
world.placeWater(at: [Coordinate(column: 11, row: -1)])
world.placeWater(at: [Coordinate(column: 11, row: -2)])
world.placeWater(at: [Coordinate(column: 11, row: -3)])
world.placeWater(at: [Coordinate(column: 12, row: 0)])
world.placeWater(at: [Coordinate(column: 13, row: 0)])
world.placeWater(at: [Coordinate(column: 14, row: 0)])
world.placeWater(at: [Coordinate(column: 15, row: -1)])
world.placeWater(at: [Coordinate(column: 15, row: -2)])
world.placeWater(at: [Coordinate(column: 15, row: -3)])
world.placeWater(at: [Coordinate(column: 14, row: -4)])
world.placeWater(at: [Coordinate(column: 13, row: -4)])
world.placeWater(at: [Coordinate(column: 12, row: -4)])

// Costruzione della torre N.4
for colonne in -4 ... 0 {
    for righe in 11 ... 15 {
        world.place(Block(), at: Coordinate(column: colonne, row: righe))
    }
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: 0, row: 11))
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: 0, row: 15))
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: -4, row: 11))
}

for i in 1 ... 8 {
    world.place(Block(), at: Coordinate(column: -4, row: 15))
}

for i in 1 ... 6 {
    for colonne in -3 ... -1 {
        for righe in 12 ... 14 {
            world.place(Block(), at: Coordinate(column: colonne, row: righe))
        }
    }
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: -1, row: 12))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: -3, row: 12))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: -1, row: 14))
}

for i in 1 ... 6 {
    world.place(Block(), at: Coordinate(column: -3, row: 14))
}

for i in 1 ... 10 {
    world.place(Block(), at: Coordinate(column: -2, row: 13))
}

// Posizionamento delle gemme e del portale sulla piattaforma N.3
world.place(Gem(), at: Coordinate(column: 0, row: 11))
world.place(Gem(), at: Coordinate(column: 0, row: 15))
world.place(Gem(), at: Coordinate(column: -4, row: 11))
world.place(Gem(), at: Coordinate(column: -4, row: 15))
world.place(Gem(), at: Coordinate(column: -1, row: 12))
world.place(Gem(), at: Coordinate(column: -3, row: 12))
world.place(Gem(), at: Coordinate(column: -1, row: 14))
world.place(Gem(), at: Coordinate(column: -3, row: 14))
world.place(Portal(color: #colorLiteral(red: 0.239215686917305, green: 0.6745098233222961, blue: 0.9686274528503418, alpha: 1.0)), at: Coordinate(column: -2, row: 13))

// Rimozione dei blocchi e posizionamento dell'acqua alla base della piattaforma N.4
world.removeBlock(atColumn: -1, row: 11)
world.removeBlock(atColumn: -2, row: 11)
world.removeBlock(atColumn: -3, row: 11)
world.removeBlock(atColumn: 0, row: 12)
world.removeBlock(atColumn: 0, row: 13)
world.removeBlock(atColumn: 0, row: 14)
world.removeBlock(atColumn: -4, row: 14)
world.removeBlock(atColumn: -4, row: 13)
world.removeBlock(atColumn: -4, row: 12)
world.removeBlock(atColumn: -1, row: 15)
world.removeBlock(atColumn: -2, row: 15)
world.removeBlock(atColumn: -3, row: 15)
world.placeWater(at: [Coordinate(column: -1, row: 11)])
world.placeWater(at: [Coordinate(column: -2, row: 11)])
world.placeWater(at: [Coordinate(column: -3, row: 11)])
world.placeWater(at: [Coordinate(column: 0, row: 12)])
world.placeWater(at: [Coordinate(column: 0, row: 13)])
world.placeWater(at: [Coordinate(column: 0, row: 14)])
world.placeWater(at: [Coordinate(column: -4, row: 14)])
world.placeWater(at: [Coordinate(column: -4, row: 13)])
world.placeWater(at: [Coordinate(column: -4, row: 12)])
world.placeWater(at: [Coordinate(column: -1, row: 15)])
world.placeWater(at: [Coordinate(column: -2, row: 15)])
world.placeWater(at: [Coordinate(column: -3, row: 15)])
world.place(Portal(color: #colorLiteral(red: 0.34117648005485535, green: 0.6235294342041016, blue: 0.16862745583057404, alpha: 1.0)), at: Coordinate(column: 10, row: 1))
world.place(Portal(color: #colorLiteral(red: 0.239215686917305, green: 0.6745098233222961, blue: 0.9686274528503418, alpha: 1.0)), at: Coordinate(column: 10, row: 10))

// Posizionamento dell'acqua che circonda l'isola centrale
for colonne in 1 ... 10 {
    for righe in 11 ... 15 {
        world.placeWater(at: [Coordinate(column: colonne, row: righe)])
    }
}

for colonne in -4 ... 0 {
    for righe in 1 ... 10 {
        world.placeWater(at: [Coordinate(column: colonne, row: righe)])
    }
}

for colonne in 1 ... 10 {
    for righe in -4 ... 0 {
        world.placeWater(at: [Coordinate(column: colonne, row: righe)])
    }
}

for colonne in 11 ... 15 {
    for righe in 1 ... 10 {
        world.placeWater(at: [Coordinate(column: colonne, row: righe)])
    }
}

// Posizionamento di gemme e piattaforme sull'isolotto centrale
world.place(Gem(), at: Coordinate(column: 1, row: 9))
world.place(Gem(), at: Coordinate(column: 2, row: 1))
world.place(Gem(), at: Coordinate(column: 10, row: 2))
world.place(Gem(), at: Coordinate(column: 9, row: 10))

let redLock = PlatformLock(color: #colorLiteral(red: 0.9254902005195618, green: 0.23529411852359772, blue: 0.10196078568696976, alpha: 1.0))
world.place(redLock, facing: west, at: Coordinate(column: 5, row: 6))
let greenLock = PlatformLock(color: #colorLiteral(red: 0.34117648005485535, green: 0.6235294342041016, blue: 0.16862745583057404, alpha: 1.0))
world.place(greenLock, facing: east, at: Coordinate(column: 6, row: 5))
let yellowLock = PlatformLock(color: #colorLiteral(red: 0.9529411792755127, green: 0.686274528503418, blue: 0.13333334028720856, alpha: 1.0))
world.place(yellowLock, facing: south, at: Coordinate(column: 5, row: 5))
let bluLock = PlatformLock(color: #colorLiteral(red: 0.239215686917305, green: 0.6745098233222961, blue: 0.9686274528503418, alpha: 1.0))
world.place(bluLock, facing: north, at: Coordinate(column: 6, row: 6))

// Posizionamento dei pontili (realizzati con piattaforme) di collegamento all'isolotto centrale
for colonne in -4 ... 0 {
    for righe in 5 ... 6 {
        world.place(Platform(onLevel: 3, controlledBy: redLock), at: Coordinate(column: colonne, row: righe))
    }
}

for colonne in 11 ... 15 {
    for righe in 5 ... 6 {
        world.place(Platform(onLevel: 3, controlledBy: greenLock), at: Coordinate(column: colonne, row: righe))
    }
}

for colonne in 5 ... 6 {
    for righe in -4 ... 0 {
        world.place(Platform(onLevel: 3, controlledBy: yellowLock), at: Coordinate(column: colonne, row: righe))
    }
}

for colonne in 5 ... 6 {
    for righe in 11 ... 15 {
        world.place(Platform(onLevel: 3, controlledBy: bluLock), at: Coordinate(column: colonne, row: righe))
    }
}

// Inizializzazione e posizionamento dei personaggi
let character = Character(name: .blu)
let expert = Expert()
let character2 = Character(name: .hopper)
let character3 = Character(name: .byte)
world.place(character, facing: south, at: Coordinate(column: 6, row: 15))
world.place(character3, facing: north, at: Coordinate(column: 5, row: -4))
world.place(expert, facing: east, at: Coordinate(column: -4, row: 6))
world.place(character2, facing: west, at: Coordinate(column: 15, row: 5))

//#-editable-code Tap to enter code

//#-end-editable-code

//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code
