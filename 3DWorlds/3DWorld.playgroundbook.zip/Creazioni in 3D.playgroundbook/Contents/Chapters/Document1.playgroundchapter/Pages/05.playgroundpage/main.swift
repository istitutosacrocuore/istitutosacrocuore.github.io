/*:
 **Precondizione:** analizzare ed eseguire il codice
 
 **Presentazione:** per raccogliere le gemme ed accendere l'interruttore i personaggi dovranno districarsi nel labirinto.
 
 Per terminare il livello è dunque necessaria la collaborazione!

 
* Callout(Autore):
**Matteo Peng**
*/
//#-hidden-code
import Foundation

public func assessmentPoint() -> AssessmentResults {
    return .pass(message: nil)
}


public func playgroundPrologue() {
    Display.coordinateMarkers = true
    
    world.isCharacterPickerEnabled = false
    world.successCriteria = .custom(.ignoreGoals, { return false })
    registerAssessment(world, assessment: assessmentPoint)
    
    //// ----
    // Any items added or removed after this call will be animated.
    finalizeWorldBuilding(for: world)
    //// ----
}

// MARK: Epilogue

public func playgroundEpilogue() {
    sendCommands(for: world)
}

playgroundPrologue()
typealias Character = Actor
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color, array)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, hide, assessmentPoint(), playgroundPrologue(), playgroundEpilogue())
//#-code-completion(identifier, show, isOnOpenSwitch, if, func, for, while, moveForward(), turnLeft(), turnRight(), collectGem(), toggleSwitch(), isBlocked, north, south, east, west, Water, Expert, Character, (, ), (), turnLockUp(), turnLockDown(), isOnClosedSwitch, var, let, ., =, <, >, ==, !=, +=, +, -, isBlocked, move(distance:), Character, Expert, (, ), (), Portal, color:, (color:), Block, Gem, Stair, Switch, Platform, (onLevel:controlledBy:), onLevel:controlledBy:, PlatformLock, jump(), true, false, turnLock(up:numberOfTimes:), world, place(_:facing:at:), place(_:between:and:), removeBlock(atColumn:row:), isBlockedLeft, &&, ||, !, isBlockedRight, Coordinate, column:row:), (column:row:), column:row:, place(_:at:), remove(at:), insert(_:at:), removeItems(at:), append(_:), count, column(_:), row(_:), removeFirst(), removeLast(), randomInt(from:to:), removeAll(), allPossibleCoordinates, danceLikeNoOneIsWatching(), turnUp(), breakItDown(), grumbleGrumble(), argh(), coordinates(inRows:), coordinates(inColumns:intersectingRows:), name:, (name:), byte, blu, hopper, randomBool(), height(at:), movePlatforms(up:numberOfTimes:), height(at:), coordinates(inColumns:), existingGems(at:), existingSwitches(at:), existingCharacters(at:), existingExperts(at:), existingBlocks(at:), existingWater(at:), placeBlocks(at:), placeWater(at:), placeGems(at:), CharacterName, numberOfBlocks(at:), column, row)
// Inizializzazione degli array di coordinate necessari per la generazione delle pareti del labirinto
let side1 = world.coordinates(inColumns: [3], intersectingRows: [7,8,10,11]) + world.coordinates(inColumns: [0,1,2], intersectingRows: [7]) + world.coordinates(inColumns: [8], intersectingRows: [7,8,10,11]) + world.coordinates(inColumns: [9,10,11], intersectingRows: [7])
let side2 = world.coordinates(inColumns: [8,9,10,11], intersectingRows: [4]) + world.coordinates(inColumns: [8], intersectingRows: [0,1,3])  + world.coordinates(inColumns: [3], intersectingRows: [0,1,3,4]) + world.coordinates(inColumns: [0,1,2], intersectingRows: [4])
let side3 = world.coordinates(inColumns: [6], intersectingRows: [9,8]) + world.coordinates(inColumns: [5], intersectingRows: [9,8]) + world.coordinates(inColumns: [5,6], intersectingRows: [3]) + world.coordinates(inColumns: [1,2], intersectingRows: [5,6])
let side4 = world.coordinates(inColumns: [9,10], intersectingRows: [5,6]) + world.coordinates(inColumns: [5,6], intersectingRows: [5,6])

let sides = side1 + side2 + side3 + side4

// Posizionamento dei blocchi delle pareti
for coordinate in sides {
    for i in 1 ... 5 {
        world.place(Block(), at: coordinate)
    }
}

// Inizializzazione e posizionamento dei personaggi
let hopper = Character(name: .hopper)
world.place(hopper, facing:west ,at: Coordinate(column: 10, row: 9))

let blu = Character(name: .blu)
world.place(blu, facing: east, at: Coordinate(column: 1, row: 2))

let byte = Character(name: .byte)
world.place(byte, facing:west, at: Coordinate(column:10, row: 2))

let expert = Expert()
world.place(expert, facing:east, at: Coordinate(column: 1, row: 9))

// Inizializzazione degli array di coordinate necessarie per il posizionamento dell'acqua
let coordinate2 = world.coordinates(inColumns: [4,5,6,7,], intersectingRows: [10,11,1,0])

for coordinate in coordinate2 {
    world.removeBlock(at:coordinate)
    world.placeWater(at:[coordinate])
}

let coordinate3 = world.coordinates(inColumns: [4,7], intersectingRows: [3,4,5,6,7,8])

for coordinate in coordinate3 {
    world.removeBlock(at:coordinate)
    world.placeWater(at:[coordinate])
}

// Inizializzazione e posizionamento della piattoforma controllata
let blueLock = PlatformLock(color: #colorLiteral(red: 0.25882354378700256, green: 0.7568627595901489, blue: 0.9686274528503418, alpha: 1.0))
world.place(blueLock, facing: west, at: Coordinate(column: 4, row: 9))
world.place(Platform(onLevel: 2, controlledBy: blueLock), at: Coordinate(column: 7, row: 9))

// Posizionamento dei blocchi per la costruzione della rampa di scale
let corners2 = [Coordinate(column: 3, row: 2)]
for coordinate in corners2 {
    world.place(Block(), at: coordinate)
}

let corners3 = [Coordinate(column: 4, row: 2)]
for coordinate in corners3 {
    for i in 1 ... 2 {
        world.place(Block(), at: coordinate)
    }
}

let corners4 = [Coordinate(column: 5, row: 2),]
for coordinate in corners4 {
    for i in 1 ... 3 {
        world.place(Block(), at: coordinate)
    }
}

let corners5 = [Coordinate(column: 6, row: 2),]
for coordinate in corners5 {
    for i in 1 ... 4 {
        world.place(Block(), at: coordinate)
    }
}

// Posizionamento delle scale
world.place(Stair(),facing:west,  at:Coordinate(column: 2, row: 2))
world.place(Stair(),facing:west,  at:Coordinate(column: 3, row: 2))
world.place(Stair(),facing:west,  at:Coordinate(column: 4, row: 2))
world.place(Stair(),facing:west,  at:Coordinate(column: 5, row: 2))
world.place(Stair(),facing:west,  at:Coordinate(column: 6, row: 2))

// Posizionamento di portali, gemme ed interruttori
world.place(Portal(color: #colorLiteral(red: 0.9254902005195618, green: 0.23529411852359772, blue: 0.10196078568696976, alpha: 1.0)), between: Coordinate(column: 7, row: 2), and: Coordinate(column: 6, row: 5))
world.place(Gem(), at: Coordinate(column: 5, row: 6))
world.place(Switch(),at: Coordinate(column: 5, row: 8))
world.place(Gem(), at: Coordinate(column: 5, row: 6))
world.place(Gem(), at: Coordinate(column: 5, row: 3))

//#-editable-code Tocca per inserire il codice

//#-end-editable-code
//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code
