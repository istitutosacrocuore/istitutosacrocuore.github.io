//
//  StoryboardCutsceneViewController.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import UIKit
import PlaygroundSupport

public protocol CutsceneAnimatable {
    func shouldAnimateTowards(forward: Bool) -> Bool
}

@objc(StoryboardCutsceneViewController)
public class StoryboardCutsceneViewController: UIPageViewController {
    private var pagingButtonCenterYConstraint: NSLayoutConstraint?
    private var navigationButtons: SPCNavigationButtons?
    private let bottomMargin: CGFloat = -40.0
    
    private var storyboardName: String = ""
    private var plistName: String = ""
    private var displayPagingButtons: Bool = true
    
    var pageNames = [String]()
    
    var currentPageIndex = 0
    private var inTransition: Bool = false
    private var transitioningPageIndex: Int?
    
    public convenience init(storyboardName: String, plistName: String, displayPagingButtons: Bool) {
        self.init(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
        self.storyboardName = storyboardName
        self.plistName = plistName
        self.displayPagingButtons = displayPagingButtons
    }
    
    override public init(transitionStyle style: UIPageViewController.TransitionStyle, navigationOrientation: UIPageViewController.NavigationOrientation, options: [UIPageViewController.OptionsKey : Any]? = nil) {
        super.init(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
    }
    
    required public init?(coder: NSCoder) {
        super.init(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
    }
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        loadPages()
        
        if displayPagingButtons {
            setupNavigationButtons()
        }
        
        goToPage(at: 0)
        
        NotificationCenter.default.addObserver(forName: .CutsceneAnimationDidComplete, object: nil, queue: nil,
                                               using: { notification in
                                                self.pulseNextButton(notification)
        })
    }
    
    private func setupNavigationButtons() {
        let nav = SPCNavigationButtons(frame: CGRect(x: 0.0, y: 0.0, width: 200.0, height: 44.0))
        nav.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nav)
        
        let buttonCenterYConstraint = nav.centerYAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: bottomMargin)
        pagingButtonCenterYConstraint = buttonCenterYConstraint
        NSLayoutConstraint.activate([
            buttonCenterYConstraint,
            nav.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])

        nav.nextPageButton.addTarget(self, action: #selector(didPressNextButton), for: .touchUpInside)
        nav.prevPageButton.addTarget(self, action: #selector(didPressPreviousButton), for: .touchUpInside)
        nav.nextDocButton.addTarget(self, action: #selector(didPressStartCodingButton), for: .touchUpInside)

        nav.pageCount = UInt(pageNames.count) //UInt(storyboardIds.count)

        self.navigationButtons = nav
    }
    
    private func onTransitionCompletedToPageWith(index pageIndex: Int) {
        self.currentPageIndex = pageIndex
        self.inTransition = false
        self.navigationButtons?.currentPage = UInt(pageIndex + 1)
    }
    
    private func loadPages() {

        guard let cutscenePlistPath = Bundle.main.path(forResource: plistName, ofType: "plist") else {
            print("=== Error: unable to locate plist \(plistName), \(Bundle.main)")
            return
        }
        
        var definition: CutsceneDefinition?
        do {
            let data = try Data(contentsOf: URL(fileURLWithPath: cutscenePlistPath))
            let decoder = PropertyListDecoder()
            definition = try decoder.decode(CutsceneDefinition.self, from: data)
        } catch {
            print(error)
        }
        
        guard let cutsceneDefinition = definition else {
            print("=== Unable to decode CutsceneDefinition from \(cutscenePlistPath)")
            return
        }
        
        self.pageNames = cutsceneDefinition.pages
    }
    
    func goToPage(at pageIndex: Int) {
        guard pageIndex >= 0, pageIndex < pageNames.count, !inTransition else { return }
        inTransition = true
        
        navigationButtons?.nextPageButton.stopPulsing()
        
        var direction: UIPageViewController.NavigationDirection = .forward
        if (pageIndex < currentPageIndex) {
            direction = UIPageViewController.NavigationDirection.reverse
        }
        
        let storyboardId = pageNames[pageIndex]
        let storyboard = UIStoryboard(name: storyboardName, bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: storyboardId)
        viewController.view.bounds = view.bounds
        
        var animated = true
        if let animatableViewController = viewController as? CutsceneAnimatable {
            animated = animatableViewController.shouldAnimateTowards(forward: direction == .forward)
        }
        
        setViewControllers([viewController], direction: direction, animated: animated, completion: { completed in
            if completed && animated {
                self.onTransitionCompletedToPageWith(index: pageIndex)
            }
        })
        
        // If animated is false the completion closure is never called in setViewControllers above so make sure it's called now.
        if !animated {
            onTransitionCompletedToPageWith(index: pageIndex)
        }
    }
    
    //MARK: Actions

    @objc
    private func pulseNextButton(_ notification: Notification) {
        if currentPageIndex == (pageNames.count - 1) {
            // We're looking at the last page, pulse the start coding button.
            navigationButtons?.nextDocButton.startPulsing(scale: 1.05, repeats: 3)
        }
        else {
            navigationButtons?.nextPageButton.startPulsing(scale: 1.15, repeats: 3)
        }
    }
    
    @objc
    private func didPressPreviousButton(_ sender: UIButton) {
        goToPage(at: currentPageIndex - 1)
    }
    
    @objc
    private func didPressNextButton(_ sender: UIButton) {
        goToPage(at: currentPageIndex + 1)
    }
    
    @objc
    private func didPressStartCodingButton(_ sender: UIButton) {
        PlaygroundPage.current.navigateTo(page: .next)
    }
    
    public func makeAdjustments(cutoffPercentage: CGFloat) {
        pagingButtonCenterYConstraint?.constant = bottomMargin - (view.bounds.height * cutoffPercentage / 2)
    }
}

// MARK:-

public extension Notification.Name {

    static let CutsceneAnimationDidComplete = Notification.Name(rawValue: "SwiftCutsceneAnimationDidCompleteNotification")
}

// MARK:-

fileprivate extension UIView {

    func startPulsing(scale: CGFloat, repeats: Int? = nil) {
        let animation = CAKeyframeAnimation(keyPath: "transform.scale")
        animation.duration = 0.8
        animation.autoreverses = false
        animation.keyTimes = [0, 0.5, 1.0]
        animation.values = [1.0, scale, 1.0]
        animation.beginTime = 0
        animation.timingFunction = CAMediaTimingFunction(name: .easeOut)
        animation.fillMode = CAMediaTimingFillMode.both
        animation.repeatCount = (repeats == nil) ? .greatestFiniteMagnitude : Float(repeats ?? 0)
        layer.add(animation, forKey: "transform.scale")
    }

    func stopPulsing() {
        layer.removeAllAnimations()
    }
}
