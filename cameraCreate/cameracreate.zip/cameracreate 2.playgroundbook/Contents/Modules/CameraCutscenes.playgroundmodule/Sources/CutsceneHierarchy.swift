//
//  CutsceneHierarchy.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import Foundation

struct CutsceneDefinition: Decodable {
    var pages: [String]
}
