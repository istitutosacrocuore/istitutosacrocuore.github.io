//
//  LiveViewListener.swift
//  
//  Copyright © 2020 Apple Inc. All rights reserved.
//

import Foundation
import PlaygroundSupport

public class LiveViewListener: PlaygroundRemoteLiveViewProxyDelegate {
    
    public func remoteLiveViewProxy(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy, received message: PlaygroundValue) {
        
        guard let liveViewMessage = ComponentMessage(playgroundValue: message) else { return }
        
        
        switch liveViewMessage {
        case let .event(origin: origin, identity: identity, event: event):
            guard let component = ComponentManager.shared.component(for: identity) else { return }
            component.receive(event, from: origin)
        default:
            break
        }

    }
    
    public func remoteLiveViewProxyConnectionClosed(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy) { }
    
    public init(for proxy: PlaygroundRemoteLiveViewProxy?) {
        proxy?.delegate = self
    }
}

