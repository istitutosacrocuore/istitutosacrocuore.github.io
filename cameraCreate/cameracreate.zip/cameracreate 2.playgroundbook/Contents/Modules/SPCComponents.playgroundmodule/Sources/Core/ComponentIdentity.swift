//
//  ComponentIdentity.swift
//  
//  Copyright © 2020 Apple Inc. All rights reserved.
//

import Foundation

public struct ComponentIdentity: Equatable, Codable, Hashable {
    public var name = ""
    public var identifier = ""
    
    public func hash(into hasher: inout Hasher) {
        hasher.combine(identifier)
    }
    
    public static func ==(lhs: ComponentIdentity, rhs: ComponentIdentity) -> Bool {
        return (lhs.identifier == rhs.identifier)
    }
    
    public init() { }
        
    public init(name: String, identifier: String = "") {
        self.name = name
        self.identifier = identifier.isEmpty ? UUID().uuidString : identifier
    }
}
