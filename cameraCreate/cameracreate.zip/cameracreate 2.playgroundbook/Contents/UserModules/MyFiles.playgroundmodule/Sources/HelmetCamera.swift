import Foundation
import SPCComponents

//#-localizable-zone(StartingPointHelmetCamera01)
// Space helmet camera component, similar to SwiftyCamera. It’s a subclass of Space.
//#-end-localizable-zone
public class HelmetCamera: Space {
//#-localizable-zone(StartingPointHelmetCamera02)
    // Create the components.
//#-end-localizable-zone

    let cameraView = CameraView()
    let coverImageView = ImageView()
    let shutterButton = Button()
    let frontRearButton = Button()
    
//#-localizable-zone(StartingPointHelmetCamera03)
    // The default size of the camera if its size is not set.
//#-end-localizable-zone

    public override var intrinsicSize: Size {
        return Size(width: 400, height: 400)
    }
//#-localizable-zone(StartingPointHelmetCamera04)
    // Constants for the position and size of each component
    // These are all based on the intrinsicSize.
//#-end-localizable-zone
    let cameraViewPosition = Point(x: -18, y: 34)
    let cameraViewSize = Size(width: 200, height: 200)
    let coverImageViewPosition = Point(x: 0, y: 0)
    let frontRearButtonPosition = Point(x: -20, y: 145)
    let frontRearButtonSize = Size(width: 30, height: 30)
    let shutterButtonPosition = Point(x:  -22, y: -128)
    let shutterButtonSize = Size(width: 40, height: 40)

//#-localizable-zone(StartingPointHelmetCamera05)
    // Output for photos taken by the camera. Sends an event notification with the new image.
//#-end-localizable-zone
    public var photoTaken = Output<Image>()
//#-localizable-zone(StartingPointHelmetCamera06)
    // Initialize the camera class.
//#-end-localizable-zone
    public override init() {
//#-localizable-zone(StartingPointHelmetCamera07)
        // Initialize the space superclass.
//#-end-localizable-zone
        super.init()
//#-localizable-zone(StartingPointHelmetCamera08)
        // Set the properties of the space.
//#-end-localizable-zone
        backgroundColor =  #colorLiteral(red: 0.05882352963, green: 0.180392161, blue: 0.2470588237, alpha: 1)
        borderColor = #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
        borderWidth = 4
        cornerRadius = 10
//#-localizable-zone(StartingPointHelmetCamera09)
        // Set the image that is placed over the camera view.
//#-end-localizable-zone
        coverImageView.image = #imageLiteral(resourceName: "spaceHelmet")
//#-localizable-zone(StartingPointHelmetCamera10)
        // Use the same image as the camera overlay image.
//#-end-localizable-zone
        cameraView.overlayImage = #imageLiteral(resourceName: "spaceHelmet")
//#-localizable-zone(StartingPointHelmetCamera10a)
        // Display all of the overlay image.
//#-end-localizable-zone
        cameraView.isOverlayImageCropped = false

//#-localizable-zone(StartingPointHelmetCamera11)
        // Set the properties of the buttons.
//#-end-localizable-zone
        frontRearButton.backgroundColor = .clear
        frontRearButton.image = #imageLiteral(resourceName: "rocketArrowButton")
        shutterButton.backgroundColor = .clear
        shutterButton.image = #imageLiteral(resourceName: "rocketStarButton")
        
//#-localizable-zone(StartingPointHelmetCamera12)
        // Add the components. Their position and size are updated later.
//#-end-localizable-zone
        add(cameraView, at: Point(x: 0, y: 0))
        add(coverImageView, at: Point(x: 0, y: 0))
        add(frontRearButton, at: Point(x: 180, y: -80))
        add(shutterButton, at: Point(x: 160, y: 80))
 
//#-localizable-zone(StartingPointHelmetCamera13)
        // Connect the components.
//#-end-localizable-zone
        frontRearButton.pressed.connect(to: switchCamera)
        shutterButton.pressed.connect(to: cameraView.trigger)

//#-localizable-zone(StartingPointHelmetCamera14)
        // Connect the photoTaken event handler.
//#-end-localizable-zone
        cameraView.photoTaken.connect(to: onPhotoTaken)

//#-localizable-zone(StartingPointHelmetCamera15)
        // Connect the sizeChanged event handler.
//#-end-localizable-zone
        sizeChanged.connect(to: onSizeChanged)

//#-localizable-zone(StartingPointHelmetCamera16)
        // Update the layout.
//#-end-localizable-zone
        updateLayoutFor(cameraSize: intrinsicSize)
    }

//#-localizable-zone(StartingPointHelmetCamera17)
    // Starts the camera.
//#-end-localizable-zone
    public func start() {
        cameraView.isUsingFrontCamera = true
        cameraView.start()
    }
//#-localizable-zone(StartingPointHelmetCamera18)
    // Switches between the front and rear camera.
//#-end-localizable-zone
    func switchCamera(pulse: Pulse) {
        cameraView.isUsingFrontCamera = !cameraView.isUsingFrontCamera
    }
//#-localizable-zone(StartingPointHelmetCamera19)
    // Photo taken event handler. Sends a notification through the camera’s photoTaken output.
//#-end-localizable-zone
    func onPhotoTaken(image: Image) {
        photoTaken.notifyInputs(image)
    }
//#-localizable-zone(StartingPointHelmetCamera20)
    // Size changed event handler. Updates the layout of the components for the new size.
//#-end-localizable-zone
    func onSizeChanged(size: Size) {
        updateLayoutFor(cameraSize: size)
    }

//#-localizable-zone(StartingPointHelmetCamera21)
    // Set the position and size of each component by scaling based on the ratio between the camera size and its intrinsic size.
//#-end-localizable-zone
    func updateLayoutFor(cameraSize: Size) {
//#-localizable-zone(StartingPointHelmetCamera22)
        // Scale size and position of components to new camera size.
//#-end-localizable-zone
        coverImageView.position = scaledPositionFor(coverImageViewPosition, within: cameraSize)
        coverImageView.size = scaledSizeFor(intrinsicSize, within: cameraSize)
        cameraView.position = scaledPositionFor(cameraViewPosition, within: cameraSize)
        cameraView.size = scaledSizeFor(cameraViewSize, within: cameraSize)
        shutterButton.position = scaledPositionFor(shutterButtonPosition, within: cameraSize)
        shutterButton.size = scaledSizeFor(shutterButtonSize, within: cameraSize)
        frontRearButton.position = scaledPositionFor(frontRearButtonPosition, within: cameraSize)
        frontRearButton.size = scaledSizeFor(frontRearButtonSize, within: cameraSize)
        cameraView.overlayImageScale = coverImageView.size.width / cameraView.size.width
        cameraView.overlayImageOffset = Point(x: -cameraView.position.x, y: -cameraView.position.y)
    }

//#-localizable-zone(StartingPointHelmetCamera23)
    // Returns a position scaled for the size of the camera space relative to its intrinsic size.
//#-end-localizable-zone
    func scaledPositionFor(_ position: Point, within spaceSize: Size) -> Point {
        let scale = intrinsicSize.scaleToFit(within: spaceSize)
        return Point(x: position.x * scale, y: position.y * scale)
    }
    
//#-localizable-zone(StartingPointHelmetCamera24)
    // Returns a size scaled for the size of the camera space relative to its intrinsic size.
//#-end-localizable-zone
    func scaledSizeFor(_ size: Size, within spaceSize: Size) -> Size {
        let scale = intrinsicSize.scaleToFit(within: spaceSize)
        return Size(width: size.width * scale, height: size.height * scale)
    }
}
