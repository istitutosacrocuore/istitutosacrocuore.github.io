import Foundation
import SPCComponents

// -----------------------------------
//#-localizable-zone(StartingPointHelperFunctions01)
// Points Around Corner
//#-end-localizable-zone
// -----------------------------------
//#-localizable-zone(StartingPointHelperFunctions02)
// Returns an array of count points randomly scattered around the corners of the space.
//#-end-localizable-zone
public func pointsAroundCornersOf(space: Space, count: Int) -> [Point] {
    var points: [Point] = []
    while points.count < count {
        let x = Double.random(in: -0.5...0.5)
        let y = Double.random(in: -0.5...0.5)
        let radius = sqrt(x * x + y * y)
        if radius > 0.425 {
            points.append(Point(x: x * space.size.width, y: y * space.size.height))
        }
    }
    return points
}


// -----------------------------------
//#-localizable-zone(StartingPointHelperFunctions03)
// Random Points Within
//#-end-localizable-zone
// -----------------------------------
//#-localizable-zone(StartingPointHelperFunctions04)
// Returns an array of count points randomly scattered within the space.
//#-end-localizable-zone
public func randomPointsWithin(space: Space, count: Int) -> [Point] {
    var points: [Point] = []
    while points.count < count {
        let x = Double.random(in: -0.5...0.5)
        let y = Double.random(in: -0.5...0.5)
        points.append(Point(x: x * space.size.width, y: y * space.size.height))
    }
    return points
}

// -----------------------------------
//#-localizable-zone(StartingPointHelperFunctions05)
// Points Around Border
//#-end-localizable-zone
// -----------------------------------
//#-localizable-zone(StartingPointHelperFunctions06)
// Returns an array of points inset from the border of the space.
//#-end-localizable-zone
public func pointsAroundBorderOf(space: Space, margin: Double, count: Int) -> [Point] {
    var points: [Point] = []
    
//#-localizable-zone(StartingPointHelperFunctions07)
    // Calculate emoji spacing.
//#-end-localizable-zone
    let dx = (space.size.width - (margin * 2)) / Double(count - 1)
    let dy = (space.size.height - (margin * 2)) / Double(count - 1)

//#-localizable-zone(StartingPointHelperFunctions08)
    // Calculate top-left and bottom-right positions.
//#-end-localizable-zone
    let topLeft = Point(x: -(space.size.width / 2), y: (space.size.height / 2))
    let bottomRight = Point(x: (space.size.width / 2), y: -(space.size.height / 2))

//#-localizable-zone(StartingPointHelperFunctions09)
    // Positions along top border.
//#-end-localizable-zone
    var x = topLeft.x + margin
    var y = topLeft.y - margin
    for _ in 0..<count {
        points.append(Point(x: x, y: y))
        x += dx
    }
    
//#-localizable-zone(StartingPointHelperFunctions10)
    // Positions along right border.
//#-end-localizable-zone
    x = bottomRight.x - margin
    y = topLeft.y - margin - dy
    for _ in 0..<(count - 2) {
        points.append(Point(x: x, y: y))
        y -= dy
    }

//#-localizable-zone(StartingPointHelperFunctions11)
    // Positions along bottom border.
//#-end-localizable-zone
    x = topLeft.x + margin
    y = bottomRight.y + margin
    for _ in 0..<count {
        points.append(Point(x: x, y: y))
        x += dx
    }
    
//#-localizable-zone(StartingPointHelperFunctions12)
    // Positions along left border.
//#-end-localizable-zone
    x = topLeft.x + margin
    y = topLeft.y - margin - dy
    for _ in 0..<(count - 2) {
        points.append(Point(x: x, y: y))
        y -= dy
    }
    
    return points
}
