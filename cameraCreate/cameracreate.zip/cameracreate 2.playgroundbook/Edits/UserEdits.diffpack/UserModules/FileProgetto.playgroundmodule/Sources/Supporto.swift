import Foundation
import UIKit

// *************************************************************
// Funzioni pubbliche di supporto alle operazioni di decorazione
// *************************************************************
 

// Restituisce un array di punti sparsi casualmente attorno agli angoli dello spazio.
public func pointsAroundCornersOf(space: Space, count: Int) -> [Point] {
    var points: [Point] = []
    while points.count < count {
        let x = Double.random(in: -0.5...0.5)
        let y = Double.random(in: -0.5...0.5)
        let radius = sqrt(x * x + y * y)
        if radius > 0.425 {
            points.append(Point(x: x * space.size.width, y: y * space.size.height))
        }
    }
    return points
}

// Restituisce un array di punti sparsi casualmente all'interno dello spazio.
public func randomPointsWithin(space: Space, count: Int) -> [Point] {
    var points: [Point] = []
    while points.count < count {
        let x = Double.random(in: -0.5...0.5)
        let y = Double.random(in: -0.5...0.5)
        points.append(Point(x: x * space.size.width, y: y * space.size.height))
    }
    return points
}

// Restituisce un array di punti inseriti dal bordo dello spazio.
public func pointsAroundBorderOf(space: Space, margin: Double, count: Int) -> [Point] {
    var points: [Point] = []
    
    // Calcola la spaziatura delle emoji.
    let dx = (space.size.width - (margin * 2)) / Double(count - 1)
    let dy = (space.size.height - (margin * 2)) / Double(count - 1)
    
    // Calcola le posizioni in alto a sinistra e in basso a destra.
    let topLeft = Point(x: -(space.size.width / 2), y: (space.size.height / 2))
    let bottomRight = Point(x: (space.size.width / 2), y: -(space.size.height / 2))
    
    // Posizioni lungo il bordo superiore.
    var x = topLeft.x + margin
    var y = topLeft.y - margin
    for _ in 0..<count {
        points.append(Point(x: x, y: y))
        x += dx
    }
    
    // Posizioni lungo il bordo destro.
    x = bottomRight.x - margin
    y = topLeft.y - margin - dy
    for _ in 0..<(count - 2) {
        points.append(Point(x: x, y: y))
        y -= dy
    }
    
    // Posizioni lungo il bordo inferiore.
    x = topLeft.x + margin
    y = bottomRight.y + margin
    for _ in 0..<count {
        points.append(Point(x: x, y: y))
        x += dx
    }
    
    // Posizioni lungo il bordo sinistro.
    x = topLeft.x + margin
    y = topLeft.y - margin - dy
    for _ in 0..<(count - 2) {
        points.append(Point(x: x, y: y))
        y -= dy
    }
    
    return points
}



