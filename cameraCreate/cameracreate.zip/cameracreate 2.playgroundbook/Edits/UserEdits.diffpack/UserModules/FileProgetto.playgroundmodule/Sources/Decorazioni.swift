import Foundation
import SPCComponents

// **************************************************
// Funzioni di servizio per la decorazione delle foto
// **************************************************


// -----------------------------------
// Adesivo
// -----------------------------------
public func decorateWithSticker(space: Space) {
    // Crea l'adesivo.
    let sticker = ImageView()
    
    // Imposta le proprietà dell'adesivo.
    sticker.image = #imageLiteral(resourceName: "cf_ccPhotoBoard001.png")
    sticker.scale = 0.4
    
    // Aggiungi l'adesivo all'area di lavoro.
    space.add(sticker, at: Point(x: 105, y: 85))
}

// -----------------------------------
// Etichetta
// -----------------------------------
public func decorateWithLabel(space: Space) {
    // Crea un'etichetta e imposta il testo.
    let label = Label()
    // Modifica la stringa per modificare il testo mostrato.
    label.text = "👩‍🦱❤️🐴"
    
    // Applica uno stile all'etichetta e imposta altre proprietà.
    let style = TextStyle(.Copperplate, fontSize: 24, color: .orange)
    label.textStyle = style
    label.rotation = 45.0
    label.shadowColor = #colorLiteral(red: 0.9764705896, green: 0.850980401, blue: 0.5490196347, alpha: 1)
    label.shadowOffset = Size(width: 1, height: 1)
    
    // Aggiungi l'etichetta allo spazio.
    space.add(label, at: Point(x: 0, y: 0))
}

// -----------------------------------
// Emoji fiore
// -----------------------------------
public func decorateWithFlowers(space: Space, count: Int) {
    let choices = ["🍀", "🌸", "🌼", "🌻", "🌹", "💐"]
    
    let points = randomPointsWithin(space: space, count: count)
    
    // Aggiungi un'etichetta in ciascuna posizione.
    for position in points {
        let index = Int.random(in: 0..<choices.count)
        let emoji = choices[index]
        let label = Label()
        label.text = emoji
        label.scale = Double.random(in: 1...2)
        label.rotation = Double.random(in: -30...30)
        space.add(label, at: position)
    }
}

// -----------------------------------
// Emoji cuori
// -----------------------------------
public func decorateWithHearts(space: Space, count: Int) {
    let choices = ["💙", "🧡", "💛", "💚", "💜", "❤️"]
    
    let points = pointsAroundCornersOf(space: space, count: count)
    
    // Aggiungi un'etichetta in ciascuna posizione.
    for position in points {
        let index = Int.random(in: 0..<choices.count)
        let emoji = choices[index]
        let label = Label()
        label.text = emoji
        label.scale = Double.random(in: 1...2.5)
        label.rotation = Double.random(in: -30...30)
        space.add(label, at: position)
    }
}

// -----------------------------------
// Fiocchi di neve
// -----------------------------------
public func decorateWithSnowflakes(space: Space, count: Int) {
    let choices = ["❅", "❆"]
    
    let points = randomPointsWithin(space: space, count: count)
    
    // Aggiungi un'etichetta in ciascuna posizione.
    for position in points {
        let index = Int.random(in: 0..<choices.count)
        let emoji = choices[index]
        let label = Label()
        label.textStyle = TextStyle(.SystemFontRegular, fontSize: 14, color: #colorLiteral(red: 0.937254902, green: 0.937254902, blue: 0.937254902, alpha: 1), alignment: .center)
        label.text = emoji
        label.scale = Double.random(in: 1...4)
        label.rotation = Double.random(in: -30...30)
        label.alpha = Double.random(in: 0.5...1)
        space.add(label, at: position)
    }
}

// -----------------------------------
// Stelle
// -----------------------------------
public func decorateWithStars(space: Space, count: Int) {
    let choices = ["✯", "✷", "✵", "٭"]
    let colors: [Color] = [#colorLiteral(red: 0.9995340705, green: 0.988355577, blue: 0.4726552367, alpha: 1), #colorLiteral(red: 0.9764705896, green: 0.850980401, blue: 0.5490196347, alpha: 1), #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), #colorLiteral(red: 0.9994240403, green: 0.9855536819, blue: 0, alpha: 1)]
    
    let points = pointsAroundCornersOf(space: space, count: count)
    
    // Aggiungi un'etichetta in ciascuna posizione.
    for position in points {
        let index = Int.random(in: 0..<choices.count)
        let emoji = choices[index]
        let colorIndex = Int.random(in: 0..<colors.count)
        let color = colors[colorIndex]
        let label = Label()
        label.textStyle = TextStyle(.SystemFontRegular, fontSize: 14, color: color, alignment: .center)
        label.text = emoji
        label.scale = Double.random(in: 1...4)
        label.rotation = Double.random(in: -30...30)
        label.alpha = Double.random(in: 0.5...1)
        space.add(label, at: position)
    }
}


// -----------------------------------
// Adesivi
// -----------------------------------
public func decorateWithImages(space: Space, count: Int) {
    let images: [Image]  = [#imageLiteral(resourceName: "cf_sticker006"), #imageLiteral(resourceName: "cf_sticker010")]
    
    let points = randomPointsWithin(space: space, count: count)
    
    // Aggiungi un'immagine adesivo in ciascuna posizione.
    for position in points {
        let index = Int.random(in: 0..<images.count)
        let image = images[index]
        let sticker = ImageView()
        sticker.image = image
        sticker.scale = Double.random(in: 1...10)
        sticker.rotation = Double.random(in: -30...30)
        sticker.alpha = Double.random(in: 0.5...1)
        space.add(sticker, at: position, size: Size(width: 20, height: 20))
    }
}

// -----------------------------------
// Cornice di emoji
// -----------------------------------
public func decorateWithEmojiBorder(space: Space, emoji: String, count: Int) {
    
    let points = pointsAroundBorderOf(space: space, margin: 15, count: count)
    
    // Aggiungi un'etichetta in ciascuna posizione.
    for position in points {
        let label = Label()
        label.textStyle = TextStyle(.Georgia, fontSize: 24)
        label.text = emoji
        space.add(label, at: position)
    }
}



// -----------------------------------
// Immagine
// -----------------------------------

public func addImage(_ image: Image, to space: Space, at position: Point, size: Size = Size(width: 100, height: 100) ) {
    let imageView = ImageView()
    imageView.image = image
    space.add(imageView, at: position, size: size)
}

// Testo
public func addLabel(_ text: String, fontSize: Double, color: Color, to space: Space, at position: Point) {
    let label = Label()
    let style = TextStyle(.ArialRoundedMTBold, fontSize: fontSize, color: color )
    label.textStyle = style
    label.shadowColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
    label.shadowOffset = Size(width: 1, height: 1)
    label.text = text
    space.add(label, at: position)
}

