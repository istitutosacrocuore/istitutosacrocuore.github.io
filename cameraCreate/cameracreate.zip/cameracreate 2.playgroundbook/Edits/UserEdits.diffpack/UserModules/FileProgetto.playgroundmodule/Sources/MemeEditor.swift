import Foundation
import SPCComponents

// **********************************************************************
// Personalizza la funzione generaMeme() per creare il tuo Meme preferito
// **********************************************************************


public func generaMeme(spazio: Space){
    
    // Richiama la funzione addLabel() per posizionare una o più etichette testo personalizzate sulla vista Immagine (da editare)
    
    addLabel("👑", fontSize: 45, color: #colorLiteral(red: 0.960784375667572, green: 0.9254902005195618, blue: -9.626150188069005e-08, alpha: 1.0), to: spazio, at: Point(x: 0, y: 85))
    
    addLabel("KEEP", fontSize: 30, color: #colorLiteral(red: 0.960784375667572, green: 0.9254902005195618, blue: -9.626150188069005e-08, alpha: 1.0), to: spazio, at: Point(x: 0, y: 40))
  
    addLabel("CALM", fontSize: 30, color: #colorLiteral(red: 0.960784375667572, green: 0.9254902005195618, blue: -9.626150188069005e-08, alpha: 1.0), to: spazio, at: Point(x: 0, y: 10))
    
    addLabel("AND", fontSize: 20, color: #colorLiteral(red: 0.960784375667572, green: 0.9254902005195618, blue: -9.626150188069005e-08, alpha: 1.0), to: spazio, at: Point(x: 0, y: -20))
    
    addLabel("CODE", fontSize: 30, color: #colorLiteral(red: 0.960784375667572, green: 0.9254902005195618, blue: -9.626150188069005e-08, alpha: 1.0), to: spazio, at: Point(x: 0, y: -55))
    
    addLabel("ON", fontSize: 30, color: #colorLiteral(red: 0.960784375667572, green: 0.9254902005195618, blue: -9.626150188069005e-08, alpha: 1.0), to: spazio, at: Point(x: 0, y: -85))
}

