import Foundation
import SPCComponents

// ***********************
// MACRO Compomente Editor
// ***********************

public class FotoEditor: Space {
    
    // Definisci uno spazio per la Vista Immagine (da editare)
    public let spazioFoto = Space()
    
    // Crea i componenti
    let immagine = ImageView()
    let pulsanteSalva = Button()
    let pulsanteCancella = Button()
    let pulsanteCondivisione = ActivityButton()
    let pulsanteSelettoreDecorazione = Button()
    let pulsanteDecora = Button()
    let pulsanteDecoraConTesto = Button()
    var selettoreDecorazione = 0
    
    // Definisci le proprietà per gestire il collegamento tra l'Editor e la Camera
    public var input = Input<Image>()
    public var fotoScattata = Output<Image>()
    
    public override init() {
        // Inizializza lo Spazio contenitore
        super.init()
        
        // Inizializza la Vista FotoEditor
        backgroundColor = #colorLiteral(red: 1.0026154518127441, green: 0.8410214781761169, blue: 0.4673088788986206, alpha: 1.0)
        borderColor = #colorLiteral(red: 0.18823501467704773, green: 0.5901960730552673, blue: 0.6627453565597534, alpha: 1.0)
        borderWidth = 3
        cornerRadius = 30
        immagine.image = #imageLiteral(resourceName: "cf_floatyCloudsWP.png")
        immagine.borderColor = #colorLiteral(red: 1.0000003576278687, green: 0.4156862795352936, blue: 4.8130750940345024e-08, alpha: 1.0)
        immagine.borderWidth = 1

        // Crea una funzione di servizio per applicare uno stile ai Pulsanti
        func impostaStilePulsante(button: Button, emoji: String, zoom: Double) {
            button.title = emoji
            button.backgroundColor = .clear
            button.scale = zoom
        }
        
        // Applica uno stile ai componenti
        pulsanteCancella.image = #imageLiteral(resourceName: "cf_cancel-icon.png")
        pulsanteSalva.image = #imageLiteral(resourceName: "cf_save-icon.png")
        pulsanteCondivisione.image = #imageLiteral(resourceName: "cf_share-icon.png")
        impostaStilePulsante(button: pulsanteSelettoreDecorazione, emoji: "\u{1F4CC}", zoom: 2.0)
        impostaStilePulsante(button: pulsanteDecora, emoji: "🪄", zoom: 2.3)
        impostaStilePulsante(button: pulsanteDecoraConTesto, emoji: "✏️", zoom: 2.0)
        
        // Aggiungi la Vista Immagine (da editare) allo Spazio
        add(spazioFoto, at: Point(x: 0, y: 0), size: Size(width: 250, height: 250))
        
        // Aggiungi tutti gli altri componenti allo Spazio
        spazioFoto.add(immagine, at: Point(x: 0, y: 0), size: Size(width: 250, height: 250))
        add(pulsanteCondivisione, at: Point(x: 170, y: 90))
        add(pulsanteSalva, at: Point(x: 170, y: 00))
        add(pulsanteCancella, at: Point(x: 170, y: -90))
        add(pulsanteSelettoreDecorazione, at: Point(x: -170, y: 90))
        add(pulsanteDecora, at: Point(x: -170, y: 00))
        add(pulsanteDecoraConTesto, at: Point(x: -170, y: -90))
                  
        // La foto scattata viene inviata e visualizza nell'editor
        input = Input<Image>({ image in
            self.immagine.image = image
            })
        
        // Connetti i componenti
        pulsanteSalva.pressed.connect(to: pulsanteSalvaSelezionato)
        spazioFoto.snapshotTaken.connect(to: snapshotAcquisito)
        pulsanteCancella.pressed.connect(to: pulsanteCancellaSelezionato)
        pulsanteDecora.pressed.connect(to: pulsanteDecoraSelezionato)
        pulsanteSelettoreDecorazione.pressed.connect(to: pulsanteSelettoreDecorazioneSelezionato)
        pulsanteDecoraConTesto.pressed.connect(to: pulsanteDecoraConTestoSelezionato)
        
        //Gestici le reazioni dei pulsanti alla selezione tramite l'evento tap (Pulse)
        func pulsanteSalvaSelezionato(pulse: Pulse) {
            spazioFoto.takeSnapshot()
        }
        
        func pulsanteApplicaImmaginiSelezionato(pulse: Pulse) {
            decorateWithImages(space: spazioFoto, count: 2)
        }
        
        // Gestisci la selezione degli strumenti per le decorazioni 
        // A ogni tap sul pulsanteSelettoreDecorazione proponi uno strumento diverso in maniera ciclica (8 alternative possibili)
        func pulsanteSelettoreDecorazioneSelezionato(tap: Pulse) {
            if selettoreDecorazione < 7 {
                selettoreDecorazione += 1
            } else {
                selettoreDecorazione = 0
                }
            impostaImmaginePulsanteDecorazione(selettoreDecorazione)
        }
        
        // Aggiorna l'aspetto del pulsanteSelettoreDecorazione richiesto 
        func impostaImmaginePulsanteDecorazione(_ selettoreDecorazione: Int) {
            switch selettoreDecorazione {
            case 0:
                impostaStilePulsante(button: pulsanteSelettoreDecorazione, emoji: "\u{1F4CC}", zoom: 2.0)
            case 1:
                impostaStilePulsante(button: pulsanteSelettoreDecorazione, emoji: "📚", zoom: 2.0)
            case 2:
                impostaStilePulsante(button: pulsanteSelettoreDecorazione, emoji: "🌺", zoom: 2.0)
            case 3:
                impostaStilePulsante(button: pulsanteSelettoreDecorazione, emoji: "💗", zoom: 2.0)
            case 4:
                impostaStilePulsante(button: pulsanteSelettoreDecorazione, emoji: "❄️", zoom: 2.0)
            case 5:
                impostaStilePulsante(button: pulsanteSelettoreDecorazione, emoji: "⭐️", zoom: 2.0)
            case 6:
                impostaStilePulsante(button: pulsanteSelettoreDecorazione, emoji: "🖼️", zoom: 2.0)
            default:
                impostaStilePulsante(button: pulsanteSelettoreDecorazione, emoji: "🤖", zoom: 2.0)
            }
        }
        
        // Associa al pulsanteSelettoreDecorazione selezionato la funzionalità corrispondente
        func pulsanteDecoraSelezionato(pulse: Pulse) {
            switch selettoreDecorazione {
            case 0:
                decorateWithSticker(space: spazioFoto)
            case 1:
               decorateWithLabel(space: spazioFoto)
            case 2:
                decorateWithFlowers(space: spazioFoto, count: 5)
            case 3:
                decorateWithHearts(space: spazioFoto, count: 5)
            case 4:
                decorateWithSnowflakes(space: spazioFoto, count: 5)
            case 5:
                decorateWithStars(space: spazioFoto, count: 5)
            case 6:
                decorateWithImages(space: spazioFoto, count: 5)
            default:
                decorateWithEmojiBorder(space: spazioFoto, emoji: "🤖", count: 5)
            }
        }
        
        func pulsanteDecoraConTestoSelezionato(tap: Pulse) {
            generaMeme(spazio: spazioFoto)
        }
        
        func pulsanteCancellaSelezionato(pulse: Pulse) {
            for componente in spazioFoto.subcomponents {
                if componente != immagine {
                    spazioFoto.remove(componente)
                }
            }
        }
        
        // Notifica l'evento immagine acquisita da inviare all'Editor
        func snapshotAcquisito(image: Image) {
            fotoScattata.notifyInputs(image)
        }
    }
}



