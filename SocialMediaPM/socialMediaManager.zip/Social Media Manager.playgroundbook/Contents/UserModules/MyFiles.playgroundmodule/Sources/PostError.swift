// Gestioni errori legati alla gestione dei Post
public enum PostError: Error {
	
	/// L'indice fornito non è valido
    case invalidIndexForPost
    
    var localizedDescription: String {
        switch self {
        case .invalidIndexForPost:
            return "No posts where found at the given index." 
        }
    }
}
