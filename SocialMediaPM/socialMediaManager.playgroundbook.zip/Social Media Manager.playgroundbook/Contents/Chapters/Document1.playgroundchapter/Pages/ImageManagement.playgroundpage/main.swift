//: # Gestisci le tue Immagini
//: Nella `live` `view` è disponibile un tutorial che propone i passaggi necessari per gestire immagini, testo, simboli o emoji come elementi grafici. \
//: **Obiettivo**: imparerai a **personalizzare** la tua `galleria` `immagini`
//:
//:
//: - Note:
//: É possibile aggiungere una sola immagine a ciascun post creato.
//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2020 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
//#-end-hidden-code
//#-editable-code Visualizza il tutorial
//#-end-editable-code
