//
//  AnswersCommand.swift
//  
//  Copyright © 2016-2020 Apple Inc. All rights reserved.
//

import UIKit
import PlaygroundSupport

enum AnswersCommand {
    case show(String)
    case showImage(UIImage)
    case ask(AnswersValueType, String)
    case submit(String)
    case clear
    case pauseUntilTapped(String)
    
    // MARK:- Mail Sharing #CustomMethod
    case shareWithEmail(String, Int, Int, Data, String, String, Int, String, String)
    
}

extension AnswersCommand {
    init?(_ playgroundValue: PlaygroundValue) {
        guard case let .dictionary(dict) = playgroundValue else {
            return nil
        }
        
        guard case let .string(command)? = dict["Command"] else {
            return nil
        }
        
        switch command {
        case "Show":
            guard case let .string(string)? = dict["String"] else {
                return nil
            }
            
            self = .show(string)
        case "ShowImage":
            guard case let .data(imageData) = dict["ImageData"],
                let image = UIImage.init(data: imageData) else {
                return nil
            }

            self = .showImage(image)
        case "Ask":
            guard let valueType = dict["ValueType"] != nil ? AnswersValueType(dict["ValueType"]!) : .string,
                  case let .string(placeholder)? = dict["Placeholder"] else {
                return nil
            }
            
            self = .ask(valueType, placeholder)
        case "Submit":
            guard case let .string(stringValue)? = dict["StringValue"] else {
                return nil
            }
            
            self = .submit(stringValue)
        case "Clear":
            self = .clear
            
        // MARK:- Mail Sharing #CustomMethod
        case "ShareWithEmail":
            guard case let .string(description)? = dict["Description"] else {
                return nil
            }
            
            guard case let .integer(likeCounter)? = dict["LikeCounter"] else {
                return nil
            }
            
            guard case let .integer(commentCounter)? = dict["CommentCounter"] else {
                return nil
            }
            
            guard case let .data(image)? = dict["Image"] else {
                return nil
            }
            
            guard case let .string(tag)? = dict["Tag"] else {
                return nil
            }
            
            guard case let .string(hashtag)? = dict["Hashtag"] else {
                return nil
            }
            
            guard case let .integer(shareCounter)? = dict["ShareCounter"] else {
                return nil
            }
            
            guard case let .string(publicationDate)? = dict["PublicationDate"] else {
                return nil
            }
            
            guard case let .string(publicationPlace)? = dict["PublicationPlace"] else {
                return nil
            }
            self = .shareWithEmail(description,
                                   likeCounter,
                                   commentCounter,
                                   image,
                                   tag,
                                   hashtag,
                                   shareCounter,
                                   publicationDate,
                                   publicationPlace)
            
        case "PauseUntilTapped":
            guard case let .string(prompt)? = dict["String"] else {
                return nil
            }

            self = .pauseUntilTapped(prompt)
        default:
            return nil
        }
    }
    
    fileprivate var playgroundValue: PlaygroundValue {
        switch self {
        case .show(let string):
            let dict: [String: PlaygroundValue] = [
                "Command": .string("Show"),
                "String": .string(string),
            ]
            return .dictionary(dict)
        case .showImage(let image):
            let dict: [String: PlaygroundValue] = [
                "Command": .string("ShowImage"),
                "ImageData": .data(image.pngData()!)
            ]
            return .dictionary(dict)
        case .ask(let valueType, let placeholder):
            let dict: [String: PlaygroundValue] = [
                "Command": .string("Ask"),
                "ValueType": valueType.playgroundValue,
                "Placeholder": .string(placeholder),
            ]
            return .dictionary(dict)
        case .submit(let stringValue):
            let dict: [String: PlaygroundValue] = [
                "Command": .string("Submit"),
                "StringValue": .string(stringValue),
            ]
            return .dictionary(dict)
        case .clear:
            let dict: [String: PlaygroundValue] = [
                "Command": .string("Clear")
            ]
            return .dictionary(dict)
        case .pauseUntilTapped(let string):
            let dict: [String: PlaygroundValue] = [
                "Command": .string("PauseUntilTapped"),
                "String": .string(string),
            ]
            return .dictionary(dict)
            
            
        // MARK:- Mail Sharing #CustomMethod
        case .shareWithEmail(let description,
                             let likeCounter,
                             let commentCounter,
                             let image,
                             let tag,
                             let hashtag,
                             let shareCounter,
                             let publicationDate,
                             let publicationPlace):
            
            let dict: [String: PlaygroundValue] = [
                "Command": .string("ShareWithEmail"),
                "Description": .string(description),
                "LikeCounter": .integer(likeCounter),
                "CommentCounter": .integer(commentCounter),
                "Image": .data(image),
                "Tag": .string(tag),
                "Hashtag": .string(hashtag),
                "ShareCounter": .integer(shareCounter),
                "PublicationDate": .string(publicationDate),
                "PublicationPlace": .string(publicationPlace),
            ]
            return .dictionary(dict)
        }
    }
}

extension PlaygroundLiveViewMessageHandler {
    func send(_ command: AnswersCommand) {
        self.send(command.playgroundValue)
    }
}
