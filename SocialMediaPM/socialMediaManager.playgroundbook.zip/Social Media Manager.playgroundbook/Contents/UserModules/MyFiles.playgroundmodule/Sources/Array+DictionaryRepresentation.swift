public extension Array {
    
    /// Restituisce un dictionary che ha come chiave una proprietà (conforme ad Hashable) di un oggetto presente nell'array, e come valore l'indice dell'oggetto corrispondente
    func dictionaryRepresentation<T: Hashable>(key: KeyPath<Element, T>) -> [T: Int] {
        var dict = [T: Int]()
        for (index, element) in self.enumerated() {
            dict[element[keyPath: key]] = index
        }

        return dict
    }
}
