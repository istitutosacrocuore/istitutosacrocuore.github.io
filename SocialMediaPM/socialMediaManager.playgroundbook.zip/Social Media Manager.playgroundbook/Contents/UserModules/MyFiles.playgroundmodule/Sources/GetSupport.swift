import Foundation

public func getSupport() {
    /// Invia una richiesta di supporto tramite email
    sharePost(
        description: "",
        likeCounter: 0,
        commentCounter: 0,
        image: Data(),
        tag: "",
        hashtag: "",
        shareCounter: 0,
        publicationDate: "",
        publicationPlace: "INTERNAL_"
    )
}
