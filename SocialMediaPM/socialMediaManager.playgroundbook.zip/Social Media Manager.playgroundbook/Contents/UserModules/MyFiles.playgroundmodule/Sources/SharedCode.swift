//Codice condiviso e disponibile su tutte le pagine del Playground Book

import UIKit

// Inizializzazione della galleria
public var images: [Image] = [#imageLiteral(resourceName: "Sample2.jpg"), #imageLiteral(resourceName: "Sample3.jpg"), "Hey!".image(withTint: .systemIndigo), "🖥".image()]

// Inizializzazione della directory destinata al salvataggio dei post su file
public let documentsDirectory =
    FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!

// Inizializzazione del file JSON nella directory individuata
public let archiveURL = documentsDirectory.appendingPathComponent("saved_posts").appendingPathExtension("json")

/// Individuazione del sistema operativo sul quale il Playground è in esecuzione (macCatalyst o iPadOS)
public let isMacOS: Bool = {
    #if targetEnvironment(macCatalyst)
    return true
    #else
    return false
    #endif
}()
