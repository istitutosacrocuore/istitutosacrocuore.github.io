public extension String {
	/// Restituisce una stringa formattata come Tag
    func asTag() -> String {
        let stringWithoutSpacing = self.replacingOccurrences(of: " ", with: "")
        return "@\(stringWithoutSpacing)"
    }
}
